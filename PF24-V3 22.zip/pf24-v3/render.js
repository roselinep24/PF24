/* PF24 V3 — Rendu UI de tous les écrans */
const R = (() => {
  const fmt=(n)=>Number(n||0).toFixed(2).replace(".",",")+" €";
  const fmtDate=(iso)=>iso?new Date(iso).toLocaleDateString("fr-FR"):"—";
  const fmtNum=(n)=>Number(n||0).toLocaleString("fr-FR");

  function topbar(title,sub,back,action){
    return `<div class="topbar">${back?`<button class="back" data-back>‹</button>`:""}<div><h1>${title}</h1>${sub?`<div class="sub">${sub}</div>`:""}</div>${action?`<button class="topbar-action" data-action="${action.code}">${action.label}</button>`:""}</div>`;
  }
  function empty(icon,text){ return `<div class="empty-state"><span class="ei">${icon}</span><p>${text}</p></div>`; }
  function toggleYN(id,label,val){ return `<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--grey-line);"><span style="font-size:14px;font-weight:600;">${label}</span><div class="chip-row" style="margin:0;"><div class="chip ${val==="oui"?"sel-yes":""}" data-toggle="${id}" data-val="oui">Oui</div><div class="chip ${val!=="oui"?"sel-no":""}" data-toggle="${id}" data-val="non">Non</div></div><input type="hidden" id="${id}" value="${val||"non"}"></div>`; }

  /* =================== LOGIN =================== */
  function login(){
    return `<div class="login-wrap"><div class="login-box">
      <div class="login-logo"><img src="assets/logo.png" alt="PF24 QSE" class="login-logo-img"><h1>PF24 QSE</h1><p>Prévention Facile — Accès privé</p></div>
      <div class="field"><label>Mot de passe</label><input type="password" id="pwd-input" placeholder="••••" autocomplete="current-password"></div>
      <button class="btn btn-primary" id="btn-login">Accéder →</button>
      <div style="text-align:center;margin-top:14px;font-size:11px;color:#8A93A3;">Version ${typeof APP_VERSION!=="undefined"?APP_VERSION:"?"}</div>
    </div></div>`;
  }

  /* =================== DASHBOARD =================== */
  function dashboard(stats){
    const c=PF24_DB.getConsultant();
    return `<div class="brand"><img src="assets/logo.png" alt="PF24 QSE" class="brand-logo"><div><h1>Bonjour 👋</h1><p>${c.nom||"Consultant PF24"}</p></div></div>
    <div class="screen">
      <div class="ca-banner"><div class="ca-label">Chiffre d'affaires estimé</div><div class="ca-num">${fmtNum(stats.caEstime)} €</div></div>
      <div class="kpi-grid">
        <div class="kpi-card" data-action="go-clients"><span class="kico">👥</span><span class="knum">${stats.totalClients}</span><div class="klab">Clients</div></div>
        <div class="kpi-card ${stats.devisEnAttente>0?"warn":""}" data-action="go-devis"><span class="kico">📄</span><span class="knum">${stats.devisEnAttente}</span><div class="klab">Devis en attente</div></div>
        <div class="kpi-card" data-action="go-visite-flow"><span class="kico">🔍</span><span class="knum">${stats.missionsEnCours}</span><div class="klab">Missions en cours</div></div>
        <div class="kpi-card ${stats.relancesUrgentes>0?"urgent":""}" data-action="go-relances"><span class="kico">🔔</span><span class="knum">${stats.relancesUrgentes}</span><div class="klab">Relances à faire</div></div>
        <div class="kpi-card" data-action="go-factures"><span class="kico">🧾</span><span class="knum">${stats.facturesAEnvoyer}</span><div class="klab">Factures à envoyer</div></div>
        <div class="kpi-card" data-action="go-catalogue"><span class="kico">🗂️</span><span class="knum">10</span><div class="klab">Offres disponibles</div></div>
      </div>
      <button class="btn btn-primary" data-action="go-visite-flow">🔍 Nouvelle visite terrain</button>
      <button class="btn btn-secondary" style="margin-top:10px" data-action="go-nouveau-devis">📄 Créer un devis rapidement</button>
    </div>`;
  }

  /* =================== CLIENTS =================== */
  function clientsList(clients){
    const groups={}; clients.forEach(c=>{ const s=c.statut||"client"; if(!groups[s])groups[s]=[]; groups[s].push(c); });
    return topbar("Clients",clients.length+" client(s)",true,{code:"go-nouveau-client",label:"+ Nouveau"})+`
    <div class="screen">
      ${clients.length===0?empty("👥","Aucun client. Commencez par créer un client ou démarrer une visite."):""}
      ${["prospect","client","inactif"].map(s=>{ if(!groups[s]) return ""; return `<div class="section-title">${s==="prospect"?"Prospects":s==="client"?"Clients actifs":"Inactifs"}</div>`+groups[s].map(c=>`<div class="list-row" data-open-client="${c.id}"><div class="lr-main"><div class="lr-name">${c.nom}</div><div class="lr-meta">${c.activite||""} • ${c.salaries||"?"}  sal.</div></div><div class="lr-right"><div>${c.prochainMaj&&new Date(c.prochainMaj)<new Date()?"<span class='badge badge-red'>Relance</span>":c.prochainMaj&&new Date(c.prochainMaj)<new Date(Date.now()+60*24*3600*1000)?"<span class='badge badge-orange'>Bientôt</span>":""}</div><div style="color:var(--grey-text);font-size:18px;">›</div></div></div>`).join(""); }).join("")}
    </div>`;
  }

  function clientDetail(client, tab, visites, devis, factures){
    const tabs=["info","visites","devis","factures"];
    return `<div class="client-header">
        <button class="back" data-back style="background:rgba(255,255,255,.12);border:none;color:#fff;width:34px;height:34px;border-radius:10px;font-size:18px;cursor:pointer;margin-bottom:10px;">‹</button>
        <div class="ch-name">${client.nom}</div><div class="ch-meta">${client.activite||""} • ${client.salaries||"?"}  salariés</div>
      </div>
      <div class="client-tabs">${tabs.map(t=>`<button class="${tab===t?"active":""}" data-client-tab="${t}">${{info:"ℹ️ Info",visites:"📋 Visites",devis:"📄 Devis",factures:"🧾 Factures"}[t]}</button>`).join("")}</div>
      <div class="screen">
      ${tab==="info"?clientInfo(client):tab==="visites"?clientVisites(client,visites):tab==="devis"?clientDevisList(client,devis):clientFacturesList(client,factures)}
      </div>`;
  }

  function clientInfo(c){
    return `<div class="card">
      <div class="section-title" style="margin-top:0;">Identité</div>
      <div style="font-size:14px;line-height:1.8;"><b>${c.nom}</b><br>${c.activite||""}<br>${c.adresse||""}<br>${c.telephone||""} ${c.email||""}<br>SIRET : ${c.siret||"—"} • APE : ${c.ape||"—"}</div>
    </div>
    <div class="card">
      <div class="section-title" style="margin-top:0;">Effectif</div>
      <div style="font-size:14px;line-height:1.8;">Total : <b>${c.salaries||"—"}</b> (H : ${c.hommes||"—"} / F : ${c.femmes||"—"})</div>
    </div>
    ${c.prochainMaj?`<div class="relance-row ${new Date(c.prochainMaj)<new Date()?"urgent":new Date(c.prochainMaj)<new Date(Date.now()+30*24*3600*1000)?"warn":""}">
      <div class="rr-client">📅 Prochaine mise à jour DUERP</div>
      <div class="rr-date">${fmtDate(c.prochainMaj)} ${new Date(c.prochainMaj)<new Date()?"— ⚠️ Dépassée":""}</div>
    </div>`:""}
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <button class="btn btn-primary btn-sm" data-action="demarrer-visite" data-client="${c.id}">🔍 Nouvelle visite</button>
      <button class="btn btn-secondary btn-sm" data-action="nouveau-devis-client" data-client="${c.id}">📄 Devis</button>
      <button class="btn btn-secondary btn-sm" data-action="edit-client" data-client="${c.id}">✏️ Modifier</button>
      <button class="btn btn-red btn-sm" data-action="supprimer-client" data-client="${c.id}">🗑️ Supprimer</button>
    </div>`;
  }
  function clientVisites(client,visites){ return visites.length?visites.slice().reverse().map(v=>`<div class="list-row" data-open-visit="${v.id}"><div class="lr-main"><div class="lr-name">${v.metierNom||"Visite"}</div><div class="lr-meta">${fmtDate(v.updatedAt)}</div></div><div class="lr-right"><span class="badge ${v.statut==="terminee"?"badge-green":"badge-grey"}">${v.statut==="terminee"?"Terminée":"En cours"}</span></div></div>`).join(""):empty("📋","Aucune visite pour ce client."); }
  function clientDevisList(client,devis){ return devis.length?devis.slice().reverse().map(d=>`<div class="list-row" data-open-devis="${d.id}"><div class="lr-main"><div class="lr-name">${d.numero}</div><div class="lr-meta">${fmtDate(d.date)}</div></div><div class="lr-right"><div class="lr-name">${fmtNum(d.total)} €</div><span class="badge ${d.statut==="accepte"?"badge-green":d.statut==="refuse"?"badge-red":d.statut==="envoye"?"badge-orange":"badge-grey"}">${d.statut}</span></div></div>`).join(""):empty("📄","Aucun devis pour ce client."); }
  function clientFacturesList(client,factures){ return factures.length?factures.slice().reverse().map(f=>`<div class="list-row" data-open-facture="${f.id}"><div class="lr-main"><div class="lr-name">${f.numero}</div><div class="lr-meta">${fmtDate(f.date)}</div></div><div class="lr-right"><div class="lr-name">${fmtNum(f.total)} €</div><span class="badge ${f.statut==="payee"?"badge-green":f.statut==="impayee"?"badge-red":"badge-orange"}">${f.statut}</span></div></div>`).join(""):empty("🧾","Aucune facture."); }

  function nouveauClient(edit){
    const c=edit||{}; const yn=(id,v)=>toggleYN(id,"",v);
    return topbar(edit?"Modifier le client":"Nouveau client","",true)+`
    <div class="screen">
      <div class="card">
        <div class="section-title" style="margin-top:0;">Identité</div>
        <div class="field"><label>Raison sociale *</label><input id="f-nom" value="${c.nom||""}" placeholder="Ex. Le Bon Pain SARL"></div>
        <div class="field"><label>Statut</label><select id="f-statut"><option value="prospect" ${(c.statut||"prospect")==="prospect"?"selected":""}>Prospect</option><option value="client" ${c.statut==="client"?"selected":""}>Client</option><option value="inactif" ${c.statut==="inactif"?"selected":""}>Inactif</option></select></div>
        <div class="field-row"><div class="field"><label>SIRET</label><input id="f-siret" value="${c.siret||""}" placeholder="14 chiffres"></div><div class="field"><label>Code APE / NAF</label><input id="f-ape" value="${c.ape||""}" placeholder="Ex. 1071C"></div></div>
        <div class="field"><label>Adresse</label><input id="f-adresse" value="${c.adresse||""}" placeholder="Adresse complète"></div>
        <div class="field-row"><div class="field"><label>Téléphone</label><input id="f-telephone" type="tel" value="${c.telephone||""}" placeholder="06 00 00 00 00"></div><div class="field"><label>Email</label><input id="f-email" type="email" value="${c.email||""}" placeholder="contact@..."></div></div>
        <div class="field"><label>Contact / Dirigeant</label><input id="f-contact" value="${c.contact||""}" placeholder="Nom du dirigeant"></div>
        <div class="field"><label>Activité</label><input id="f-activite" value="${c.activite||""}" placeholder="Ex. Boulangerie"></div>
      </div>
      <div class="card">
        <div class="section-title" style="margin-top:0;">Effectif</div>
        <div class="field-row"><div class="field"><label>Total *</label><input id="f-salaries" type="number" min="0" value="${c.salaries||0}"></div><div class="field"><label>SPST — Service de Prévention et de Santé au Travail</label><input id="f-spst" value="${c.spst||""}" placeholder="Ex : ACMS, AMETIF, CMB…"></div></div>
        <div class="field-row"><div class="field"><label>Téléphone SPST</label><input id="f-spstTel" value="${c.spstTel||""}" placeholder="01 …"></div><div class="field"><label>Référent sécurité interne</label><input id="f-referentSecurite" value="${c.referentSecurite||""}" placeholder="Nom (si désigné)"></div></div>
        <div class="field-row"><div class="field"><label>Tél. référent sécurité</label><input id="f-referentTel" value="${c.referentTel||""}"></div><div class="field"><label>Localisation trousse de secours</label><input id="f-trousseLocalisation" value="${c.trousseLocalisation||""}" placeholder="Ex : cuisine, près de l'évier"></div></div>
        <div class="field"><label>Point de rassemblement (évacuation)</label><input id="f-pointRassemblement" value="${c.pointRassemblement||""}" placeholder="Ex : parking devant l'entrée"></div>
        <div class="field-row"><div class="field"><label>Hommes</label><input id="f-hommes" type="number" min="0" value="${c.hommes||0}"></div><div class="field"><label>Femmes</label><input id="f-femmes" type="number" min="0" value="${c.femmes||0}"></div></div>
        ${toggleYN("f-apprentis","Apprentis",c.apprentis?"oui":"non")}
        ${toggleYN("f-interimaires","Intérimaires",c.interimaires?"oui":"non")}
        ${toggleYN("f-jeunes","Jeunes travailleurs (-18 ans)",c.jeunesTravailleurs?"oui":"non")}
        ${toggleYN("f-isoles","Travailleurs isolés",c.travailIsole?"oui":"non")}
        ${toggleYN("f-vulnerables","Salariés vulnérables (non nominatif)",c.vulnerables?"oui":"non")}
        ${toggleYN("f-exterieures","Coactivité / entreprises extérieures",c.entreprisesExterieures?"oui":"non")}
        ${toggleYN("f-deplacements","Déplacements professionnels réguliers",c.deplacements?"oui":"non")}
      </div>
      <div class="card">
        <div class="section-title" style="margin-top:0;">Traçabilité DUERP</div>
        <div class="field"><label>Rédacteur du DUERP</label><input id="f-redacteur" value="${c.redacteur||PF24_DB.getConsultant().nom||""}" placeholder="Nom du consultant"></div>
        <div class="field-row"><div class="field"><label>Valideur (dirigeant)</label><input id="f-valideur" value="${c.valideur||c.contact||""}" placeholder="Nom du dirigeant"></div><div class="field"><label>Fonction du dirigeant</label><input id="f-fonctionDirigeant" value="${c.fonctionDirigeant||""}" placeholder="Gérant, Président…"></div></div>
        <div class="field"><label>Prochaine mise à jour DUERP</label><input id="f-prochainMaj" type="date" value="${c.prochainMaj?c.prochainMaj.slice(0,10):""}"></div>
      </div>
      <div class="card">
        <div class="field"><label>Photo façade</label>
          <div class="photo-upload" data-action="prendre-photo-client">📷 Prendre une photo de la façade<div id="preview-client">${c.photoId?"<img id='preview-img' data-photoid='"+c.photoId+"'>":""}</div></div>
          <p style="font-size:11px;color:var(--grey-text);margin-top:6px;">⚠️ Ne pas photographier de visages (RGPD)</p>
        </div>
      </div>
      <button class="btn btn-primary" data-action="valider-client" data-edit="${edit?.id||""}">Enregistrer →</button>
    </div>`;
  }

  /* =================== CATALOGUE =================== */
  function catalogue(){
    return topbar("Catalogue d'offres","10 prestations disponibles",true)+`
    <div class="screen">
      ${CATALOGUE.map(p=>`<div class="cat-card" data-open-offre="${p.id}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;">
          <div class="cat-name">${p.nom}</div>
          ${p.badge?`<span class="badge badge-navy">${p.badge}</span>`:""}
        </div>
        <div class="cat-price">${p.prix} €</div>
        <div class="cat-desc">${p.desc}</div>
        <div class="cat-tags">${p.livrables.slice(0,3).map(l=>`<span class="badge badge-blue">✓ ${l}</span>`).join("")}</div>
      </div>`).join("")}
    </div>`;
  }

  /* =================== DEVIS =================== */
  function devisList(list, clients){
    return topbar("Devis",list.length+" devis",true,{code:"go-nouveau-devis",label:"+ Nouveau"})+`
    <div class="screen">
      ${list.length===0?empty("📄","Aucun devis. Créez votre premier devis."):""}
      ${list.slice().reverse().map(d=>{ const c=clients.find(x=>x.id===d.clientId); return `<div class="list-row" data-open-devis="${d.id}">
        <div class="lr-main"><div class="lr-name">${d.numero}</div><div class="lr-meta">${c?c.nom:"Client inconnu"} • ${fmtDate(d.date)}</div></div>
        <div class="lr-right"><div class="lr-name">${fmtNum(d.total)} €</div><span class="badge ${d.statut==="accepte"?"badge-green":d.statut==="refuse"?"badge-red":d.statut==="envoye"?"badge-orange":"badge-grey"}">${d.statut}</span></div>
      </div>`; }).join("")}
    </div>`;
  }

  function nouveauDevis(clients, selectedClientId, precheckOffre){
    return topbar("Nouveau devis","",true)+`
    <div class="screen">
      <div class="card">
        <div class="section-title" style="margin-top:0;">Client</div>
        <div class="field"><label>Client *</label><select id="dv-clientId"><option value="">— Choisir —</option>${clients.map(c=>`<option value="${c.id}" ${c.id===selectedClientId?"selected":""}>${c.nom}</option>`).join("")}</select></div>
      </div>
      <div class="card">
        <div class="section-title" style="margin-top:0;">Ajustement du tarif</div>
        <div class="field-row">
          <div class="field"><label>Effectif client</label><input id="dv-effectif" type="number" min="0" placeholder="Nb salariés" value="0"></div>
          <div class="field"><label>Complexité</label><select id="dv-complexite"><option value="simple">Simple</option><option value="moderee">Modérée (+20 %)</option><option value="complexe">Complexe (+50 %)</option></select></div>
        </div>
        <p style="font-size:11.5px;color:var(--grey-text);margin:0 0 4px;">Le prix calculé s'affiche dans le champ. Modifiez-le librement pour faire un geste commercial.</p>
      </div>
      <div class="card">
        <div class="section-title" style="margin-top:0;">Prestations — cochez et ajustez le prix</div>
        ${CATALOGUE.map(p=>`<div class="dv-line" id="dvline-${p.id}" style="display:flex;align-items:flex-start;gap:10px;padding:12px 0;border-bottom:1px solid var(--grey-line);">
          <input type="checkbox" class="dv-cb" id="dv-cat-${p.id}" ${p.id===precheckOffre?"checked":""}
            data-catid="${p.id}"
            data-baseprix="${p.prix}"
            data-nom="${p.nom.replace(/"/g,"&quot;")}"
            style="width:22px;height:22px;flex-shrink:0;margin-top:3px;accent-color:var(--navy);">
          <div style="flex:1;min-width:0;">
            <div style="font-weight:800;font-size:14px;line-height:1.3;">${p.nom}</div>
            <div style="font-size:11.5px;color:var(--grey-text);margin-top:2px;">${p.desc}</div>
            <div style="font-size:11px;color:var(--grey-mid);margin-top:2px;">⏱ ${p.duree}</div>
            <div id="dv-tarif-${p.id}" style="font-size:11px;color:var(--grey-mid);text-decoration:line-through;min-height:14px;margin-top:2px;"></div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0;">
            <input id="dv-price-${p.id}" class="dv-pi" type="number" min="0" step="10"
              value="${p.prix}" disabled
              style="width:88px;padding:8px 10px;border:1.5px solid var(--grey-line);border-radius:9px;font-size:15px;font-weight:800;text-align:right;color:var(--navy);background:#f8f9fb;opacity:.45;transition:.15s;">
            <span style="font-size:10px;color:var(--grey-mid);">€ HT</span>
          </div>
        </div>`).join("")}
      </div>
      <div class="card" style="background:var(--navy);color:#fff;display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="font-size:12px;opacity:.7;margin-bottom:4px;">Total devis</div>
          <div id="dv-total-num" style="font-size:30px;font-weight:900;">0,00 €</div>
          <div style="font-size:10px;opacity:.6;margin-top:4px;">${REGLEMENTAIRE.tva}</div>
        </div>
        <div style="font-size:11px;opacity:.6;text-align:right;max-width:110px;">Modifiable ligne par ligne</div>
      </div>
      <div class="field"><label>Commentaire / conditions particulières</label><textarea id="dv-commentaire" placeholder="Geste commercial, conditions de paiement, validité…" rows="3"></textarea></div>
      <button class="btn btn-primary" data-action="valider-devis">Enregistrer le devis →</button>
    </div>`;
  }


  function devisDetail(devis, client){
    const statOptions=["brouillon","envoye","accepte","refuse"];
    return topbar(devis.numero,client?.nom||"",true)+`
    <div class="screen">
      <div class="dv-header">
        <div class="dv-num">${devis.numero}</div>
        <div class="dv-date">Client : ${client?.nom||"—"} • ${fmtDate(devis.date)}</div>
        <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
          ${statOptions.map(s=>`<div class="chip ${devis.statut===s?"sel-present":""}" data-action="set-devis-statut" data-devis="${devis.id}" data-statut="${s}">${s}</div>`).join("")}
        </div>
      </div>
      ${devis.lignes.map(l=>`<div class="dv-ligne"><div class="dl-name">${l.nom}${l.remise>0?` <span class="badge badge-orange" style="font-size:10px;padding:2px 7px;">Offre -${l.remise}%</span>`:""}<br><span style="font-size:12px;color:var(--grey-text);">${l.prixCatalogue&&l.remise>0?`<s>${fmt(l.prixCatalogue)}</s> → `:""} ${fmt(l.prixUnit)}</span></div><div class="dl-price" style="${l.remise>0?"color:var(--green);":""}">${fmt(l.total)}</div></div>`).join("")}
      <div class="dv-total"><span class="dt-label">Total HT</span><span class="dt-amount">${fmtNum(devis.total)} €</span></div>
      <p class="tva-mention">${REGLEMENTAIRE.tva}</p>
      ${devis.commentaire?`<p style="font-size:13px;color:var(--grey-text);">${devis.commentaire}</p>`:""}
      <button class="btn btn-primary" data-action="generer-pdf-devis" data-devis="${devis.id}">📄 Télécharger PDF devis</button>
      ${devis.statut==="accepte"?`<button class="btn btn-green" style="margin-top:10px" data-action="creer-facture-from-devis" data-devis="${devis.id}">🧾 Créer la facture</button>`:""}
      <button class="btn btn-secondary" style="margin-top:10px" data-action="supprimer-devis" data-devis="${devis.id}">🗑️ Supprimer</button>
    </div>`;
  }

  /* =================== FACTURES =================== */
  function facturesList(list, clients){
    return topbar("Factures",list.length+" facture(s)",true)+`
    <div class="screen">
      ${list.length===0?empty("🧾","Aucune facture. Acceptez un devis pour en créer une."):""}
      ${list.slice().reverse().map(f=>{ const c=clients.find(x=>x.id===f.clientId); return `<div class="list-row" data-open-facture="${f.id}">
        <div class="lr-main"><div class="lr-name">${f.numero}</div><div class="lr-meta">${c?c.nom:"—"} • Éch. ${fmtDate(f.dateEcheance)}</div></div>
        <div class="lr-right"><div class="lr-name">${fmtNum(f.total)} €</div><span class="badge ${f.statut==="payee"?"badge-green":f.statut==="impayee"?"badge-red":"badge-orange"}">${f.statut}</span></div>
      </div>`; }).join("")}
    </div>`;
  }

  function factureDetail(facture, client){
    return topbar(facture.numero,client?.nom||"",true)+`
    <div class="screen">
      <div class="dv-header" style="background:${facture.statut==="payee"?"var(--green)":facture.statut==="impayee"?"var(--red)":"var(--navy)"}">
        <div class="dv-num">${facture.numero}</div>
        <div class="dv-date">${client?.nom||""} • ${fmtDate(facture.date)} • Éch. ${fmtDate(facture.dateEcheance)}</div>
        <div style="margin-top:10px;display:flex;gap:8px;">
          ${["brouillon","envoyee","payee","impayee"].map(s=>`<div class="chip ${facture.statut===s?"sel-present":""}" data-action="set-facture-statut" data-facture="${facture.id}" data-statut="${s}">${s}</div>`).join("")}
        </div>
      </div>
      ${facture.lignes.map(l=>`<div class="dv-ligne"><div class="dl-name">${l.nom}</div><div class="dl-price">${fmt(l.total)}</div></div>`).join("")}
      <div class="dv-total"><span class="dt-label">Total HT</span><span class="dt-amount">${fmtNum(facture.total)} €</span></div>
      ${facture.acompte>0?`<div style="display:flex;justify-content:space-between;padding:10px 0;font-size:14px;"><span>Acompte versé</span><span style="color:var(--green);">- ${fmtNum(facture.acompte)} €</span></div>`:""}
      <div style="display:flex;justify-content:space-between;padding:10px 0;font-size:16px;font-weight:900;"><span>Solde à régler</span><span>${fmtNum(facture.solde||facture.total)} €</span></div>
      <p class="tva-mention">${REGLEMENTAIRE.tva}</p>
      <button class="btn btn-primary" data-action="generer-pdf-facture" data-facture="${facture.id}">📄 Télécharger PDF facture</button>
      <button class="btn btn-secondary" style="margin-top:10px" data-action="supprimer-facture" data-facture="${facture.id}">🗑️ Supprimer</button>
    </div>`;
  }

  /* =================== VISITE TERRAIN =================== */
  function choixMetier(){
    const secteurs=[...new Set(Object.values(METIERS).map(m=>m.secteur))];
    return topbar("Choix du métier","Étape 1 / 5",true)+`
    <div class="screen">
      ${secteurs.map(s=>`<div class="section-title">${s}</div>`+Object.entries(METIERS).filter(([,m])=>m.secteur===s).map(([id,m])=>`<button class="bloc-btn" data-action="choisir-metier" data-metier="${id}"><span class="bb-icon">${m.icon}</span><span class="bb-title">${m.nom}</span></button>`).join("")).join("")}
    </div>`;
  }

  function choixBlocs(visit){
    const m=METIERS[visit.metierId]; const blocIds=m?m.blocs:[];
    return topbar("Blocs à analyser","Étape 2 / 5",true)+`
    <div class="screen">
      <p style="font-size:13px;color:var(--grey-text);margin-top:0;">Cochez les blocs présents dans l'établissement.</p>
      <div>${blocIds.map(bid=>{ const b=BLOCS[bid]; const sel=(visit.blocsSelectionnes||[]).includes(bid); return `<div class="bloc-btn ${sel?"sel":""}" data-action="toggle-bloc" data-bloc="${bid}"><span class="bb-icon">${b.icon}</span><span class="bb-title">${b.nom}</span></div>`; }).join("")}</div>
      <button class="btn btn-primary" style="margin-top:16px" data-action="valider-blocs">Continuer →</button>
    </div>`;
  }

  function populationBlocs(visit){
    const blocIds=visit.blocsSelectionnes||[];
    return topbar("Population exposée","Étape 3 / 5 (R4121-1)",true)+`
    <div class="screen">
      ${blocIds.map(bid=>{ const b=BLOCS[bid]; const p=(visit.population||{})[bid]||{}; return `<div class="card"><div class="section-title" style="margin-top:0;">${b.icon} ${b.nom}</div>
        <div class="field-row"><div class="field"><label>Exposés</label><input data-pop="${bid}" data-field="exposes" type="number" min="0" value="${p.exposes||0}"></div><div class="field"><label>Femmes</label><input data-pop="${bid}" data-field="femmes" type="number" min="0" value="${p.femmes||0}"></div></div>
        <div class="chip-row">${["apprentis","interimaires","jeunesTravailleurs","travailIsole","expoDiff"].map(f=>`<div class="chip toggle-pop ${p[f]?"sel-yes":""}" data-pop-toggle="${bid}" data-field="${f}">${{apprentis:"Apprentis",interimaires:"Intérim",jeunesTravailleurs:"Jeunes",travailIsole:"Isolé",expoDiff:"Expo H/F"}[f]}</div>`).join("")}</div>
      </div>`; }).join("")}
      <button class="btn btn-primary" data-action="valider-population">Démarrer la visite terrain →</button>
    </div>`;
  }

  function visiteBlocs(visit, client){
    const blocsIds=visit.blocsSelectionnes||[];
    let _tot=0,_done=0;
    blocsIds.forEach(bid=>{const objs=OBJETS_PAR_BLOC[bid]||[];const bs=visit.blocs[bid]||{};_tot+=objs.length;_done+=objs.filter(o=>bs.objets?.[o]?.statut).length;});
    const _pct=_tot?Math.round(_done/_tot*100):0;
    return topbar(client?.nom||"Visite terrain",`${_pct}% renseigné`,true)+`
    <div class="screen">
      <div style="background:#E3E8F0;border-radius:8px;height:10px;margin-bottom:14px;overflow:hidden;"><div style="width:${_pct}%;height:100%;background:linear-gradient(90deg,var(--green,#1E9E63),#25c07a);border-radius:8px;transition:width .3s;"></div></div>
      ${blocsIds.map(bid=>{ const b=BLOCS[bid]; const objs=OBJETS_PAR_BLOC[bid]||[]; const bs=visit.blocs[bid]||{}; const done=objs.filter(o=>bs.objets?.[o]?.statut).length; return `<button class="bloc-btn" data-action="ouvrir-bloc" data-bloc="${bid}"><span class="bb-icon">${b.icon}</span><span class="bb-title">${b.nom}</span><span class="bb-meta">${done}/${objs.length} renseignés</span></button>`; }).join("")}
    </div>`;
  }

  function visiteBlocDetail(visit, blocId){
    const b=BLOCS[blocId]; const objs=OBJETS_PAR_BLOC[blocId]||[]; const bs=visit.blocs[blocId]||{objets:{}};
    return topbar(b.nom,"Objets / équipements",true)+`
    <div class="screen">
      ${objs.map(obj=>{ const o=bs.objets[obj]||{statut:null,maitrise:null,observation:"",photos:[]}; return `<div class="obj-row">
        <div class="or-head"><div class="or-name">${obj}</div></div>
        <div class="chip-row">
          <div class="chip ${o.statut==="present"?"sel-present":""}" data-action="set-statut" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-statut="present">Présent</div>
          <div class="chip ${o.statut==="absent"?"sel-absent":""}" data-action="set-statut" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-statut="absent">Absent</div>
          <div class="chip ${o.statut==="na"?"sel-na":""}" data-action="set-statut" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-statut="na">NC</div>
        </div>
        ${o.statut==="present"?`<div class="mastery"><div class="m ${o.maitrise==="bon"?"sel-bon":""}" data-action="set-maitrise" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-maitrise="bon">Bon</div><div class="m ${o.maitrise==="moyen"?"sel-moyen":""}" data-action="set-maitrise" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-maitrise="moyen">Moyen</div><div class="m ${o.maitrise==="insuffisant"?"sel-insuf":""}" data-action="set-maitrise" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}" data-maitrise="insuffisant">Insuffisant</div></div>
        <div class="obj-actions">
          <button data-action="ajouter-photo-objet" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}">📷 Photo (${(o.photos||[]).length})</button>
          <button data-action="ajouter-observation" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}">📝 Texte</button>
          <button data-action="dicter-observation" data-bloc="${blocId}" data-objet="${encodeURIComponent(obj)}">🎤 Dicter</button>
        </div>
        ${o.observation?`<div style="font-size:12px;color:var(--grey-text);margin-top:8px;font-style:italic;">"${o.observation}"</div>`:""}
        ${o.iaSuggestion?`<div class="ia-card"><div class="ia-title">🤖 Suggestions IA — à valider</div><div class="ia-item">🔍 ${o.iaSuggestion.objetsDetectes.join(", ")}</div>${o.iaSuggestion.risquesPossibles.length?`<div class="ia-item">⚠️ ${o.iaSuggestion.risquesPossibles.join(", ")}</div>`:""}</div>`:""}
        `:""}
      </div>`; }).join("")}
    </div>`;
  }

  function photosGalerie(visit, photosData){
    return topbar("Photos",(visit.photos||[]).length+" photo(s)",true)+`
    <div class="screen">
      ${photosData.length?`<div class="photo-grid">${photosData.map(p=>`<div class="photo-thumb"><img src="${p.dataUrl}"><div class="pt-cap">${p.objet||p.blocNom||""}</div></div>`).join("")}</div>`:empty("📷","Aucune photo pour l'instant.")}
    </div>`;
  }

  function risquesListe(risques){
    return topbar("Risques identifiés",risques.length+" risque(s)",true)+`
    <div class="screen">
      ${risques.length===0?empty("⚠️","Cochez des objets présents dans la visite pour générer les risques."):""}
      ${risques.map(r=>`<div class="risk-row"><div class="rr-top"><div><div class="rr-danger">${r.danger}</div><div class="rr-meta">${r.unite} — ${r.objet}<br>${r.situation}</div></div><div class="niv-badge" style="background:${r.couleur==="red"?"var(--red)":r.couleur==="orange"?"var(--orange)":"var(--green)"}">${r.niveau}</div></div><div style="font-size:12.5px;margin-top:8px;">Dommages : ${r.dommages}</div><div style="margin-top:6px;"><span class="label-type ${r.type==="obligatoire"?"label-oblig":r.type==="inrs"?"label-inrs":"label-best"}">${r.type==="obligatoire"?"⚖️ Obligation":r.type==="inrs"?"📘 INRS":"✅ Bonne pratique"}</span></div></div>`).join("")}
    </div>`;
  }

  function validation(visit, risques, actions, score, scoreConf, stats, client){
    return topbar("Bilan de visite","Génération dossier",true)+`
    <div class="screen">
      <div class="grid2" style="margin-bottom:16px;">
        <div class="card" style="text-align:center;"><div class="score-circle" style="--score:${score};width:100px;height:100px;"><div class="score-inner" style="width:78px;height:78px;"><b style="font-size:20px;">${score}</b><span>Sécurité</span></div></div></div>
        <div class="card" style="text-align:center;"><div class="score-circle" style="--score:${scoreConf};width:100px;height:100px;"><div class="score-inner" style="width:78px;height:78px;"><b style="font-size:20px;">${scoreConf}</b><span>Conformité</span></div></div></div>
      </div>
      <div style="text-align:center;font-size:11px;color:var(--grey-t,#5B6472);margin:-8px 0 10px;">Indicateurs internes PF24 — sans valeur réglementaire</div>
      <div class="stat-grid">
        <div class="stat-tile"><div class="snum">${stats.blocs}</div><div class="slab">Unités</div></div>
        <div class="stat-tile"><div class="snum">${stats.objets}</div><div class="slab">Objets</div></div>
        <div class="stat-tile"><div class="snum">${risques.length}</div><div class="slab">Risques</div></div>
        <div class="stat-tile"><div class="snum">${actions.length}</div><div class="slab">Actions</div></div>
        <div class="stat-tile"><div class="snum">${risques.filter(r=>r.couleur==="red").length}</div><div class="slab">Critiques</div></div>
        <div class="stat-tile"><div class="snum">${stats.photos}</div><div class="slab">Photos</div></div>
      </div>
      <button class="btn btn-green" style="margin-top:16px" data-action="generer-dossier">📄 Dossier DUERP complet (PDF)</button>
      <div class="section-title" style="margin-top:16px;margin-bottom:8px;">Documents éditables (Word)</div>
      <div class="grid2" style="gap:8px;">
        <button class="btn btn-secondary btn-sm" data-action="generer-word">📝 DUERP Word</button>
        <button class="btn btn-secondary btn-sm" data-action="generer-registre">🧯 Registre sécurité</button>
      </div>
      <button class="btn btn-secondary" style="margin-top:8px;" data-action="generer-fiches">👷 Fiches de poste</button>
      ${client?.entreprisesExterieures
        ?`<button class="btn btn-secondary" style="margin-top:8px;" data-action="generer-pdp">🤝 Plan de prévention (entreprises extérieures)</button>`
        :`<div style="font-size:11.5px;color:var(--grey-t,#5B6472);margin-top:8px;padding:8px 10px;background:#F4F6F9;border-radius:8px;">🤝 Plan de prévention non proposé — aucune entreprise extérieure déclarée (modifiable dans la fiche client).</div>`}
      ${((visit.blocsSelectionnes||[]).includes("livraison")||client?.deplacements)
        ?`<button class="btn btn-secondary" style="margin-top:8px;" data-action="generer-protocole">🚚 Protocole de sécurité (chargement/déchargement)</button>`
        :`<div style="font-size:11.5px;color:var(--grey-t,#5B6472);margin-top:8px;padding:8px 10px;background:#F4F6F9;border-radius:8px;">🚚 Protocole de sécurité non proposé — aucune livraison/déplacement déclaré.</div>`}
      <div class="grid2" style="margin-top:10px;">
        <button class="btn btn-secondary btn-sm" data-action="ouvrir-registre">📋 Saisir registre</button>
        <button class="btn btn-secondary btn-sm" data-action="ouvrir-historique">🕓 Historique</button>
      </div>
      <button class="btn btn-secondary" style="margin-top:10px" data-action="exporter-json-visite">⬇️ Exporter JSON</button>
      <p style="font-size:11px;color:var(--grey-text);margin-top:14px;">${REGLEMENTAIRE.mention_validation}</p>
    </div>`;
  }

  function upsell(suggestions){
    return topbar("Opportunités",suggestions.length+" prestation(s) suggérée(s)",true)+`
    <div class="screen">
      <p style="font-size:13.5px;color:var(--grey-text);">À la suite de cette visite, PF24 détecte des besoins complémentaires :</p>
      ${suggestions.map(s=>`<div class="upsell-banner" data-action="upsell-devis" data-offre="${s.id}" style="cursor:pointer;"><div class="ub-title">${CATALOGUE.find(c=>c.id===s.id)?.nom||s.id}</div><div class="ub-desc">${s.raison}</div><div class="ub-cta" data-action="upsell-devis" data-offre="${s.id}">Créer un devis →</div></div>`).join("")}
      <button class="btn btn-primary" data-action="go-clients">Retour au tableau de bord</button>
    </div>`;
  }

  /* =================== RELANCES =================== */
  function relances(list){
    return topbar("Relances annuelles",list.length+" à traiter",true)+`
    <div class="screen">
      ${list.length===0?empty("🔔","Aucune relance pour les 90 prochains jours. Bravo !"):""}
      ${list.map(r=>{ const diff=r.diff; const msg=diff<0?`En retard de ${Math.abs(diff)} jours`:diff===0?"Aujourd'hui":`Dans ${diff} jour(s)`; return `<div class="relance-row ${r.urgence}">
        <div class="rr-client">${r.client.nom}</div>
        <div class="rr-date">${msg} • ${fmtDate(r.client.prochainMaj)}</div>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;">
          <button class="btn btn-sm btn-secondary" data-action="email-relance" data-client="${r.client.id}">📧 Email type</button>
          <button class="btn btn-sm btn-secondary" data-action="devis-relance" data-client="${r.client.id}">📄 Devis mise à jour</button>
          <button class="btn btn-sm btn-green" data-action="demarrer-visite" data-client="${r.client.id}">🔍 Nouvelle visite</button>
        </div>
      </div>`; }).join("")}
    </div>`;
  }

  /* =================== PARAMÈTRES =================== */
  function parametres(consultant){
    return topbar("Paramètres","",true)+`
    <div class="screen">
      <div class="section-title">Profil consultant</div>
      <div class="settings-section">
        <div class="field" style="padding:14px 16px;">
          <div class="field"><label>Nom complet</label><input id="cons-nom" value="${consultant.nom||""}"></div>
          <div class="field"><label>Fonction</label><input id="cons-fonction" value="${consultant.fonction||"Conseil en Qualité, Sécurité et Environnement"}"></div>
          <div class="field"><label>Activité</label><input id="cons-activite" value="${consultant.activite||""}"></div>
          <div class="field"><label>SIRET</label><input id="cons-siret" value="${consultant.siret||""}"></div>
          <div class="field"><label>Adresse</label><input id="cons-adresse" value="${consultant.adresse||""}"></div>
          <div class="field-row"><div class="field"><label>Téléphone</label><input id="cons-tel" value="${consultant.telephone||""}"></div><div class="field"><label>Email</label><input id="cons-email" value="${consultant.email||""}"></div></div>
          <div class="field"><label>Pied de page des documents</label><input id="cons-piedpage" value="${consultant.piedPage||""}" placeholder="Ex : PF24 QSE — Prévention Facile — contact@pf24qse.fr"></div>
          <button class="btn btn-primary btn-sm" data-action="sauver-consultant">Enregistrer le profil</button>
        </div>
      </div>
      <div class="section-title">Sécurité</div>
      <div class="settings-section">
        <div style="padding:14px 16px;">
          <div class="field"><label>Ancien mot de passe</label><input type="password" id="pwd-old" placeholder="Mot de passe actuel"></div>
          <div class="field"><label>Nouveau mot de passe</label><input type="password" id="pwd-new" placeholder="Nouveau mot de passe"></div>
          <button class="btn btn-secondary btn-sm" data-action="changer-pwd">Changer le mot de passe</button>
        </div>
      </div>
      <div class="section-title">Historique des générations</div>
      <div class="card">
        ${(PF24_DB.getGenerations&&PF24_DB.getGenerations().length)?PF24_DB.getGenerations().slice(0,8).map(g=>`<div style="font-size:12px;padding:6px 0;border-bottom:1px solid #EEF1F5;"><b>${g.type}</b> — ${g.clientNom||""}<br><span style="color:var(--grey-t,#5B6472);">${g.date} ${g.heure} — v${g.version||1}</span></div>`).join(""):`<div style="font-size:12px;color:var(--grey-t,#5B6472);">Aucune génération enregistrée pour l'instant.</div>`}
      </div>
      <div class="section-title">Données</div>
      <div class="settings-section">
        <div class="settings-row" data-action="export-all-json"><span class="sr-label">⬇️ Exporter toutes les données</span></div>
        <div class="settings-row" style="cursor:default;"><span class="sr-label">⬆️ Importer des données</span><span><input type="file" id="import-file" accept=".json" style="font-size:12px;"></span></div>
        <div class="settings-row" data-action="import-all"><span class="sr-label">Valider l'import</span></div>
        <div class="settings-row" data-action="charger-demo"><span class="sr-label">▶️ Charger la visite de démonstration</span></div>
      </div>
      <div class="section-title">🔒 RGPD</div>
      <div class="card"><p style="font-size:12px;color:var(--grey-text);line-height:1.6;">${MENTIONS_RGPD.finalite}<br><br>${MENTIONS_RGPD.minimisation}<br><br>${MENTIONS_RGPD.photos}<br><br>${MENTIONS_RGPD.conservation}</p></div>
      <button class="btn btn-red" style="margin-top:10px" data-action="logout">Se déconnecter</button>
    </div>`;
  }


  /* =================== CHOIX CLIENT =================== */
  const REG_ITEMS_R=["Extincteurs","Installation électrique","Gaz (si applicable)","Ventilation (si applicable)","Équipements soumis à vérification","Trousse de secours","FDS (fiches de données de sécurité)","Formations sécurité","Consignes incendie","Plan d'évacuation"];

  function choixClient(clients){
    return topbar("Choisir un client","Avant de démarrer la visite",true)+`
    <div class="screen">
      <button class="btn btn-secondary" data-action="go-nouveau-client-visite" style="margin-bottom:16px;">+ Créer un nouveau client</button>
      ${clients.length===0?empty("👥","Aucun client. Créez d'abord un client."):""}
      ${clients.map(c=>`<div class="list-row" data-start-visit="${c.id}">
        <div class="lr-main"><div class="lr-name">${c.nom}</div><div class="lr-meta">${c.activite||""} • ${c.salaries||"?"}  sal.</div></div>
        <div style="color:var(--grey-text);font-size:20px;">›</div>
      </div>`).join("")}
    </div>`;
  }

  function registreScreen(visit){
    const reg=visit?.registre||{};
    return topbar("Registre sécurité","Simplifié",true)+`
    <div class="screen">
      ${REG_ITEMS_R.map(item=>{ const r=reg[item]||{}; return `<div class="obj-row">
        <div class="or-head"><div class="or-name">${item}</div></div>
        <div class="chip-row">
          <div class="chip ${r.statut==="conforme"?"sel-present":""}" data-action="set-registre" data-item="${encodeURIComponent(item)}" data-statut="conforme">✔ Conforme</div>
          <div class="chip ${r.statut==="a_verifier"?"sel-na":""}" data-action="set-registre" data-item="${encodeURIComponent(item)}" data-statut="a_verifier">⚠ À vérifier</div>
          <div class="chip ${r.statut==="non_conforme"?"sel-absent":""}" data-action="set-registre" data-item="${encodeURIComponent(item)}" data-statut="non_conforme">✗ Non conforme</div>
        </div>
        <div class="field" style="margin-top:8px;"><textarea data-reg-obs="${encodeURIComponent(item)}" placeholder="Observation…" rows="2">${r.observation||""}</textarea></div>
      </div>`; }).join("")}
      <button class="btn btn-primary" data-action="sauver-registre">Enregistrer le registre</button>
    </div>`;
  }

  function historiqueScreen(visit){
    const h=visit?.historique||[];
    return topbar("Historique DUERP",h.length+" version(s)",true)+`
    <div class="screen">
      ${h.length===0?empty("🕓","Aucune version. Générez le premier dossier depuis le Bilan."):""}
      ${h.slice().reverse().map(v=>`<div class="card" style="margin-bottom:10px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <div style="font-weight:800;font-size:15px;">Version v${v.numero}</div>
          <span class="badge badge-navy">v${v.numero}</span>
        </div>
        <div style="font-size:12.5px;color:var(--grey-text);">${fmtDate(v.date)} — ${v.auteur}</div>
        <div style="font-size:12.5px;margin-top:4px;">${v.motif}</div>
        <div style="font-size:11.5px;color:var(--grey-text);margin-top:4px;">${v.resume||""}</div>
      </div>`).join("")}
    </div>`;
  }

  return { login, dashboard, clientsList, clientDetail, nouveauClient, catalogue, devisList, nouveauDevis, devisDetail, facturesList, factureDetail, choixMetier, choixBlocs, choixClient, populationBlocs, visiteBlocs, visiteBlocDetail, photosGalerie, risquesListe, validation, upsell, relances, parametres, registreScreen, historiqueScreen };
})();
