/* PF24 V3 — Couche de stockage : localStorage + IndexedDB (photos) */
const PF24_DB = (() => {
  const LS = { C:"pf24_clients", V:"pf24_visits", D:"pf24_devis", F:"pf24_factures",
    SET:"pf24_settings", CONS:"pf24_consultant", DC:"pf24_dv_ctr", FC:"pf24_fa_ctr" };
  const IDB_NAME="pf24_v3_photos", IDB_ST="photos";
  let _idb=null;

  function _open(){
    return new Promise((res,rej)=>{
      if(_idb) return res(_idb);
      const r=indexedDB.open(IDB_NAME,1);
      r.onupgradeneeded=e=>{ if(!e.target.result.objectStoreNames.contains(IDB_ST)) e.target.result.createObjectStore(IDB_ST,{keyPath:"id"}); };
      r.onsuccess=e=>{ _idb=e.target.result; res(_idb); };
      r.onerror=e=>rej(e);
    });
  }
  async function savePhoto(id,dataUrl){ const db=await _open(); return new Promise((res,rej)=>{ const tx=db.transaction(IDB_ST,"readwrite"); tx.objectStore(IDB_ST).put({id,dataUrl}); tx.oncomplete=()=>res(id); tx.onerror=rej; }); }
  async function getPhoto(id){ const db=await _open(); return new Promise((res,rej)=>{ const r=db.transaction(IDB_ST,"readonly").objectStore(IDB_ST).get(id); r.onsuccess=()=>res(r.result?.dataUrl||null); r.onerror=rej; }); }
  async function deletePhoto(id){ const db=await _open(); return new Promise((res,rej)=>{ const tx=db.transaction(IDB_ST,"readwrite"); tx.objectStore(IDB_ST).delete(id); tx.oncomplete=res; tx.onerror=rej; }); }

  /* ---- helpers ---- */
  function _get(key){ return JSON.parse(localStorage.getItem(key)||"[]"); }
  function _set(key,val){ localStorage.setItem(key,JSON.stringify(val)); }
  function uid(p){ return p+"_"+Date.now().toString(36)+Math.random().toString(36).slice(2,6); }

  /* ---- Consultant profile ---- */
  const CONS_DEFAULT={nom:"",fonction:"Conseil en Qualité, Sécurité et Environnement",piedPage:"",activite:"Conseil en Qualité, Sécurité et Environnement",siret:"",adresse:"",telephone:"",email:""};
  function getConsultant(){ return JSON.parse(localStorage.getItem(LS.CONS)||JSON.stringify(CONS_DEFAULT)); }
  function saveConsultant(c){ localStorage.setItem(LS.CONS,JSON.stringify(c)); }

  /* ---- Auth ---- */
  function checkAuth(){ return sessionStorage.getItem("pf24_auth")==="1"; }
  function login(pwd){ const stored=localStorage.getItem("pf24_pwd")||btoa("pf24"); if(btoa(pwd)===stored){sessionStorage.setItem("pf24_auth","1");return true;} return false; }
  function logout(){ sessionStorage.removeItem("pf24_auth"); }
  function changePwd(oldPwd,newPwd){ const stored=localStorage.getItem("pf24_pwd")||btoa("pf24"); if(btoa(oldPwd)!==stored)return false; localStorage.setItem("pf24_pwd",btoa(newPwd)); return true; }

  /* ---- Clients ---- */
  function getClients(){ return _get(LS.C); }
  function getClient(id){ return getClients().find(c=>c.id===id)||null; }
  function saveClient(c){ c.updatedAt=new Date().toISOString(); const list=getClients(); const i=list.findIndex(x=>x.id===c.id); if(i>=0)list[i]=c; else list.push(c); _set(LS.C,list); return c; }
  function deleteClient(id){ _set(LS.C,getClients().filter(c=>c.id!==id)); getVisits().filter(v=>v.clientId===id).forEach(v=>deleteVisit(v.id)); _set(LS.D,getDevis().filter(d=>d.clientId!==id)); _set(LS.F,getFactures().filter(f=>f.clientId!==id)); }
  function updateClientRelance(clientId, prochainMaj){ const c=getClient(clientId); if(c){ c.prochainMaj=prochainMaj; saveClient(c); } }

  /* ---- Visites ---- */
  function getVisits(){ return _get(LS.V); }
  function getVisit(id){ return getVisits().find(v=>v.id===id)||null; }
  function saveVisit(v){ v.updatedAt=new Date().toISOString(); const list=getVisits(); const i=list.findIndex(x=>x.id===v.id); if(i>=0)list[i]=v; else list.push(v); _set(LS.V,list); return v; }
  function deleteVisit(id){ _set(LS.V,getVisits().filter(v=>v.id!==id)); }
  function getVisitsForClient(clientId){ return getVisits().filter(v=>v.clientId===clientId); }

  /* ---- Numérotation ---- */
  function nextNum(lsKey, prefix){ const yr=new Date().getFullYear(); const n=(Number(localStorage.getItem(lsKey)||"0"))+1; localStorage.setItem(lsKey,String(n)); return `${prefix}-${yr}-${String(n).padStart(3,"0")}`; }
  function nextDevisNum(){ return nextNum(LS.DC,"DV"); }
  function nextFactureNum(){ return nextNum(LS.FC,"FA"); }

  /* ---- Devis ---- */
  function getDevis(){ return _get(LS.D); }
  function getDevisById(id){ return getDevis().find(d=>d.id===id)||null; }
  function getDevisForClient(clientId){ return getDevis().filter(d=>d.clientId===clientId); }
  function saveDevis(d){ d.updatedAt=new Date().toISOString(); const list=getDevis(); const i=list.findIndex(x=>x.id===d.id); if(i>=0)list[i]=d; else list.push(d); _set(LS.D,list); return d; }
  function deleteDevisById(id){ _set(LS.D,getDevis().filter(d=>d.id!==id)); }
  function createDevis(clientId, lignes, meta={}){
    const d={ id:uid("dv"), numero:nextDevisNum(), clientId, date:new Date().toISOString(),
      validite:30, statut:"brouillon", lignes, total:lignes.reduce((s,l)=>s+l.total,0),
      commentaire:"", metierId:meta.metierId||"", effectif:meta.effectif||0,
      complexite:meta.complexite||"simple", createdAt:new Date().toISOString() };
    return saveDevis(d);
  }

  /* ---- Factures ---- */
  function getFactures(){ return _get(LS.F); }
  function getFactureById(id){ return getFactures().find(f=>f.id===id)||null; }
  function getFacturesForClient(clientId){ return getFactures().filter(f=>f.clientId===clientId); }
  function saveFacture(f){ f.updatedAt=new Date().toISOString(); const list=getFactures(); const i=list.findIndex(x=>x.id===f.id); if(i>=0)list[i]=f; else list.push(f); _set(LS.F,list); return f; }
  function createFactureFromDevis(devis){ const date=new Date(); const echeance=new Date(date); echeance.setDate(echeance.getDate()+30);
    const f={ id:uid("fa"), numero:nextFactureNum(), devisId:devis.id, clientId:devis.clientId,
      date:date.toISOString(), dateEcheance:echeance.toISOString(), statut:"brouillon",
      lignes:JSON.parse(JSON.stringify(devis.lignes)), total:devis.total, acompte:0, solde:devis.total,
      commentaire:"", createdAt:date.toISOString() };
    return saveFacture(f);
  }
  function deleteFactureById(id){ _set(LS.F,getFactures().filter(f=>f.id!==id)); }

  /* ---- Dashboard stats ---- */
  function getDashboardStats(){
    const clients=getClients(), devis=getDevis(), factures=getFactures(), visites=getVisits();
    const now=Date.now(), in60=now+60*24*60*60*1000;
    const caDevis=devis.filter(d=>d.statut==="accepte").reduce((s,d)=>s+d.total,0);
    const caFact=factures.filter(f=>f.statut==="payee").reduce((s,f)=>s+f.total,0);
    return {
      totalClients:clients.length,
      prospects:clients.filter(c=>c.statut==="prospect").length,
      devisEnAttente:devis.filter(d=>d.statut==="envoye").length,
      missionsEnCours:visites.filter(v=>v.statut==="en_cours").length,
      facturesAEnvoyer:factures.filter(f=>f.statut==="brouillon").length,
      caEstime:caDevis+caFact,
      relancesUrgentes:clients.filter(c=>c.prochainMaj&&new Date(c.prochainMaj).getTime()<=in60).length,
    };
  }

  /* ---- Relances ---- */
  function getRelances(){ const now=Date.now(); const in90=now+90*24*60*60*1000;
    return getClients().filter(c=>c.prochainMaj).map(c=>{ const d=new Date(c.prochainMaj).getTime(); const diff=Math.round((d-now)/(24*60*60*1000)); return {client:c,diff,urgence:d<now?"depassee":d<now+30*24*60*60*1000?"critique":d<now+60*24*60*60*1000?"warn":"ok"}; }).filter(r=>new Date(r.client.prochainMaj).getTime()<=in90).sort((a,b)=>a.diff-b.diff); }

  /* ---- Export / Import ---- */
  function exportAll(){ return JSON.stringify({clients:getClients(),visites:getVisits(),devis:getDevis(),factures:getFactures(),consultant:getConsultant(),exportedAt:new Date().toISOString(),app:"PF24 V3"},null,2); }
  /* Fusion sans doublons : par id, la version la plus récente (updatedAt) est conservée */
  function _mergeById(localArr, impArr){
    const map = new Map((localArr||[]).map(x=>[x.id,x]));
    (impArr||[]).forEach(x=>{
      const cur = map.get(x.id);
      if(!cur){ map.set(x.id,x); return; }
      const a = new Date(cur.updatedAt||cur.date||0), b = new Date(x.updatedAt||x.date||0);
      if(b>a) map.set(x.id,x);
    });
    return Array.from(map.values());
  }
  /* Journal des générations (aucune version écrasée, plafond 200) */
  function getGenerations(){ try{return JSON.parse(localStorage.getItem("pf24_generations")||"[]")}catch(e){return[]} }
  function logGeneration(entry){
    const g=getGenerations(); const now=new Date();
    g.unshift({ id:uid("gen"), date:now.toLocaleDateString("fr-FR"), heure:now.toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}), ...entry });
    localStorage.setItem("pf24_generations", JSON.stringify(g.slice(0,200)));
  }
  function importAll(json){ const d=JSON.parse(json);
    if(d.clients) _set(LS.C,_mergeById(getClients(),d.clients));
    if(d.visites) _set(LS.V,_mergeById(getVisits(),d.visites));
    if(d.devis)   _set(LS.D,_mergeById(getDevis(),d.devis));
    if(d.factures)_set(LS.F,_mergeById(getFactures(),d.factures));
    if(d.consultant) saveConsultant(d.consultant);
  }

  return {
    savePhoto,getPhoto,deletePhoto,uid,
    getConsultant,saveConsultant,
    checkAuth,login,logout,changePwd,
    getClients,getClient,saveClient,deleteClient,updateClientRelance,
    getVisits,getVisit,saveVisit,deleteVisit,getVisitsForClient,
    getDevis,getDevisById,getDevisForClient,saveDevis,createDevis,deleteDevisById,
    getFactures,getFactureById,getFacturesForClient,saveFacture,createFactureFromDevis,deleteFactureById,
    getDashboardStats,getRelances,
    nextDevisNum,nextFactureNum,
    exportAll,importAll, getGenerations, logGeneration };
})();
