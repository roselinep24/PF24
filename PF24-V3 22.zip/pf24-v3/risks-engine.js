/* PF24 V3 — Moteur de génération des risques */
const PF24_ENGINE = (() => {

  function ajusterProba(base, maitrise){
    if(maitrise==="insuffisant") return Math.min(4,base+1);
    if(maitrise==="bon") return Math.max(1,base-1);
    return base;
  }
  function niveau(g,p){ return g*p; }
  function priorite(n){ return n>=12?"Critique":n>=6?"Élevée":"Modérée"; }
  function couleur(n){ return n>=12?"red":n>=6?"orange":"green"; }

  function genererRisques(visit){
    const risques=[], actions=[];
    let rc=1, ac=1;

    for(const blocId of Object.keys(visit.blocs||{})){
      const blocState=visit.blocs[blocId];
      const blocNom=BLOCS[blocId]?BLOCS[blocId].nom:blocId;

      for(const objNom of Object.keys(blocState.objets||{})){
        const obj=blocState.objets[objNom];
        if(obj.statut!=="present") continue;
        const regle=REGLES_OBJETS[objNom];
        if(!regle) continue;

        regle.risques.forEach(r=>{
          const pInitial=r.probabilite;
          const pResiduel=ajusterProba(r.probabilite,obj.maitrise);
          const nInitial=niveau(r.gravite,pInitial);
          const nResiduel=niveau(r.gravite,pResiduel);
          risques.push({ id:"R"+String(rc++).padStart(3,"0"), unite:blocNom, objet:objNom,
            danger:r.danger, situation:r.situation, dommages:r.dommages,
            mesuresExistantes:obj.observation||"—", maitrise:obj.maitrise||"—",
            gravite:r.gravite,
            probabiliteInitiale:pInitial, niveauInitial:nInitial,
            probabilite:pResiduel, niveau:nResiduel,
            priorite:priorite(nResiduel), couleur:couleur(nResiduel),
            population:visit.population?.[blocId]||null, type:regle.type||"obligatoire" });
        });

        regle.actions.forEach(a=>{
          const nRef=regle.risques.length?niveau(regle.risques[0].gravite,ajusterProba(regle.risques[0].probabilite,obj.maitrise)):6;
          actions.push({ id:"A"+String(ac++).padStart(3,"0"), action:a,
            risqueAssocie:regle.risques[0]?.danger||objNom,
            priorite:priorite(nRef), responsable:"Gérant",
            delai:nRef>=12?"2 semaines":nRef>=6?"1 mois":"2 mois",
            cout:"Variable", preuve:"Attestation / facture / photo", dateCloture:"",
            commentaire:"", photoId:null, statut:"À faire", bloc:blocNom });
        });
      }
    }

    /* ====== ATEX : secteurs à risque explosion ====== */
    if(typeof SECTEURS_ATEX !== 'undefined' && SECTEURS_ATEX.includes(visit.metierId)){
      const hasAtexObj = Object.values(visit.blocs||{}).some(b=>
        Object.entries(b.objets||{}).some(([k,o])=>
          o.statut==='present' && OBJETS_ATEX && OBJETS_ATEX.some(atx=>k.includes(atx.split(' ')[0]))));
      if(hasAtexObj){
        const nAtex=niveau(4,1);
        risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — ATEX",
          objet:"Risque explosion",danger:"ATEX - Atmosphere Explosive",
          situation:"Poussières ou gaz inflammables susceptibles de former une atmosphère explosive",
          dommages:"Explosion, brûlures graves, décès",mesuresExistantes:"À évaluer",maitrise:"—",
          gravite:4,probabiliteInitiale:1,niveauInitial:nAtex,probabilite:1,niveau:nAtex,
          priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
        actions.push({id:"A"+String(ac++).padStart(3,"0"),
          action:"Faire réaliser une évaluation ATEX par un expert certifié (Directive 1999/92/CE, art. R4227-42 CT) — Classer les zones et utiliser du matériel certifié",
          risqueAssocie:"ATEX",priorite:"Critique",responsable:"Employeur + Expert ATEX",
          delai:"1 mois",cout:"Variable (500–2000€)",preuve:"Document de protection contre les explosions (DPCE)",
          dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — ATEX"});
      }
    }

    /* ====== TMS : checklist simplifiée INRS ====== */
    if(typeof CHECKLIST_TMS !== 'undefined'){
      const hasManutention = Object.values(visit.blocs||{}).some(b=>
        Object.entries(b.objets||{}).some(([k,o])=>o.statut==='present' && /manut|charge|diable|transpalette|levage/i.test(k)));
      const hasMachines = Object.values(visit.blocs||{}).some(b=>
        Object.entries(b.objets||{}).some(([k,o])=>o.statut==='present' && /machine|outil|pétrin|trancheuse|laminoir/i.test(k)));
      if(hasManutention || hasMachines){
        const nTMS=niveau(2,3);
        CHECKLIST_TMS.slice(0,3).forEach(item=>{
          risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — TMS",
            objet:"Troubles Musculo-Squelettiques",danger:"TMS - "+item.question.split("?")[0].slice(0,60).split('?')[0].replace(/^Des salariés /,'').slice(0,60),
            situation:item.question,dommages:item.risque,
            mesuresExistantes:"Évaluation à confirmer et actualiser lors des échanges avec les salariés, le médecin du travail et lors de la mise à jour du DUERP",maitrise:"—",
            gravite:2,probabiliteInitiale:3,niveauInitial:nTMS,probabilite:3,niveau:nTMS,
            priorite:"Élevée",couleur:"orange",transverse:true,type:"inrs",
            baseLegale:item.base});
          actions.push({id:"A"+String(ac++).padStart(3,"0"),action:item.action,
            risqueAssocie:"TMS",priorite:"Élevée",responsable:"Employeur + Médecin du travail",
            delai:"3 mois",cout:"Faible à moyen",preuve:"Évaluation ergonomique / attestation formation",
            dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — TMS"});
        });
      }
    }

    /* ====== CMR : vérification si produits chimiques présents ====== */
    if(typeof CMR_OBLIGATIONS !== 'undefined'){
      const hasCMR = Object.values(visit.blocs||{}).some(b=>
        Object.entries(b.objets||{}).some(([k,o])=>o.statut==='present' && /CMR|chimique|solvant|décolorant|colorant|encre/i.test(k)));
      if(hasCMR){
        const nCMR=niveau(4,1);
        risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — CMR",
          objet:"Agents CMR",danger:"Exposition a des agents Cancerogenes, Mutagenes, Reprotoxiques (CMR)",
          situation:"Produits chimiques présents susceptibles d'être classés CMR",
          dommages:"Cancer professionnel, atteinte à la reproduction, mutation génétique",
          mesuresExistantes:"Vérifier les FDS de chaque produit — rubrique 11 (toxicologie)",
          maitrise:"—",gravite:4,probabiliteInitiale:1,niveauInitial:nCMR,probabilite:1,niveau:nCMR,
          priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
        CMR_OBLIGATIONS.slice(0,4).forEach(obl=>{
          actions.push({id:"A"+String(ac++).padStart(3,"0"),action:obl,
            risqueAssocie:"Agents CMR",priorite:"Critique",responsable:"Employeur",
            delai:"1 mois",cout:"Variable",preuve:"Registre d'exposition + FDS",
            dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — CMR"});
        });
      }
    }

    /* ====== Risques transverses population ======*/
    const popG=popGlobale(visit);
    /* Module RPS — 6 axes Gollac (rapport DARES 2011) */
    const popG2 = popGlobale(visit);
    if(popG2.salaries > 0) {
      const rpsAxes = [
        {axe:"Intensité du travail",desc:"Charge de travail élevée, rythme soutenu, interruptions fréquentes",action:"Analyser la charge de travail en équipe, mettre en place des pauses réglementées"},
        {axe:"Exigences émotionnelles",desc:"Contact avec le public, situations conflictuelles, mort/maladie (médical)",action:"Former à la gestion des situations difficiles, prévoir des temps d'échange en équipe"},
        {axe:"Manque d'autonomie",desc:"Peu de marge de manœuvre dans l'organisation du travail",action:"Favoriser l'autonomie dans les tâches et la prise de décision"},
        {axe:"Rapports sociaux dégradés",desc:"Relations tendues avec la hiérarchie ou les collègues",action:"Mettre en place des entretiens réguliers, clarifier les rôles de chacun"},
        {axe:"Conflits de valeurs",desc:"Contradiction entre les valeurs personnelles et les exigences du travail",action:"Ouvrir des espaces de dialogue sur le sens du travail"},
        {axe:"Insécurité de la situation",desc:"Incertitude sur l'emploi, changements fréquents d'organisation",action:"Communiquer clairement sur les évolutions, associer les salariés aux changements"},
      ];
      const nRPS = 4; // G×P = 2×2 par défaut RPS
      rpsAxes.forEach(axe => {
        risques.push({
          id:"R"+String(rc++).padStart(3,"0"), unite:"Transverse — RPS",
          objet:"Risques psychosociaux", danger:"RPS - "+axe.axe,
          situation:axe.desc,
          dommages:"Épuisement professionnel, troubles anxieux, dépression",
          mesuresExistantes:"Évaluation à confirmer et actualiser lors des échanges avec les salariés et lors de la mise à jour du DUERP",
          maitrise:"À évaluer",
          gravite:2, probabiliteInitiale:2, niveauInitial:nRPS,
          probabilite:2, niveau:nRPS, priorite:"Élevée", couleur:"orange",
          transverse:true, type:"inrs", axeGollac:axe.axe
        });
        actions.push({
          id:"A"+String(ac++).padStart(3,"0"),
          action:axe.action,
          risqueAssocie:"RPS - "+axe.axe,
          priorite:"Élevée", responsable:"Direction",
          delai:"3 mois", cout:"Faible à moyen",
          preuve:"Compte-rendu de réunion / attestation formation",
          dateCloture:"", commentaire:"", photoId:null,
          statut:"À faire", bloc:"Transverse — RPS"
        });
      });
    }

    RISQUES_TRANSVERSES.forEach(rt=>{
      if(!rt.condition(popG)) return;
      const n=niveau(rt.gravite,rt.probabilite);
      risques.push({ id:"R"+String(rc++).padStart(3,"0"), unite:"Transverse", objet:rt.nom,
        danger:rt.nom, situation:rt.situation, dommages:rt.dommages, mesuresExistantes:"—",
        maitrise:"—", gravite:rt.gravite, probabilite:rt.probabilite, niveau:n,
        priorite:priorite(n), couleur:couleur(n), transverse:true, type:rt.type });
      rt.actions.forEach(a=>{
        actions.push({ id:"A"+String(ac++).padStart(3,"0"), action:a, risqueAssocie:rt.nom,
          priorite:priorite(n), responsable:"Gérant", delai:n>=12?"2 semaines":"1 mois",
          cout:"Variable", preuve:"Document interne", dateCloture:"", commentaire:"",
          photoId:null, statut:"À faire", bloc:"Transverse" });
      });
    });

    // Déduplication : un même danger dans la même unité n'apparaît qu'une fois
    const seen = new Set();
    const risquesDedup = risques.filter(r => {
      const key = r.unite + '|' + r.danger;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    });

    // Hiérarchie des mesures (Art. L4121-2 CT) : réordonner les actions
    const ordreHierarchie = [
      // 1. Suppression/substitution
      r => /supprimer|supprim|élimin|substitu/i.test(r.action),
      // 2. Protection collective
      r => /collectiv|balisag|signali|garde-corps|protecteur|capotage|extract/i.test(r.action),
      // 3. Organisation
      r => /organis|procédure|rotation|planif|limit/i.test(r.action),
      // 4. Formation/information
      r => /former|form|informer|afficher|sensibilis|FDS/i.test(r.action),
      // 5. EPI en dernier
      r => /gant|EPI|masque|casque|chaussure|harnais|lunette|protecteur auditif/i.test(r.action),
    ];
    const actionsOrdonnees = [...actions].sort((a, b) => {
      const rankA = ordreHierarchie.findIndex(fn => fn(a));
      const rankB = ordreHierarchie.findIndex(fn => fn(b));
      return (rankA === -1 ? 99 : rankA) - (rankB === -1 ? 99 : rankB);
    });

    // Vérification travaux interdits si jeunes ou femmes enceintes
    const pop = popGlobale(visit);
    const alertesTravaux = [];
    if (pop.jeunesTravailleurs) {
      const objetsPresents = Object.values(visit.blocs||{})
        .flatMap(b => Object.entries(b.objets||{})
        .filter(([,o]) => o.statut === 'present').map(([k]) => k));
      const risquesCMR = objetsPresents.some(o => /chimique|CMR|solvant/i.test(o));
      const risquesElec = objetsPresents.some(o => /électrique|tableau/i.test(o));
      const risquesLevage = objetsPresents.some(o => /chariot|pont élévateur/i.test(o));
      if (risquesCMR) alertesTravaux.push("! JEUNES TRAVAILLEURS — Vérifier l'absence d'exposition à des agents CMR (interdit aux -18 ans, art. D4153-15 CT)");
      if (risquesElec) alertesTravaux.push("! JEUNES TRAVAILLEURS — Habilitation électrique requise pour travaux sur installations électriques");
      if (risquesLevage) alertesTravaux.push("! JEUNES TRAVAILLEURS — Conduite de chariots élévateurs interdite aux -18 ans sans dérogation DREETS");
    }

    /* ====== RISQUES TRANSVERSES MÉTIERS (v4.4) ====== */
    const mId = visit.metierId||"";
    const isAlimentaire = /boulang|patiss|bouch|traiteur|restaur|fromag|poisson|primeur|glacier|snack|pizzeria|creperie/i.test(mId);
    const blocsSel = visit.blocsSelectionnes||[];
    const popM = popGlobale(visit);

    // Travail de nuit / horaires décalés (boulangerie, boucherie…)
    if(isAlimentaire && popM.salaries>0){
      const nN=niveau(2,3);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Organisation",
        objet:"Horaires de travail",danger:"Travail de nuit / horaires décalés",
        situation:"Prise de poste avant 6h ou travail entre 21h et 6h (art. L3122-2 CT)",
        dommages:"Troubles du sommeil, fatigue chronique, risque cardiovasculaire accru, désocialisation",
        mesuresExistantes:"Évaluation à confirmer et actualiser lors des échanges avec les salariés et lors de la mise à jour du DUERP",
        maitrise:"—",gravite:2,probabiliteInitiale:3,niveauInitial:nN,probabilite:3,niveau:nN,
        priorite:"Élevée",couleur:"orange",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Organiser le suivi individuel adapté des travailleurs de nuit par le SPST (visite d'information et de prévention avant affectation — art. L3122-11 CT) et limiter les horaires isolés",
        risqueAssocie:"Travail de nuit",priorite:"Élevée",responsable:"Employeur + SPST",
        delai:"3 mois",cout:"Inclus cotisation SPST",preuve:"Attestation de suivi SPST",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — Organisation"});
      // Travail isolé associé (fournil de nuit)
      const nIso=niveau(3,2);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Organisation",
        objet:"Travail isolé",danger:"Travail isolé (production de nuit / tôt le matin)",
        situation:"Salarié seul au fournil ou en production en dehors des heures d'ouverture",
        dommages:"Retard de secours en cas d'accident ou de malaise",
        mesuresExistantes:"Évaluation à confirmer et actualiser lors des échanges avec les salariés et lors de la mise à jour du DUERP",
        maitrise:"—",gravite:3,probabiliteInitiale:2,niveauInitial:nIso,probabilite:2,niveau:nIso,
        priorite:"Élevée",couleur:"orange",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Mettre en place un moyen d'alerte pour le travailleur isolé : DATI, téléphone à portée permanente ou procédure d'appel programmé",
        risqueAssocie:"Travail isolé",priorite:"Élevée",responsable:"Employeur",
        delai:"1 mois",cout:"0-200€",preuve:"Dispositif en place / procédure écrite",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — Organisation"});
    }

    // Incivilités / agressions clientèle
    if(popM.salaries>0 && (blocsSel.includes("accueil")||blocsSel.includes("vente"))){
      const nI2=niveau(2,3);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — RPS",
        objet:"Relation clientèle",danger:"Incivilités et agressions verbales",
        situation:"Contact direct avec le public (vente, accueil, réclamations)",
        dommages:"Stress, atteinte psychologique, risque d'agression physique",
        mesuresExistantes:"Évaluation à confirmer et actualiser lors des échanges avec les salariés et lors de la mise à jour du DUERP",
        maitrise:"—",gravite:2,probabiliteInitiale:3,niveauInitial:nI2,probabilite:3,niveau:nI2,
        priorite:"Élevée",couleur:"orange",transverse:true,type:"inrs"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Définir une procédure en cas d'incivilité ou d'agression (retrait, alerte, dépôt de plainte), en informer les salariés et afficher les consignes",
        risqueAssocie:"Incivilités clientèle",priorite:"Élevée",responsable:"Employeur",
        delai:"3 mois",cout:"Faible",preuve:"Procédure écrite / affichage",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — RPS"});
    }

    // Risque routier (livraisons hors BTP — le BTP l'a déjà)
    const dejaBTP = ['electricien','plombier','chauffagiste','menuisier','serrurier','peintre','macon','couvreur','charpentier','couvreur_zinc','terrassier','carreleur','plaquiste','canalisateur','conducteur_tp','gros_oeuvre'].includes(mId);
    if(!dejaBTP && (blocsSel.includes("livraison")||blocsSel.includes("vehicules"))){
      const nR2=niveau(4,2);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Déplacements",
        objet:"Risque routier professionnel",danger:"Accident de la route (livraisons / déplacements)",
        situation:"Déplacements professionnels réguliers (livraisons, approvisionnements)",
        dommages:"Accident grave, décès — 1ère cause d'accidents mortels du travail",
        mesuresExistantes:"À évaluer",maitrise:"—",
        gravite:4,probabiliteInitiale:2,niveauInitial:nR2,probabilite:2,niveau:nR2,
        priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Formaliser une politique de prévention du risque routier : entretien des véhicules, interdiction du téléphone au volant, organisation des tournées sans pression horaire excessive",
        risqueAssocie:"Risque routier",priorite:"Critique",responsable:"Employeur",
        delai:"1 mois",cout:"Faible",preuve:"Note interne signée",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — Déplacements"});
    }

    // Ambiance thermique chaude (fournil / cuisson)
    if(isAlimentaire){
      const nT=niveau(2,3);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Ambiances",
        objet:"Ambiance thermique",danger:"Chaleur (fournil, zone de cuisson)",
        situation:"Travail prolongé à proximité des fours en période de production ou de forte chaleur",
        dommages:"Fatigue, déshydratation, coup de chaleur",
        mesuresExistantes:"À évaluer (ventilation, accès à l'eau, organisation des cuissons)",maitrise:"—",
        gravite:2,probabiliteInitiale:3,niveauInitial:nT,probabilite:3,niveau:nT,
        priorite:"Élevée",couleur:"orange",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Mettre à disposition de l'eau fraîche en permanence (art. R4225-2 CT), ventiler la zone de cuisson et organiser des pauses en période de forte chaleur",
        risqueAssocie:"Chaleur",priorite:"Élevée",responsable:"Employeur",
        delai:"3 mois",cout:"Faible",preuve:"Point d'eau accessible / consigne affichée",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — Ambiances"});
    }

    // Risque biologique (denrées altérées, moisissures — métiers alimentaires)
    if(isAlimentaire){
      const nB=niveau(2,2);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Hygiène",
        objet:"Agents biologiques",danger:"Risque biologique (moisissures, denrées altérées)",
        situation:"Manipulation de denrées périssables, déchets organiques, surfaces humides",
        dommages:"Infections, mycoses, réactions allergiques (agents biologiques groupes 1-2, art. R4421-1 CT)",
        mesuresExistantes:"À évaluer (plan de nettoyage, contrôle des DLC, gestion des déchets)",maitrise:"—",
        gravite:2,probabiliteInitiale:2,niveauInitial:nB,probabilite:2,niveau:nB,
        priorite:"Modérée",couleur:"green",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Formaliser le plan de nettoyage-désinfection, le contrôle des DLC/DDM et l'évacuation quotidienne des déchets organiques ; mettre à disposition des gants adaptés",
        risqueAssocie:"Risque biologique",priorite:"Modérée",responsable:"Employeur",
        delai:"3 mois",cout:"Faible",preuve:"Plan de nettoyage affiché",
        dateCloture:"",commentaire:"",photoId:null,statut:"À faire",bloc:"Transverse — Hygiène"});
    }

    /* ====== BTP / CHANTIER — risques transverses ====== */
    const isBTP = ['electricien','plombier','chauffagiste','menuisier','serrurier','peintre',
      'macon','couvreur','charpentier','couvreur_zinc','terrassier','carreleur','plaquiste',
      'canalisateur','conducteur_tp','gros_oeuvre'].includes(visit.metierId);

    if(isBTP){
      const hasChantier = (visit.blocsSelectionnes||[]).includes('chantier');

      // Risque routier professionnel (déplacements chantier quotidiens)
      const nRoute=niveau(4,2);
      risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Déplacements",
        objet:"Risque routier professionnel",
        danger:"Accident de la route lors des déplacements professionnels",
        situation:"Déplacements quotidiens vers les chantiers sans politique de prévention routière formalisée",
        dommages:"Accident grave, décès — 1ère cause d'accidents mortels du travail",
        mesuresExistantes:"A évaluer",maitrise:"—",
        gravite:4,probabiliteInitiale:2,niveauInitial:nRoute,probabilite:2,niveau:nRoute,
        priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
      actions.push({id:"A"+String(ac++).padStart(3,"0"),
        action:"Mettre en place une politique de prévention du risque routier : contrôle des véhicules, interdiction du téléphone au volant, définition des itinéraires, respect des temps de conduite",
        risqueAssocie:"Risque routier",priorite:"Critique",responsable:"Dirigeant",
        delai:"1 mois",cout:"Faible",preuve:"Note interne / charte sécurité conduite",
        dateCloture:"",commentaire:"",photoId:null,statut:"A faire",bloc:"Transverse — Déplacements"});

      if(hasChantier){
        // Co-activité
        const nCo=niveau(4,2);
        risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Chantier",
          objet:"Coactivité",danger:"Accident par interférence entre entreprises",
          situation:"Chantiers avec plusieurs corps de métier sans coordination SPS",
          dommages:"Collision, chute d'objet, accident grave",
          mesuresExistantes:"A vérifier",maitrise:"—",
          gravite:4,probabiliteInitiale:2,niveauInitial:nCo,probabilite:2,niveau:nCo,
          priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
        actions.push({id:"A"+String(ac++).padStart(3,"0"),
          action:"Vérifier si l'opération nécessite un coordonnateur SPS (art. L4532-4 CT) et établir le plan de prévention ou PPSPS avant le démarrage",
          risqueAssocie:"Coactivité",priorite:"Critique",responsable:"Dirigeant",
          delai:"Avant démarrage",cout:"Variable",preuve:"Plan de prévention / PPSPS",
          dateCloture:"",commentaire:"",photoId:null,statut:"A faire",bloc:"Transverse — Chantier"});

        // Amiante si bâtiment avant 1997
        const nAmiante=niveau(4,2);
        risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Chantier",
          objet:"Amiante",danger:"Exposition aux fibres d'amiante",
          situation:"Intervention sur bâtiment construit avant 1997 sans diagnostic amiante préalable",
          dommages:"Mésothéliome, cancer broncho-pulmonaire — maladie professionnelle irréversible",
          mesuresExistantes:"Demander le DTA ou RAT avant intervention",maitrise:"—",
          gravite:4,probabiliteInitiale:2,niveauInitial:nAmiante,probabilite:2,niveau:nAmiante,
          priorite:"Critique",couleur:"red",transverse:true,type:"obligatoire"});
        actions.push({id:"A"+String(ac++).padStart(3,"0"),
          action:"Exiger le Dossier Technique Amiante (DTA) ou faire réaliser un Repérage Amiante avant Travaux (RAT) certifié COFRAC avant toute intervention sur bâtiment avant 1997 (art. R4412-97 CT)",
          risqueAssocie:"Amiante",priorite:"Critique",responsable:"Dirigeant",
          delai:"Avant chaque chantier",cout:"300-1500€",preuve:"DTA ou rapport RAT",
          dateCloture:"",commentaire:"",photoId:null,statut:"A faire",bloc:"Transverse — Chantier"});

        // Travail isolé chantier
        const nIsole=niveau(3,2);
        risques.push({id:"R"+String(rc++).padStart(3,"0"),unite:"Transverse — Chantier",
          objet:"Travail isolé",danger:"Retard de secours en cas d'accident",
          situation:"Compagnon travaillant seul sur un chantier sans moyen d'alerte",
          dommages:"Aggravation d'un accident faute de secours rapide",
          mesuresExistantes:"A vérifier",maitrise:"—",
          gravite:3,probabiliteInitiale:2,niveauInitial:nIsole,probabilite:2,niveau:nIsole,
          priorite:"Elevée",couleur:"orange",transverse:true,type:"obligatoire"});
        actions.push({id:"A"+String(ac++).padStart(3,"0"),
          action:"Equiper les compagnons travaillant seuls d'un DATI (Dispositif d'Alarme pour Travailleur Isolé) ou définir une procédure d'appel programmé",
          risqueAssocie:"Travail isolé",priorite:"Elevée",responsable:"Chef de chantier",
          delai:"1 mois",cout:"50-200€ par dispositif",preuve:"DATI ou procédure écrite",
          dateCloture:"",commentaire:"",photoId:null,statut:"A faire",bloc:"Transverse — Chantier"});
      }

      // Alertes travaux interdits si pertinentes
      const objetsPresents=Object.values(visit.blocs||{}).flatMap(b=>Object.keys(b.objets||{}).filter(k=>b.objets[k]?.statut==='present'));
      if(objetsPresents.some(o=>/amiante|amiantee/i.test(o)))
        alertesTravaux.push("AMIANTE — Toute intervention sur matériau amianté nécessite une certification SS3 ou SS4 (Décret 2012-639). Vérifier la certification de votre entreprise.");
      if(objetsPresents.some(o=>/silice|béton|granit/i.test(o)))
        alertesTravaux.push("SILICE — VLEP contraignante : 0,1 mg/m³ (art. R4412-149 CT). Mesure d'empoussièrement recommandée si exposition régulière.");
    }

        // Recalcul FINAL après les blocs métiers/BTP (sinon leurs risques étaient perdus)
        const seenF = new Set();
        const risquesFinal = risques.filter(r => {
          const k = r.unite + '|' + r.danger;
          if (seenF.has(k)) return false;
          seenF.add(k); return true;
        });
        const actionsFinal = [...actions].sort((a, b) => {
          const ra = ordreHierarchie.findIndex(fn => fn(a));
          const rb = ordreHierarchie.findIndex(fn => fn(b));
          return (ra === -1 ? 99 : ra) - (rb === -1 ? 99 : rb);
        });
        return {risques:risquesFinal, actions:actionsFinal, alertesTravaux};
  }

  function popGlobale(visit){
    const blocs=Object.values(visit.population||{});
    const a={salaries:0,hommes:0,femmes:0,apprentis:false,interimaires:false,
      jeunesTravailleurs:false,travailIsole:false,vulnerables:false,
      entreprisesExterieures:visit.entreprisesExterieures===true,
      teletravail:visit.teletravail===true,deplacements:visit.deplacements===true};
    blocs.forEach(p=>{
      a.salaries+=Number(p.exposes||0); a.hommes+=Number(p.hommes||0); a.femmes+=Number(p.femmes||0);
      if(p.apprentis) a.apprentis=true;
      if(p.interimaires) a.interimaires=true;
      if(p.jeunesTravailleurs) a.jeunesTravailleurs=true;
      if(p.travailIsole) a.travailIsole=true;
      if(p.vulnerables) a.vulnerables=true;
    });
    const client=PF24_DB.getClient(visit.clientId);
    if(client?.vulnerables) a.vulnerables=true;
    if(client?.apprentis) a.apprentis=true;
    if(client?.interimaires) a.interimaires=true;
    return a;
  }

  function calculerScore(visit){
    const {risques}=genererRisques(visit);
    if(!risques.length) return 100;
    const crit=risques.filter(r=>r.couleur==="red").length;
    const elev=risques.filter(r=>r.couleur==="orange").length;
    return Math.max(10,Math.min(100,Math.round(100-crit*8-elev*3)));
  }

  function calculerScoreConformite(visit, client){
    let tot=0, ok=0;
    ["nom","siret","activite","salaries","redacteur"].forEach(f=>{ tot++; if(client?.[f]) ok++; });
    tot++; if(Object.keys(visit.population||{}).length>0) ok++;
    tot++; if((visit.historique||[]).length>0) ok++;
    ["Extincteurs","Installation électrique","Trousse de secours","FDS"].forEach(item=>{
      tot++; if(visit.registre?.[item]?.statut) ok++;
    });
    return Math.max(0,Math.min(100,Math.round((ok/tot)*100)));
  }

  function top5(actions){ const o={Critique:0,Élevée:1,Modérée:2}; return [...actions].sort((a,b)=>o[a.priorite]-o[b.priorite]).slice(0,5); }

  function nouvelleVersion(visit, motif){
    visit.historique=visit.historique||[];
    const v={ numero:visit.historique.length+1, date:new Date().toISOString(),
      auteur:visit.redacteur||"Consultant PF24", motif:motif||(visit.historique.length?"Mise à jour":"Création initiale du DUERP"),
      resume:`${visit.historique.length?"Mise à jour":"Création"} — ${Object.keys(visit.blocs||{}).length} unité(s) évaluée(s).` };
    visit.historique.push(v); return v;
  }

  return { genererRisques, calculerScore, calculerScoreConformite, top5, nouvelleVersion, popGlobale };
})();
