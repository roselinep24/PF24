/* PF24 V3 — Base de données complète : 60 métiers, 35 blocs, catalogue, règles */


/* ============================================================
   SPRINT 4 — ATEX, TMS, CMR
   ============================================================ */

/* Secteurs concernés par le risque ATEX (Directive 1999/92/CE, art. R4227-42 CT) */
const SECTEURS_ATEX = ['boulangerie','garage','carrossier','pressing','blanchisserie','atelier_fab','imprimerie','laboratoire_metier'];

/* Objets déclenchant une évaluation ATEX */
const OBJETS_ATEX = ['Silo / doseur poudre','Bouteille de gaz GPL','Chargeur de batterie','Cage de gonflage','Produits chimiques'];

/* Checklist TMS simplifiée INRS (méthode RULA adaptée TPE) */
const CHECKLIST_TMS = [
  {id:"tms1", question:"Des salariés portent-ils des charges > 25 kg (hommes) ou > 15 kg (femmes) ?", base:"Norme NF X35-109 (recommandation) — limite absolue 55 kg : art. R4541-9 CT", risque:"Lombalgie, hernie discale", action:"Mettre à disposition une aide mécanique (diable, transpalette, lève-charge)"},
  {id:"tms2", question:"Des salariés répètent-ils le même geste > 4 fois par minute pendant plus de 2h ?", base:"INRS, méthode RULA", risque:"Tendinites, syndrome du canal carpien", action:"Varier les tâches, prévoir des rotations de poste"},
  {id:"tms3", question:"Des salariés travaillent-ils bras levés au-dessus des épaules régulièrement ?", base:"INRS ED 6094", risque:"Tendinite de l'épaule, coiffe des rotateurs", action:"Adapter la hauteur du poste, utiliser des outils adaptés"},
  {id:"tms4", question:"Des salariés restent-ils en position statique (debout ou assis) plus de 2h sans pause ?", base:"INRS, travaux debout", risque:"Lombalgies, varices, fatigue musculaire", action:"Prévoir des pauses actives, proposer un siège assis-debout"},
  {id:"tms5", question:"Des salariés utilisent-ils des outils vibrants (meuleuse, marteau-piqueur, etc.) ?", base:"Art. R4443-1 CT — valeurs d\u2019action : 0,5 m/s² corps entier / 2,5 m/s² mains-bras (art. R4443-2 CT)", risque:"Syndrome de Raynaud, TMS membres supérieurs", action:"Limiter la durée d'utilisation, choisir des outils à faibles vibrations, vérifier les valeurs d'action"},
  {id:"tms6", question:"Des salariés travaillent-ils en position accroupie ou agenouillée régulièrement ?", base:"INRS ED 6161", risque:"Bursite du genou, gonarthrose (maladie professionnelle)", action:"Fournir des genouillères ergonomiques, aménager le poste"},
];

/* Module CMR — vérification et traçabilité */
const CMR_CATEGORIES = {
  "1A": "Substance reconnue cancérogène — Interdite ou substituée en priorité absolue",
  "1B": "Substance présumée cancérogène — Substitution obligatoire (art. L4412-2 CT)",
  "2":  "Substance suspectée cancérogène — Mesures de protection renforcées",
};

const CMR_OBLIGATIONS = [
  "Rechercher activement la substitution du produit CMR (documenter la démarche)",
  "Tenir un registre d'exposition nominatif pour chaque salarié exposé",
  "Remettre une fiche individuelle d'exposition à chaque salarié (art. R4412-40 CT)",
  "Conservation du registre et des fiches : 40 ans",
  "Déclarer l'exposition à la CNAM si persistante (suivi post-exposition)",
  "Mesurer les concentrations atmosphériques (VLEP contraignantes ou indicatives)",
  "Informer le médecin du travail de toute exposition CMR",
];


/* ============================================================
   PLAN DE PRÉVENTION — Art. R4511-1 à R4515-11 CT
   Décret n°92-158 du 20 février 1992
   Arrêté du 19 mars 1993 (liste des travaux dangereux)
   ============================================================ */

/* Seuils déclenchant un plan de prévention ÉCRIT obligatoire */
const PDP_SEUILS = {
  duree: "Plan écrit obligatoire si le nombre total d'heures de travail prévisible ≥ 400 heures sur une période ≤ 12 mois (art. R4512-7 CT)",
  travaux_dangereux: "Plan écrit obligatoire quelle que soit la durée si les travaux figurent sur la liste des travaux dangereux (Arrêté du 19 mars 1993)",
};

/* Liste des TRAVAUX DANGEREUX — Arrêté du 19 mars 1993 (art. R4512-7 CT) */
const TRAVAUX_DANGEREUX_PDP = [
  "Travaux exposant aux rayonnements ionisants",
  "Travaux exposant à des substances explosives, comburantes, extrêmement ou facilement inflammables",
  "Travaux exposant à des agents chimiques dangereux CMR (cancérogènes, mutagènes, reprotoxiques)",
  "Travaux exposant à des agents biologiques pathogènes (groupes 2, 3, 4)",
  "Travaux effectués sur une installation classée soumise à plan d'opération interne (POI)",
  "Travaux de maintenance sur équipements de travail soumis à vérifications périodiques",
  "Travaux de transformation ou réparation d'appareils à pression de gaz ou de vapeur",
  "Travaux de maintenance sur installations à très haute ou très basse température",
  "Travaux comportant le recours à des ponts roulants, transstockeurs ou portiques",
  "Travaux exposant à un risque de noyade",
  "Travaux exposant à un risque d'ensevelissement",
  "Travaux de montage ou démontage d'éléments préfabriqués lourds",
  "Travaux de démolition",
  "Travaux dans ou sur des cuves, réservoirs, citernes, bassins",
  "Travaux en milieu confiné (puits, conduites, canalisations, égouts, espaces clos)",
  "Travaux comportant l'emploi d'explosifs",
  "Travaux du bâtiment/génie civil exposant à un risque de chute de hauteur > 3 mètres",
  "Travaux exposant à un risque électrique haute ou basse tension",
];

/* Sections obligatoires du Plan de Prévention (art. R4512-8 CT) */
const PDP_SECTIONS_OBLIGATOIRES = [
  "Définition des phases d'activité dangereuses et moyens de prévention spécifiques",
  "Adaptation des matériels, installations et dispositifs à la nature des opérations",
  "Instructions à donner aux travailleurs",
  "Organisation mise en place pour assurer les premiers secours en cas d'urgence",
  "Conditions de participation des salariés d'une entreprise aux travaux d'une autre",
];

/* Étapes obligatoires de la démarche Plan de Prévention */
const PDP_ETAPES = [
  {etape:"1. Inspection commune préalable",base:"Art. R4512-2 CT",desc:"Avant le début des travaux, l'entreprise utilisatrice organise une inspection commune des lieux avec l'entreprise extérieure. OBLIGATOIRE."},
  {etape:"2. Analyse des risques d'interférence",base:"Art. R4512-6 CT",desc:"Analyse conjointe des risques pouvant résulter de l'interférence entre les activités, installations et matériels."},
  {etape:"3. Rédaction du plan de prévention",base:"Art. R4512-7 CT",desc:"Établissement du plan par écrit (si seuils atteints) avant le début des travaux, arrêté en commun."},
  {etape:"4. Information des salariés",base:"Art. R4514-1 CT",desc:"L'entreprise extérieure informe ses salariés des dangers et des mesures de prévention."},
  {etape:"5. Suivi et mise à jour",base:"Art. R4513-1 à R4513-4 CT",desc:"Inspections et réunions périodiques de coordination pendant toute la durée des travaux."},
];

/* Protocole de sécurité — chargement/déchargement (Art. R4515-1 à R4515-11 CT) */
const PROTOCOLE_SECURITE_ITEMS = [
  "Consignes de sécurité (circulation, plan de circulation)",
  "Lieu de livraison ou de prise en charge",
  "Modalités d'accès et de stationnement aux postes de chargement/déchargement",
  "Matériels et engins spécifiques utilisés",
  "Moyens de secours en cas d'accident",
  "Identité du responsable désigné par l'entreprise d'accueil",
  "Nature et conditionnement de la marchandise",
  "Précautions ou sujétions particulières résultant de la nature des substances",
];


/* ============================================================
   EPI PAR MÉTIER — pré-remplissage des fiches de poste (v4.4)
   ============================================================ */
function getEPIPourMetier(mId){
  mId = mId||"";
  if(/boulang|patiss/i.test(mId)) return [
    {epi:"Chaussures de sécurité antidérapantes",norme:"EN ISO 20345 S2/S3 SRC",verif:"Remplacement si usure"},
    {epi:"Gants anti-chaleur (four, plaques)",norme:"EN 407",verif:"Avant chaque usage — remplacement si brûlé/percé"},
    {epi:"Gants anti-coupure (trancheuse, découpe)",norme:"EN 388 niveau ≥ 3",verif:"Avant chaque usage"},
    {epi:"Tenue professionnelle / tablier",norme:"—",verif:"Entretien régulier"},
    {epi:"Masque FFP2 si pesée/tamisage farine prolongé",norme:"EN 149",verif:"Usage unique"},
  ];
  if(/restaur|cuisin|snack|pizzeria|creperie|traiteur/i.test(mId)) return [
    {epi:"Chaussures de sécurité antidérapantes",norme:"EN ISO 20345 S2 SRC",verif:"Remplacement si usure"},
    {epi:"Gants anti-chaleur",norme:"EN 407",verif:"Avant chaque usage"},
    {epi:"Gants anti-coupure niveau 5",norme:"EN 388",verif:"Avant chaque usage"},
    {epi:"Tablier de protection",norme:"—",verif:"Entretien régulier"},
  ];
  if(/coiffure|estheti|barbier|onglerie/i.test(mId)) return [
    {epi:"Gants nitrile (colorations, produits chimiques)",norme:"EN 374",verif:"Usage unique"},
    {epi:"Tablier imperméable",norme:"—",verif:"Entretien régulier"},
    {epi:"Chaussures fermées antidérapantes",norme:"—",verif:"Remplacement si usure"},
  ];
  if(/garage|meca|carross/i.test(mId)) return [
    {epi:"Chaussures de sécurité",norme:"EN ISO 20345 S3",verif:"Remplacement si usure"},
    {epi:"Gants de mécanicien",norme:"EN 388",verif:"Avant chaque usage"},
    {epi:"Lunettes de protection",norme:"EN 166",verif:"Avant travaux avec projections"},
    {epi:"Protecteurs auditifs (outillage pneumatique)",norme:"EN 352",verif:"Si bruit > 80 dB(A)"},
    {epi:"Combinaison de travail",norme:"—",verif:"Entretien régulier"},
  ];
  if(/nettoyage|proprete/i.test(mId)) return [
    {epi:"Gants nitrile ou néoprène",norme:"EN 374",verif:"Avant chaque usage"},
    {epi:"Chaussures antidérapantes",norme:"EN ISO 20345 S2 SRC",verif:"Remplacement si usure"},
    {epi:"Lunettes de protection (transvasement)",norme:"EN 166",verif:"Avant chaque usage"},
  ];
  if(/electricien|plombier|chauffag|menuisier|serrurier|peintre|macon|couvreur|charpentier|terrassier|carreleur|plaquiste|canalisateur|conducteur_tp|gros_oeuvre/i.test(mId)) return [
    {epi:"Casque de chantier",norme:"EN 397",verif:"Remplacement après choc / 5 ans max"},
    {epi:"Chaussures de sécurité",norme:"EN ISO 20345 S3",verif:"Remplacement si usure"},
    {epi:"Gilet haute visibilité",norme:"EN ISO 20471 classe 2/3",verif:"Remplacement si délavé"},
    {epi:"Gants de manutention",norme:"EN 388",verif:"Avant chaque usage"},
    {epi:"Lunettes de protection",norme:"EN 166",verif:"Selon travaux"},
    {epi:"Protecteurs auditifs",norme:"EN 352",verif:"Si bruit > 80 dB(A)"},
  ];
  return [
    {epi:"Chaussures fermées antidérapantes",norme:"—",verif:"Remplacement si usure"},
    {epi:"Gants adaptés aux tâches identifiées",norme:"EN 388 / EN 374 selon risque",verif:"Avant chaque usage"},
  ];
}

/* ==================== CATALOGUE DES OFFRES ==================== */
const CATALOGUE = [
  { id:"essentiel", nom:"Pack Essentiel DUERP", prix:350, duree:"1 journée",
    desc:"Visite terrain, DUERP complet, PAPRIPACT priorisé, rapport de visite professionnel.",
    livrables:["DUERP par unité de travail","PAPRIPACT / plan d'actions","Rapport de visite","Synthèse dirigeant"],
    badge:"🏆 Le plus demandé" },
  { id:"conformite", nom:"Pack Conformité", prix:550, duree:"1–2 jours",
    desc:"Pack Essentiel + fiches de poste sécurité + registre sécurité simplifié.",
    livrables:["Tout Pack Essentiel","Fiches de poste sécurité","Registre sécurité simplifié","Score de conformité réglementaire"],
    badge:"✅ Conformité totale" },
  { id:"serenite", nom:"Pack Sérénité", prix:850, duree:"Sur mesure",
    desc:"Pack Conformité + accompagnement 6 mois + relance annuelle incluse.",
    livrables:["Tout Pack Conformité","Accompagnement plan d'actions (6 mois)","Relance annuelle automatique","Devis de mise à jour inclus"],
    badge:"⭐ Premium" },
  { id:"maj", nom:"Mise à jour annuelle", prix:250, duree:"½ journée",
    desc:"Mise à jour du DUERP existant avec nouvelle version tracée.",
    livrables:["Visite de mise à jour","Nouvelle version DUERP","PAPRIPACT mis à jour"],
    badge:"🔄 Renouvellement" },
  { id:"fiches", nom:"Fiches de poste sécurité", prix:150, duree:"Inclus visite",
    desc:"Fiches simplifiées par poste de travail selon le métier.",
    livrables:["Fiches de poste par métier","Risques principaux par poste","EPI requis"] },
  { id:"registre", nom:"Registre de sécurité", prix:100, duree:"Inclus visite",
    desc:"Registre simplifié avec suivi des contrôles réglementaires.",
    livrables:["Registre des contrôles périodiques","Suivi extincteurs/électricité","Formations"] },
  { id:"affichages", nom:"Kit affichages obligatoires", prix:80, duree:"Fourni",
    desc:"Affichages légaux obligatoires pour l'établissement.",
    livrables:["Règlement intérieur","Consignes incendie","Numéros d'urgence"] },
  { id:"pdp", nom:"Plan de prévention (entreprise extérieure)", prix:280, duree:"½ journée",
    desc:"Document obligatoire dès qu'une entreprise extérieure intervient : ≥400h/12 mois ou travaux dangereux (art. R4511-1 et s. CT).",
    livrables:["Inspection commune préalable","Analyse des risques d'interférence","Plan de prévention signé EU/EE","Checklist travaux dangereux (arrêté 19/03/1993)"] },
  { id:"protocole", nom:"Protocole de sécurité chargement/déchargement", prix:180, duree:"2h",
    desc:"Obligatoire pour toute opération de chargement/déchargement avec transporteur extérieur (art. R4515-1 et s. CT).",
    livrables:["Protocole ponctuel ou permanent","Plan de circulation","Consignes et moyens de secours","Signature entreprise d'accueil / transporteur"] },
  { id:"audit", nom:"Audit sécurité", prix:450, duree:"1 journée",
    desc:"Audit complet de la démarche prévention de l'établissement.",
    livrables:["Rapport d'audit","Plan d'amélioration","Grille de conformité"] },
  { id:"chimique", nom:"Analyse risque chimique", prix:300, duree:"½ journée",
    desc:"Analyse CMR, FDS, inventaire chimique, mesures de prévention.",
    livrables:["Inventaire chimique","Analyse CMR","Fiches exposition"] },
  { id:"accompagnement", nom:"Accompagnement plan d'actions", prix:480, duree:"4h",
    desc:"Accompagnement dans la mise en œuvre du plan d'actions (forfait 4h).",
    livrables:["Suivi mensuel des actions","Relances responsables","Tableau de bord avancement"] },
];

/* ==================== 35 BLOCS PF24 ==================== */
const BLOCS = {
  accueil:     { nom:"Accueil",                icon:"🛎️" },
  bureau:      { nom:"Bureau",                 icon:"💻" },
  stockage:    { nom:"Stockage",               icon:"📦" },
  sanitaires:  { nom:"Sanitaires",             icon:"🚻" },
  vestiaires:  { nom:"Vestiaires",             icon:"🧥" },
  pause:       { nom:"Salle de pause",         icon:"☕" },
  nettoyage:   { nom:"Nettoyage",              icon:"🧹" },
  dechets:     { nom:"Local déchets",          icon:"🗑️" },
  parking:     { nom:"Parking",                icon:"🅿️" },
  circulation: { nom:"Circulation",            icon:"🚶" },
  livraison:   { nom:"Livraison",              icon:"🚚" },
  chimiques:   { nom:"Produits chimiques",     icon:"🧪" },
  electricite: { nom:"Électricité",            icon:"⚡" },
  gaz:         { nom:"Gaz",                    icon:"🔥" },
  incendie:    { nom:"Incendie",               icon:"🧯" },
  froid:       { nom:"Froid",                  icon:"❄️" },
  ventilation: { nom:"Ventilation",            icon:"💨" },
  eclairage:   { nom:"Éclairage",              icon:"💡" },
  bruit:       { nom:"Bruit",                  icon:"🔊" },
  manutention: { nom:"Manutention",            icon:"📋" },
  levage:      { nom:"Levage",                 icon:"🏗️" },
  hauteur:     { nom:"Travail en hauteur",     icon:"🪜" },
  machines:    { nom:"Machines",               icon:"⚙️" },
  outillage:   { nom:"Outillage",              icon:"🔧" },
  vehicules:   { nom:"Véhicules",              icon:"🚗" },
  chargement:  { nom:"Chargement",             icon:"🔃" },
  dechargement:{ nom:"Déchargement",           icon:"📥" },
  cuisine:     { nom:"Cuisine",                icon:"🍳" },
  atelier:     { nom:"Atelier mécanique",      icon:"🔩" },
  laboratoire: { nom:"Laboratoire",            icon:"🔬" },
  soins:       { nom:"Salle de soins",         icon:"💉" },
  tatouage:    { nom:"Tatouage",               icon:"🖋️" },
  coiffure:    { nom:"Salon de coiffure",      icon:"✂️" },
  vente:       { nom:"Salle de vente",         icon:"🛍️" },
  fabrication: { nom:"Fabrication alimentaire",icon:"🏭" },
  chantier:    { nom:"Zone de chantier",        icon:"🏗️" },
};

/* ==================== 60 MÉTIERS → BLOCS ==================== */
const METIERS = {
  // RESTAURATION (8)
  restaurant:   { nom:"Restaurant traditionnel",    icon:"🍽️", secteur:"Restauration",
    blocs:["accueil","cuisine","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","eclairage","manutention"] },
  brasserie:    { nom:"Brasserie",                  icon:"🍺", secteur:"Restauration",
    blocs:["accueil","cuisine","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","manutention","livraison"] },
  snack:        { nom:"Snack / Fast-food",           icon:"🌮", secteur:"Restauration",
    blocs:["accueil","cuisine","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","manutention"] },
  pizzeria:     { nom:"Pizzeria",                   icon:"🍕", secteur:"Restauration",
    blocs:["accueil","cuisine","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","manutention"] },
  boulangerie:  { nom:"Boulangerie",                icon:"🥖", secteur:"Restauration",
    blocs:["accueil","cuisine","fabrication","vente","stockage","livraison","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","eclairage","manutention","machines"] },
  patisserie:   { nom:"Pâtisserie",                 icon:"🍰", secteur:"Restauration",
    blocs:["accueil","cuisine","fabrication","vente","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","manutention","machines"] },
  boucherie:    { nom:"Boucherie / Charcuterie",    icon:"🥩", secteur:"Restauration",
    blocs:["accueil","vente","fabrication","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","froid","ventilation","manutention","outillage","machines","chimiques"] },
  traiteur:     { nom:"Traiteur",                   icon:"🍱", secteur:"Restauration",
    blocs:["accueil","cuisine","fabrication","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","gaz","froid","ventilation","manutention","vehicules","livraison"] },
  // COMMERCE (10)
  fleuriste:    { nom:"Fleuriste",                  icon:"💐", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","manutention","chimiques","livraison"] },
  epicerie:     { nom:"Épicerie",                   icon:"🛒", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","manutention","livraison"] },
  primeur:      { nom:"Primeur",                    icon:"🥕", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","manutention","livraison"] },
  caviste:      { nom:"Caviste",                    icon:"🍷", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","manutention"] },
  librairie:    { nom:"Librairie",                  icon:"📚", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  vetements:    { nom:"Magasin de vêtements",       icon:"👗", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","manutention"] },
  salon_the:    { nom:"Salon de thé",               icon:"☕", secteur:"Commerce",
    blocs:["accueil","cuisine","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","ventilation"] },
  tabac:        { nom:"Tabac / Presse",              icon:"🗞️", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  decoration:   { nom:"Boutique décoration",        icon:"🪴", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","manutention"] },
  animalerie:   { nom:"Animalerie",                 icon:"🐾", secteur:"Commerce",
    blocs:["accueil","vente","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","ventilation","chimiques"] },
  // AUTOMOBILE (2)
  garage:       { nom:"Garage automobile",          icon:"🔧", secteur:"Automobile",
    blocs:["accueil","atelier","levage","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation"] },
  carrossier:   { nom:"Carrossier",                 icon:"🚗", secteur:"Automobile",
    blocs:["accueil","atelier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation","hauteur"] },
  // BÂTIMENT (8)
  electricien:  { nom:"Électricien",                icon:"⚡", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","levage"] },
  plombier:     { nom:"Plombier / Chauffagiste",    icon:"🔩", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","gaz","levage"] },
  chauffagiste: { nom:"Chauffagiste / CVC",         icon:"🌡️", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","gaz","levage"] },
  menuisier:    { nom:"Menuisier / Charpentier",    icon:"🪚", secteur:"Bâtiment",
    blocs:["accueil","bureau","atelier","chantier","machines","outillage","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation","chimiques","hauteur","levage"] },
  serrurier:    { nom:"Serrurier / Métallier",      icon:"🔐", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","atelier","outillage","stockage","sanitaires","vestiaires","pause","nettoyage","incendie","electricite","vehicules","manutention","bruit","hauteur"] },
  peintre:      { nom:"Peintre / Façadier",         icon:"🖌️", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","ventilation","levage"] },
  macon:        { nom:"Maçon / Gros œuvre",         icon:"🧱", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","levage","bruit","machines"] },
  couvreur:     { nom:"Couvreur / Couvreur-Zingueur",icon:"🏠", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","levage","chimiques"] },
  // NOUVEAUX MÉTIERS BTP
  charpentier:  { nom:"Charpentier bois / ossature",  icon:"🪵", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","atelier","machines","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation","hauteur","levage"] },
  couvreur_zinc:{ nom:"Couvreur-Zingueur",             icon:"🏠", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur","levage"] },
  terrassier:   { nom:"Terrassier / Travaux Publics",  icon:"🚜", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","machines","outillage","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","levage","hauteur"] },
  carreleur:    { nom:"Carreleur / Solier",            icon:"🔲", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation","machines"] },
  plaquiste:    { nom:"Plaquiste / Plâtrier",          icon:"🔨", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","ventilation","hauteur"] },
  canalisateur: { nom:"Canalisateur / Réseaux",        icon:"🔧", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","outillage","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","levage","hauteur","machines"] },
  conducteur_tp:{ nom:"Conducteur d'engins TP",        icon:"🚛", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","machines","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","levage"] },
  gros_oeuvre:  { nom:"Entreprise Gros Œuvre / BTP",   icon:"🏢", secteur:"Bâtiment",
    blocs:["accueil","bureau","chantier","machines","outillage","chimiques","vehicules","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","manutention","bruit","levage","hauteur"] },
  // BEAUTÉ (4)
  coiffeur:     { nom:"Coiffeur",                   icon:"✂️", secteur:"Beauté / Bien-être",
    blocs:["accueil","coiffure","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  barbier:      { nom:"Barbier",                    icon:"💈", secteur:"Beauté / Bien-être",
    blocs:["accueil","coiffure","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  estheticienne:{ nom:"Esthéticienne",              icon:"💅", secteur:"Beauté / Bien-être",
    blocs:["accueil","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  tatoueur:     { nom:"Tatoueur",                   icon:"🖋️", secteur:"Beauté / Bien-être",
    blocs:["accueil","tatouage","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  // MÉDICAL (6)
  cabinet_medical: { nom:"Cabinet médical",          icon:"🩺", secteur:"Médical / Paramédical",
    blocs:["accueil","bureau","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","froid"] },
  cabinet_dentaire:{ nom:"Cabinet dentaire",         icon:"🦷", secteur:"Médical / Paramédical",
    blocs:["accueil","bureau","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","bruit","froid","ventilation"] },
  kine:         { nom:"Kinésithérapeute",           icon:"🤲", secteur:"Médical / Paramédical",
    blocs:["accueil","bureau","soins","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  osteopathe:   { nom:"Ostéopathe",                 icon:"🦴", secteur:"Médical / Paramédical",
    blocs:["accueil","bureau","soins","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  podologue:    { nom:"Podologue",                  icon:"🦶", secteur:"Médical / Paramédical",
    blocs:["accueil","bureau","soins","chimiques","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  pharmacie:    { nom:"Pharmacie",                  icon:"💊", secteur:"Médical / Paramédical",
    blocs:["accueil","vente","bureau","soins","chimiques","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","froid","eclairage","manutention"] },
  // TERTIAIRE (10)
  bureau_admin: { nom:"Bureau administratif",        icon:"📋", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  comptable:    { nom:"Cabinet comptable",           icon:"📊", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  immo:         { nom:"Agence immobilière",          icon:"🏢", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking","vehicules"] },
  avocats:      { nom:"Cabinet d'avocats",           icon:"⚖️", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  bureau_etudes:{ nom:"Bureau d'études",             icon:"📐", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking","chimiques"] },
  formation:    { nom:"Centre de formation",         icon:"🎓", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking","circulation"] },
  communication:{ nom:"Agence de communication",    icon:"📣", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  informatique: { nom:"Société informatique",        icon:"💻", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  assurance:    { nom:"Assurance",                  icon:"🛡️", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking"] },
  banque:       { nom:"Banque",                     icon:"🏦", secteur:"Tertiaire / Bureau",
    blocs:["accueil","bureau","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking","ventilation"] },
  // INDUSTRIE / LOGISTIQUE (9)
  entrepot:     { nom:"Entrepôt logistique",         icon:"🏭", secteur:"Industrie / Logistique",
    blocs:["accueil","stockage","manutention","levage","chargement","dechargement","vehicules","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","eclairage","bruit","circulation","livraison"] },
  atelier_fab:  { nom:"Atelier de fabrication",      icon:"⚙️", secteur:"Industrie / Logistique",
    blocs:["accueil","fabrication","machines","outillage","chimiques","manutention","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","bruit","ventilation","eclairage"] },
  imprimerie:   { nom:"Imprimerie",                 icon:"🖨️", secteur:"Industrie / Logistique",
    blocs:["accueil","machines","chimiques","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","bruit","ventilation","eclairage","manutention"] },
  laboratoire_metier:{ nom:"Laboratoire",            icon:"🔬", secteur:"Industrie / Logistique",
    blocs:["accueil","laboratoire","soins","chimiques","froid","ventilation","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage"] },
  atelier_maint:{ nom:"Atelier de maintenance",      icon:"🛠️", secteur:"Industrie / Logistique",
    blocs:["accueil","atelier","machines","outillage","chimiques","vehicules","manutention","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","bruit","hauteur"] },
  transport:    { nom:"Transport routier",           icon:"🚛", secteur:"Industrie / Logistique",
    blocs:["accueil","bureau","vehicules","manutention","chargement","dechargement","sanitaires","pause","nettoyage","dechets","incendie","electricite","eclairage","parking","livraison"] },
  livreur:      { nom:"Livreur",                    icon:"📦", secteur:"Industrie / Logistique",
    blocs:["accueil","vehicules","manutention","chargement","dechargement","sanitaires","pause","nettoyage","incendie","electricite","livraison"] },
  centre_tri:   { nom:"Centre de tri",              icon:"♻️", secteur:"Industrie / Logistique",
    blocs:["accueil","stockage","manutention","levage","chargement","dechargement","vehicules","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","bruit","ventilation","circulation"] },
  recyclerie:   { nom:"Recyclerie",                 icon:"🔄", secteur:"Industrie / Logistique",
    blocs:["accueil","stockage","manutention","chimiques","vehicules","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","eclairage","circulation"] },
  // HYGIÈNE / NETTOYAGE (3)
  blanchisserie:{ nom:"Blanchisserie",              icon:"🧺", secteur:"Hygiène / Nettoyage",
    blocs:["accueil","machines","chimiques","ventilation","stockage","sanitaires","vestiaires","pause","nettoyage","dechets","incendie","electricite","bruit","manutention"] },
  pressing:     { nom:"Pressing",                   icon:"👔", secteur:"Hygiène / Nettoyage",
    blocs:["accueil","vente","machines","chimiques","ventilation","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","bruit","manutention"] },
  nettoyage_ent:{ nom:"Entreprise de nettoyage",   icon:"🧹", secteur:"Hygiène / Nettoyage",
    blocs:["accueil","bureau","chimiques","vehicules","stockage","sanitaires","pause","nettoyage","dechets","incendie","electricite","manutention","hauteur"] },
};

/* ==================== OBJETS PAR BLOC ==================== */
const OBJETS_PAR_BLOC = {
  accueil:     ["Caisse / comptoir","Zone d'attente client","Porte vitrée","Sol d'entrée","Éclairage accueil"],
  bureau:      ["Poste informatique","Siège de bureau","Imprimante","Armoire de rangement","Câblage informatique"],
  stockage:    ["Rayonnage","Escabeau","Transpalette","Armoire produits chimiques","Sol de réserve"],
  sanitaires:  ["Lavabo","Chauffe-eau","Sèche-mains électrique","Sol des sanitaires","Verrou de porte"],
  vestiaires:  ["Casiers","Portant vêtements","Banc vestiaire","Miroir","Douche (si présente)"],
  pause:       ["Réfrigérateur","Micro-ondes","Bouilloire / cafetière","Table et chaises","Évier kitchenette"],
  nettoyage:   ["Produits de nettoyage","Chariot de ménage","Aspirateur","Panneau sol glissant","Autolaveuse (si présente)"],
  dechets:     ["Poubelles / conteneurs","Bac à verre","Bac à cartons","Collecteur DASRI (si applicable)","Compacteur (si présent)"],
  parking:     ["Portail motorisé","Cheminement piéton","Éclairage extérieur","Sol du parking","Bornes de recharge (si présentes)"],
  circulation: ["Couloir de circulation","Escalier intérieur","Porte vitrée interne","Porte coupe-feu","Sol des allées"],
  livraison:   ["Zone de réception","Quai de déchargement","Hayon élévateur","Diable de manutention","Rampe de déchargement"],
  chimiques:   ["Armoire de stockage chimique","Bac de rétention","Rince-œil d'urgence","FDS disponibles","Produits CMR"],
  electricite: ["Tableau électrique général","Câblage apparent","Multiprise","Éclairage de secours (BAES)","Prises en zone humide"],
  gaz:         ["Vanne de coupure gaz","Tuyauterie gaz","Bouteille de gaz GPL","Détecteur de gaz","Ventilation local gaz"],
  incendie:    ["Extincteur","Issue de secours","Détecteur de fumée","Porte coupe-feu","Alarme incendie"],
  froid:       ["Chambre froide positive","Chambre froide négative","Congélateur autonome","Poignée ouverture intérieure","Alarme enfermement"],
  ventilation: ["Système VMC","Extraction localisée","Hotte d'extraction","Filtres de ventilation","Grille d'aération"],
  eclairage:   ["Éclairage général","Éclairage localisé poste","Lumière naturelle (fenêtres)","Éclairage de secours"],
  bruit:       ["Source de bruit (machine, compresseur)","Outillage bruyant","Isolation phonique"],
  manutention: ["Charges lourdes","Diable","Transpalette","Formation gestes et postures","Aide mécanique disponible"],
  levage:      ["Pont élévateur","Cric hydraulique","Chandelles / calage","Palan / treuil","Chariot élévateur"],
  hauteur:     ["Escabeau conforme","Échelle","Garde-corps mezzanine","Harnais antichute","Plateforme individuelle roulante"],
  machines:    ["Machine à risque de happement (pétrin, malaxeur)","Machine tranchante (trancheuse, scie)","Protecteur de sécurité","Arrêt d'urgence","Poste de nettoyage machine"],
  outillage:   ["Outils tranchants manuels","Outils électroportatifs rotatifs","Outils à percussion","Outils de soudure / découpe thermique","Rangement outillage"],
  vehicules:   ["Véhicule utilitaire professionnel","Véhicule léger de service","Deux-roues professionnel","Trousse de premiers secours embarquée"],
  chargement:  ["Zone de chargement","Hayon élévateur (chargement)","Sangle d'arrimage","Aide à la manutention chargement"],
  dechargement:["Zone de déchargement","Rampe de déchargement","Hayon élévateur (déchargement)","Aide à la manutention déchargement"],
  cuisine:     ["Four professionnel","Plaque de cuisson / piano","Friteuse","Hotte d'extraction","Couteaux de cuisine","Mandoline / robot coupe","Lave-vaisselle professionnel","Chambre froide cuisine","Sol cuisine (glissant)"],
  atelier:     ["Pont élévateur véhicule","Cric (intervention)","Démonte-pneu / Équilibreuse","Cage de gonflage","Véhicule électrique / hybride","Chargeur de batterie"],
  laboratoire: ["Pétrin / mélangeur","Laminoir","Silo / doseur poudre","Four de production","Équipements de stérilisation","Produits chimiques laboratoire"],
  soins:       ["Table / fauteuil de soin","Outils réutilisables (pinces, instruments)","Stérilisateur (UV ou autoclave)","Collecteur objets piquants (PCT)","Point de lavage des mains"],
  tatouage:    ["Machine à tatouer","Aiguilles à usage unique","Autoclave de stérilisation","Collecteur DASRI aiguilles","Encre de tatouage","Produits de désinfection"],
  coiffure:    ["Ciseaux de coupe","Tondeuse / rasoir","Sèche-cheveux / lisseur / fer","Bac à shampoing","Produits colorants / décolorants","Zone de coloration"],
  vente:       ["Rayonnage de vente","Vitrine réfrigérée","Vitrine chauffante","Balance de vente","Caisse enregistreuse"],
  fabrication: ["Machine de production en ligne","Machine de conditionnement","Tapis de convoyage","Poste de contrôle qualité","Silo / doseur poudre","Laminoir","Four de production","Pétrin / mélangeur","Diviseuse / façonneuse"],
  chantier:    [
    "Plan de prévention / PPSPS",
    "DICT / DT-DICT réseaux enterrés",
    "Zone de fouille / tranchée",
    "Talutage / étaiement de fouille",
    "Signalisation temporaire de chantier",
    "Base vie / vestiaires chantier",
    "Amiante (bâtiment avant 1997)",
    "Poussières de silice cristalline",
    "Coactivité (entreprises extérieures)",
    "Engins de chantier (pelle, grue, nacelle)",
    "Filets et protections contre chutes d'objets",
    "Réseaux aériens (lignes électriques)",
    "Zone de stockage matériaux",
    "Intempéries / travail par temps extrême",
  ],
};

/* ==================== RÈGLES OBJETS → RISQUES ==================== */
const REGLES_OBJETS = {
  "Friteuse":{ risques:[
    { danger:"Huile chaude",situation:"Surchauffe ou projection lors de la friture",dommages:"Brûlure grave, incendie",gravite:4,probabilite:2 },
    { danger:"Sol gras",situation:"Projection d'huile au sol non nettoyée immédiatement",dommages:"Chute, fracture",gravite:3,probabilite:3 }],
    actions:["Mettre à disposition des gants thermiques","Vérifier la présence d'une couverture anti-feu","Former le personnel à la conduite à tenir en cas de départ de feu","Nettoyer immédiatement les projections d'huile"],
    epi:["Gants thermiques","Chaussures antidérapantes"],controle:"Contrôle du thermostat de sécurité annuel",type:"obligatoire" },
  "Four professionnel":{ risques:[
    { danger:"Surface chaude",situation:"Manipulation sans protection adaptée",dommages:"Brûlure cutanée grave",gravite:3,probabilite:4 }],
    actions:["Fournir des gants thermiques","Former au geste sécurisé d'enfournement"],
    epi:["Gants thermiques"],controle:"Vérification annuelle de l'équipement",type:"obligatoire" },
  "Hotte d'extraction":{ risques:[
    { danger:"Graisses accumulées",situation:"Hotte non nettoyée régulièrement",dommages:"Incendie grave, propagation rapide",gravite:4,probabilite:2 }],
    actions:["Planifier le nettoyage professionnel périodique de la hotte"],
    epi:[],controle:"Nettoyage et contrôle semestriel (usage intensif)",type:"obligatoire" },
  "Sol cuisine (glissant)":{ risques:[
    { danger:"Sol gras / humide",situation:"Projection d'huile ou d'eau non nettoyée",dommages:"Chute, fracture",gravite:3,probabilite:4 }],
    actions:["Mettre en place un protocole de nettoyage immédiat","Installer un tapis antidérapant au poste de friture"],
    epi:["Chaussures antidérapantes"],controle:"",type:"obligatoire" },
  "Mandoline / robot coupe":{ risques:[
    { danger:"Lame exposée",situation:"Utilisation sans gant ni protection",dommages:"Coupure profonde, amputation partielle",gravite:4,probabilite:2 }],
    actions:["Rendre obligatoire le port de gants anti-coupure","Former avant toute utilisation autonome"],
    epi:["Gants anti-coupure"],controle:"",type:"obligatoire" },
  "Couteaux de cuisine":{ risques:[
    { danger:"Lame tranchante",situation:"Couteau mal affûté ou manipulation incorrecte",dommages:"Coupure par dérapage",gravite:2,probabilite:3 }],
    actions:["Planifier l'affûtage régulier","Former à la technique de découpe sécurisée"],
    epi:["Gants anti-coupure"],controle:"",type:"bonne_pratique" },
  "Pont élévateur":{ risques:[
    { danger:"Écrasement sous véhicule",situation:"Intervention sous véhicule mal verrouillé",dommages:"Écrasement grave, décès",gravite:4,probabilite:2 },
    { danger:"Chute du véhicule",situation:"Défaillance du matériel de levage non contrôlé",dommages:"Traumatisme grave",gravite:4,probabilite:1 }],
    actions:["Vérifier le rapport de contrôle périodique","Former les salariés à l'utilisation","Interdire le passage sous véhicule mal stabilisé"],
    epi:["Chaussures de sécurité"],controle:"Vérification générale périodique annuelle (organisme agréé)",type:"obligatoire" },
  "Pont élévateur véhicule":{ risques:[
    { danger:"Écrasement sous véhicule",situation:"Verrouillage non vérifié avant intervention",dommages:"Écrasement grave, décès",gravite:4,probabilite:2 }],
    actions:["Vérifier le verrouillage avant toute intervention","Former le personnel"],
    epi:["Chaussures de sécurité"],controle:"VGP annuelle (organisme agréé)",type:"obligatoire" },
  "Aiguilles à usage unique":{ risques:[
    { danger:"AES (Accident d'Exposition au Sang)",situation:"Piqûre accidentelle par aiguille souillée",dommages:"Contamination biologique (hépatite, VIH)",gravite:4,probabilite:1 },
    { danger:"DASRI",situation:"Élimination incorrecte des aiguilles usagées",dommages:"Piqûre accidentelle, contamination",gravite:3,probabilite:2 }],
    actions:["Garantir l'usage unique systématique","Mettre à disposition un collecteur DASRI","Disposer d'une procédure AES affichée","Former à la conduite à tenir en cas d'AES"],
    epi:["Gants nitrile","Masque chirurgical"],controle:"Contrôle du collecteur DASRI trimestriel",type:"obligatoire" },
  "Autoclave de stérilisation":{ risques:[
    { danger:"Stérilisation inefficace",situation:"Autoclave non contrôlé ou cycle inadapté",dommages:"Contamination croisée entre clients",gravite:3,probabilite:1 }],
    actions:["Vérifier le cycle de stérilisation annuellement","Assurer la traçabilité des cycles","Maintenir le carnet d'entretien à jour"],
    epi:[],controle:"Vérification annuelle (organisme agréé)",type:"obligatoire" },
  "Collecteur DASRI aiguilles":{ risques:[
    { danger:"Piqûre accidentelle",situation:"Collecteur absent ou plein non évacué",dommages:"AES, contamination",gravite:3,probabilite:2 }],
    actions:["Mettre à disposition un collecteur dédié aux aiguilles","Planifier l'enlèvement régulier par filière agréée"],
    epi:["Gants nitrile"],controle:"Vérification mensuelle du remplissage",type:"obligatoire" },
  "Machine à tatouer":{ risques:[
    { danger:"AES",situation:"Contact avec sang du client",dommages:"Contamination biologique",gravite:4,probabilite:1 }],
    actions:["Former aux règles d'hygiène spécifiques à l'activité de tatouage","Protéger la machine par housses à usage unique"],
    epi:["Gants nitrile","Masque chirurgical"],controle:"",type:"obligatoire" },
  "Produits chimiques":{ risques:[
    { danger:"Contact cutané / inhalation",situation:"Manipulation sans EPI ni ventilation",dommages:"Irritation, allergie, intoxication",gravite:3,probabilite:2 }],
    actions:["Demander les FDS à chaque fournisseur","Rendre accessible le classeur FDS","Former à la lecture de FDS"],
    epi:["Gants nitrile","Lunettes de protection"],controle:"",type:"obligatoire" },
  "Produits CMR":{ risques:[
    { danger:"CMR (Cancérogène, Mutagène, Reprotoxique)",situation:"Exposition chronique sans protection renforcée",dommages:"Cancer professionnel, atteinte à la reproduction",gravite:4,probabilite:1 }],
    actions:["Rechercher la substitution du produit CMR","Tracer les expositions (registre)","Mettre en place une protection renforcée","Informer le médecin du travail"],
    epi:["Gants nitrile renforcés","Masque FFP2","Lunettes de protection"],controle:"Déclaration à la CNAM si exposition persistante",type:"obligatoire" },
  "Extincteur":{ risques:[
    { danger:"Absence de moyen d'extinction",situation:"Extincteur absent, inaccessible ou non vérifié",dommages:"Aggravation d'un départ de feu",gravite:3,probabilite:2 }],
    actions:["Vérifier la présence et la conformité des extincteurs","Planifier la vérification annuelle par organisme agréé","Former le personnel à l'utilisation des extincteurs"],
    epi:[],controle:"Vérification annuelle par organisme agréé",type:"obligatoire" },
  "Issue de secours":{ risques:[
    { danger:"Évacuation impossible",situation:"Issue de secours obstruée",dommages:"Brûlure, asphyxie en cas d'incendie",gravite:4,probabilite:2 }],
    actions:["Dégager les issues de secours en permanence","Afficher le plan d'évacuation"],
    epi:[],controle:"Contrôle hebdomadaire du dégagement",type:"obligatoire" },
  "Tableau électrique général":{ risques:[
    { danger:"Défaut électrique",situation:"Installation non contrôlée depuis plus de 12 mois",dommages:"Électrisation, incendie",gravite:4,probabilite:1 }],
    actions:["Faire vérifier l'installation électrique par un organisme agréé"],
    epi:[],controle:"Vérification annuelle obligatoire",type:"obligatoire" },
  "Vanne de coupure gaz":{ risques:[
    { danger:"Fuite de gaz",situation:"Vanne non signalée ou inaccessible en cas d'urgence",dommages:"Incendie, explosion",gravite:4,probabilite:1 }],
    actions:["Signaler clairement la vanne de coupure gaz","Former le personnel à la conduite à tenir en cas d'odeur de gaz"],
    epi:[],controle:"Contrôle annuel de l'installation gaz",type:"obligatoire" },
  "Chambre froide positive":{ risques:[
    { danger:"Enfermement accidentel",situation:"Dispositif d'ouverture intérieure absent ou défectueux",dommages:"Hypothermie grave, détresse",gravite:4,probabilite:1 }],
    actions:["Vérifier le dispositif d'ouverture intérieure","Installer une alarme intérieure si absente"],
    epi:["Gants isolants grand froid"],controle:"Vérification trimestrielle du dispositif d'urgence",type:"obligatoire" },
  "Chambre froide négative":{ risques:[
    { danger:"Enfermement / hypothermie",situation:"Absence de sécurité intérieure ou exposition prolongée",dommages:"Hypothermie grave, décès",gravite:4,probabilite:1 }],
    actions:["Vérifier l'ouverture intérieure et l'alarme","Limiter le temps d'exposition","Fournir des vêtements adaptés au grand froid"],
    epi:["Gants isolants grand froid","Vêtement grand froid"],controle:"Vérification trimestrielle",type:"obligatoire" },
  "Rayonnage":{ risques:[
    { danger:"Chute d'objet",situation:"Empilement sans hauteur maximale définie",dommages:"Traumatisme",gravite:2,probabilite:3 }],
    actions:["Définir une hauteur maximale d'empilement","Vérifier la fixation murale des rayonnages"],
    epi:["Chaussures de sécurité"],controle:"Vérification annuelle de la fixation",type:"bonne_pratique" },
  "Escabeau":{ risques:[
    { danger:"Chute de hauteur",situation:"Accès en hauteur sans escabeau conforme (support de fortune)",dommages:"Chute, traumatisme grave",gravite:3,probabilite:2 }],
    actions:["Mettre à disposition un escabeau conforme","Interdire les supports de fortune"],
    epi:["Chaussures de sécurité"],controle:"Vérification annuelle de l'état",type:"obligatoire" },
  "Câblage informatique":{ risques:[
    { danger:"Câbles au sol",situation:"Câbles non protégés traversant la zone de circulation",dommages:"Chute de plain-pied",gravite:2,probabilite:3 }],
    actions:["Sécuriser les câbles au sol (passe-câbles ou goulotes)"],
    epi:[],controle:"",type:"bonne_pratique" },
  "Câblage apparent":{ risques:[
    { danger:"Câble endommagé",situation:"Câble présentant un dénudage ou un défaut visible",dommages:"Électrisation, court-circuit",gravite:3,probabilite:2 }],
    actions:["Mettre en place un contrôle visuel régulier","Remplacer immédiatement tout câble défectueux"],
    epi:[],controle:"Vérification visuelle trimestrielle",type:"obligatoire" },
  "Poste informatique":{ risques:[
    { danger:"TMS écran",situation:"Poste écran mal réglé ou mobilier inadapté",dommages:"TMS cervicaux et dorsaux, fatigue visuelle",gravite:2,probabilite:3 }],
    actions:["Vérifier et ajuster la hauteur de l'écran et du siège","Former à l'ergonomie du poste de travail"],
    epi:[],controle:"",type:"inrs" },
  "Produits de nettoyage":{ risques:[
    { danger:"Mélange de produits incompatibles",situation:"Mélange de Javel et détartrant",dommages:"Intoxication respiratoire grave",gravite:3,probabilite:2 }],
    actions:["Former aux risques de mélange","Séparer physiquement le stockage des produits incompatibles"],
    epi:["Gants nitrile"],controle:"",type:"obligatoire" },
  "Lavabo":{ risques:[
    { danger:"Sol humide",situation:"Fuite ou projection d'eau non nettoyée",dommages:"Chute, entorse",gravite:2,probabilite:3 }],
    actions:["Nettoyer immédiatement toute eau au sol"],
    epi:["Chaussures antidérapantes"],controle:"Vérification trimestrielle des fuites",type:"bonne_pratique" },
  "Charges lourdes":{ risques:[
    { danger:"TMS / manutention",situation:"Port manuel de charges lourdes sans aide mécanique",dommages:"Lombalgie, hernie discale",gravite:3,probabilite:4 }],
    actions:["Former aux gestes et postures (PRAP)","Mettre à disposition un diable ou transpalette"],
    epi:["Chaussures de sécurité"],controle:"",type:"obligatoire" },
  "Hauteur":{ risques:[
    { danger:"Chute de hauteur",situation:"Accès en hauteur sans EPC ou EPI adapté",dommages:"Chute grave, traumatisme",gravite:4,probabilite:2 }],
    actions:["Équiper de garde-corps","Former au travail en hauteur","Mettre à disposition un harnais si nécessaire"],
    epi:["Harnais antichute","Chaussures de sécurité"],controle:"Vérification annuelle harnais",type:"obligatoire" },
  "Stérilisateur (UV ou autoclave)":{ risques:[
    { danger:"Stérilisation insuffisante",situation:"Appareil non vérifié régulièrement",dommages:"Contamination croisée entre clients",gravite:3,probabilite:1 }],
    actions:["Vérifier le bon fonctionnement annuellement","Tracer les cycles de stérilisation"],
    epi:[],controle:"Vérification annuelle",type:"obligatoire" },
  "Produits colorants / décolorants":{ risques:[
    { danger:"Allergie cutanée / inhalation",situation:"Contact répété ou inhalation de poudres décolorantes",dommages:"Allergie, asthme professionnel",gravite:2,probabilite:4 }],
    actions:["Rendre obligatoire le port de gants nitrile","Porter un masque FFP2 lors du dosage de poudre décolorante","Réaliser un test de tolérance 48h avant toute coloration"],
    epi:["Gants nitrile","Masque FFP2"],controle:"",type:"inrs" },
  "Bac à shampoing":{ risques:[
    { danger:"Glissade zone humide",situation:"Eau au sol non nettoyée",dommages:"Chute, entorse, fracture",gravite:2,probabilite:3 }],
    actions:["Installer un tapis antidérapant dédié"],
    epi:["Chaussures antidérapantes"],controle:"",type:"bonne_pratique" },

  /* ============================
     LEVAGE & MANUTENTION
     ============================ */
  "Chariot élévateur":{ risques:[
    {danger:"Renversement / écrasement",situation:"Charge déséquilibrée ou sol irrégulier",dommages:"Écrasement grave, décès",gravite:4,probabilite:2},
    {danger:"Collision personne à pied",situation:"Zone de circulation mixte piétons/chariots",dommages:"Traumatisme grave",gravite:4,probabilite:2}],
    actions:["Séparer les flux piétons et chariots (marquage au sol)","Vérifier le rapport de VGP annuel","Former et habiliter les conducteurs (CACES R489)","Vérifier le port du harnais pour les opérations en hauteur"],
    epi:["Chaussures de sécurité","Gilet haute visibilité"],controle:"VGP annuelle + CACES R489",type:"obligatoire"},

  "Cric hydraulique":{ risques:[
    {danger:"Écrasement sous charge",situation:"Cric mal positionné ou défaillant sous véhicule",dommages:"Écrasement grave, décès",gravite:4,probabilite:1}],
    actions:["Utiliser systématiquement des chandelles de sécurité après levage","Vérifier l'état du cric avant chaque utilisation","Interdire tout passage sous véhicule levé sans chandelles"],
    epi:["Chaussures de sécurité"],controle:"Vérification visuelle mensuelle",type:"obligatoire"},

  "Chandelles / calage":{ risques:[
    {danger:"Chute du véhicule",situation:"Chandelles absentes ou mal positionnées",dommages:"Écrasement, décès",gravite:4,probabilite:1}],
    actions:["Rendre obligatoire l'utilisation des chandelles dès que le véhicule est levé"],
    epi:["Chaussures de sécurité"],controle:"",type:"obligatoire"},

  "Compacteur (si présent)":{ risques:[
    {danger:"Happement / écrasement",situation:"Introduction de membres dans la zone de compaction",dommages:"Amputation, écrasement grave",gravite:4,probabilite:1},
    {danger:"Bruit",situation:"Utilisation sans protection auditive",dommages:"Surdité professionnelle",gravite:2,probabilite:3}],
    actions:["Former à l'utilisation exclusive de l'outil de chargement","Vérifier le bon fonctionnement du dispositif d'arrêt d'urgence","Mettre à disposition des protecteurs auditifs"],
    epi:["Protecteurs auditifs","Gants de manutention","Chaussures de sécurité"],controle:"VGP annuelle",type:"obligatoire"},

  "Hayon élévateur (chargement)":{ risques:[
    {danger:"Chute de hauteur",situation:"Glissade sur plateau ou basculement de la charge",dommages:"Traumatisme grave",gravite:3,probabilite:2}],
    actions:["Vérifier l'état du plateau antidérapant","Former à l'utilisation du hayon","Limiter la charge à la capacité nominale"],
    epi:["Chaussures de sécurité"],controle:"VGP annuelle (art. R4323-22 CT)",type:"obligatoire"},

  "Hayon élévateur (déchargement)":{ risques:[
    {danger:"Chute de hauteur",situation:"Glissade ou basculement lors du déchargement",dommages:"Traumatisme grave",gravite:3,probabilite:2}],
    actions:["Vérifier l'état du plateau antidérapant","Former à l'utilisation","Deux personnes pour les charges lourdes"],
    epi:["Chaussures de sécurité","Gants de manutention"],controle:"VGP annuelle",type:"obligatoire"},

  /* ============================
     GAZ & ÉNERGIE
     ============================ */
  "Bouteille de gaz GPL":{ risques:[
    {danger:"Explosion / incendie",situation:"Fuite de gaz à proximité d'une source d'ignition",dommages:"Brûlures graves, décès, dommages matériels",gravite:4,probabilite:1},
    {danger:"Asphyxie",situation:"Fuite dans un espace confiné non ventilé",dommages:"Asphyxie, perte de connaissance",gravite:4,probabilite:1}],
    actions:["Stocker les bouteilles en position verticale, à l'extérieur ou dans un local ventilé","Contrôler l'installation gaz annuellement","Installer un détecteur de gaz","Former à la conduite à tenir en cas de fuite"],
    epi:[],controle:"Contrôle annuel installation gaz",type:"obligatoire"},

  "Détecteur de gaz":{ risques:[
    {danger:"Défaut de détection",situation:"Détecteur non testé ou hors service",dommages:"Fuite non détectée → explosion/asphyxie",gravite:4,probabilite:1}],
    actions:["Tester le détecteur mensuellement","Remplacer selon la durée de vie du capteur (en général 5 ans)"],
    epi:[],controle:"Test mensuel + remplacement selon préconisation fabricant",type:"obligatoire"},

  "Chargeur de batterie":{ risques:[
    {danger:"Explosion / incendie",situation:"Dégagement d'hydrogène lors de la charge en espace non ventilé",dommages:"Explosion, brûlures, incendie",gravite:4,probabilite:1},
    {danger:"Electrisation",situation:"Contact avec bornes sous tension",dommages:"Électrisation, brûlures",gravite:3,probabilite:1}],
    actions:["Charger dans un local ventilé ou à l'extérieur","Interdire toute source d'ignition à proximité pendant la charge","Utiliser des EPI isolants pour les connexions"],
    epi:["Gants isolants","Lunettes de protection"],controle:"Vérification annuelle",type:"obligatoire"},

  "Cage de gonflage":{ risques:[
    {danger:"Explosion du pneumatique",situation:"Surpression lors du gonflage d'un pneu endommagé",dommages:"Projection, traumatisme crânien grave",gravite:4,probabilite:1}],
    actions:["Utiliser exclusivement la cage de gonflage homologuée","Ne pas dépasser la pression préconisée","Inspecter le pneumatique avant gonflage"],
    epi:["Lunettes de protection","Écran facial"],controle:"Vérification état cage trimestrielle",type:"obligatoire"},

  "Véhicule utilitaire professionnel":{ risques:[
    {danger:"Accident routier",situation:"Déplacements professionnels sans politique de prévention routière",dommages:"Accident grave, décès",gravite:4,probabilite:2},
    {danger:"Manutention chargement/déchargement",situation:"Charge mal arrimée, absence d'aide mécanique",dommages:"Chute, lombalgie, écrasement",gravite:3,probabilite:3}],
    actions:["Mettre en place une politique de risque routier","Vérifier les véhicules avant départ (contrôle visuel)","Former aux techniques de chargement/arrimage","Equiper d'une trousse de secours embarquée"],
    epi:["Gilet haute visibilité","Chaussures de sécurité"],controle:"Contrôle technique + entretien selon kilométrage",type:"obligatoire"},

  "Deux-roues professionnel":{ risques:[
    {danger:"Accident de la route",situation:"Circulation en deux-roues pour livraison sans équipements adaptés",dommages:"Traumatisme grave, décès",gravite:4,probabilite:2}],
    actions:["Imposer le port du casque homologué et des gants","Vérifier l'état du véhicule avant chaque départ","Former à la conduite en sécurité"],
    epi:["Casque homologué","Gants moto","Vêtements de protection"],controle:"Entretien annuel",type:"obligatoire"},

  /* ============================
     INCENDIE & SÉCURITÉ
     ============================ */
  "Alarme incendie":{ risques:[
    {danger:"Alarme non fonctionnelle",situation:"Alarme non testée ou hors service",dommages:"Évacuation retardée, piégeage, décès",gravite:4,probabilite:1}],
    actions:["Tester l'alarme au moins une fois par semaine","Faire vérifier le système par un technicien qualifié semestriellement","Former tout le personnel à la procédure d'évacuation"],
    epi:[],controle:"Test hebdomadaire + vérification semestrielle technicien qualifié",type:"obligatoire"},

  "Portail motorisé":{ risques:[
    {danger:"Écrasement / coincement",situation:"Personne ou objet dans la trajectoire du portail",dommages:"Écrasement, fracture",gravite:3,probabilite:2}],
    actions:["Vérifier le bon fonctionnement des cellules photosensibles et des bords sensibles","Faire vérifier annuellement par un technicien","Mettre en place un signal sonore/lumineux avant ouverture/fermeture"],
    epi:[],controle:"Vérification annuelle technicien + test cellules mensuel",type:"obligatoire"},

  "Poignée ouverture intérieure":{ risques:[
    {danger:"Enfermement",situation:"Dispositif d'ouverture intérieure absent ou défectueux",dommages:"Hypothermie, asphyxie, décès",gravite:4,probabilite:1}],
    actions:["Vérifier mensuellement le dispositif d'ouverture intérieure de la chambre froide","Installer une alarme sonore intérieure si absente","Former le personnel à la procédure d'urgence"],
    epi:[],controle:"Vérification mensuelle",type:"obligatoire"},

  /* ============================
     MACHINES & ÉQUIPEMENTS
     ============================ */
  "Pétrin / mélangeur":{ risques:[
    {danger:"Happement des membres",situation:"Introduction de la main dans le malaxeur en fonctionnement",dommages:"Écrasement, amputation",gravite:4,probabilite:1}],
    actions:["Vérifier le protecteur de cuve avant chaque utilisation","Former à l'interdiction de la main dans le pétrin en marche","Vérifier l'arrêt d'urgence opérationnel"],
    epi:["Gants anti-coupure (hors pétrin en marche)"],controle:"VGP annuelle machine",type:"obligatoire"},

  "Four de production":{ risques:[
    {danger:"Brûlure par surface chaude",situation:"Contact avec orifice, sole ou porte du four",dommages:"Brûlures du 2e ou 3e degré",gravite:3,probabilite:3}],
    actions:["Mettre à disposition des gants thermiques adaptés à la température du four","Former aux gestes sécurisés (enfournement, défournement)","Vérifier annuellement le thermostat de sécurité"],
    epi:["Gants thermiques (résistance ≥ 250°C)","Tablier thermique"],controle:"Vérification annuelle équipement",type:"obligatoire"},

  "Laminoir":{ risques:[
    {danger:"Happement / écrasement des membres",situation:"Introduction des mains dans les rouleaux en fonctionnement",dommages:"Écrasement, fracture, amputation",gravite:4,probabilite:1}],
    actions:["Vérifier le protecteur des rouleaux avant chaque utilisation","Former à l'interdiction d'introduction des doigts","Vérifier l'arrêt d'urgence"],
    epi:["Gants anti-coupure (hors zone de prise)"],controle:"VGP annuelle",type:"obligatoire"},

  "Silo / doseur poudre":{ risques:[
    {danger:"Inhalation de poussières",situation:"Manipulation de farines, sucres ou poudres sans protection respiratoire",dommages:"Pathologie respiratoire, allergie, asthme professionnel",gravite:3,probabilite:3},
    {danger:"Explosion poussières (ATEX)",situation:"Accumulation de poussières de farine en espace confiné",dommages:"Explosion, brûlures, décès",gravite:4,probabilite:1}],
    actions:["Ventiler les zones de manipulation de farines","Mettre à disposition des masques FFP2 pour le remplissage","Nettoyer régulièrement les dépôts de poussières","Évaluer le risque ATEX Zone 22 si accumulation importante"],
    epi:["Masque FFP2","Lunettes de protection"],controle:"Contrôle annuel ventilation + évaluation ATEX si nécessaire",type:"obligatoire"},

  "Tapis de convoyage":{ risques:[
    {danger:"Happement / coincement",situation:"Contact avec la zone d'entraînement du tapis sans protecteur",dommages:"Écrasement, fracture, amputation",gravite:4,probabilite:1}],
    actions:["Vérifier les protecteurs des zones d'entraînement","Former à l'interdiction de toute intervention avec le tapis en marche","Vérifier l'arrêt d'urgence"],
    epi:["Chaussures de sécurité"],controle:"VGP annuelle",type:"obligatoire"},

  "Machine tranchante (trancheuse, scie)":{ risques:[
    {danger:"Coupure grave par la lame",situation:"Contact avec la lame en marche ou lors du nettoyage",dommages:"Coupure profonde, amputation partielle",gravite:4,probabilite:2}],
    actions:["Former avant toute utilisation autonome","Rendre obligatoire le port de gants anti-coupure niveau 5","Veiller au retrait de l'alimentation avant tout nettoyage","Vérifier le protecteur de lame"],
    epi:["Gants anti-coupure niveau 5 (EN 388)","Cotte de mailles si usage intensif"],controle:"Vérification état lame et protecteur mensuelle",type:"obligatoire"},

  "Lave-vaisselle professionnel":{ risques:[
    {danger:"Brûlure par vapeur ou eau chaude",situation:"Ouverture du capot en cours de cycle",dommages:"Brûlures du visage et des mains",gravite:3,probabilite:2},
    {danger:"Contact avec produits chimiques",situation:"Manipulation des bacs de produits sans protection",dommages:"Irritation cutanée, brûlure chimique",gravite:2,probabilite:3}],
    actions:["Former à l'interdiction d'ouverture en cours de cycle","Mettre à disposition des gants résistants à la chaleur et aux produits chimiques","Vérifier les FDS des produits utilisés"],
    epi:["Gants nitrile résistants à la chaleur","Tablier imperméable"],controle:"Entretien selon préconisation fabricant",type:"obligatoire"},

  "Arrêt d'urgence":{ risques:[
    {danger:"Arrêt d'urgence inaccessible ou non fonctionnel",situation:"Arrêt d'urgence obstrué ou non testé",dommages:"Impossibilité d'arrêter une machine en cas d'accident",gravite:4,probabilite:1}],
    actions:["Tester les arrêts d'urgence mensuellement","S'assurer qu'ils sont accessibles et clairement identifiés (rouge/jaune)","Former tout le personnel à leur localisation"],
    epi:[],controle:"Test mensuel + VGP annuelle machine",type:"obligatoire"},

  /* ============================
     BRUIT — seuils légaux
     ============================ */
  "Source de bruit (machine, compresseur)":{ risques:[
    {danger:"Surdité professionnelle",situation:"Exposition à des niveaux sonores élevés sans protection",dommages:"Perte auditive irréversible (maladie professionnelle tableau n°42)",gravite:3,probabilite:3}],
    actions:["Mesurer le niveau sonore (sonomètre ou audiodosimètre)","Si > 80 dB(A) : informer les salariés et proposer les protections","Si > 85 dB(A) : port de protections auditives OBLIGATOIRE, zones délimitées","Si > 87 dB(A) : VALEUR LIMITE — action immédiate, réduction technique obligatoire","Réduire le bruit à la source si possible (capotage, isolation, amortissement)"],
    epi:["Protecteurs auditifs (SNR adapté au niveau sonore)"],controle:"Mesure sonométrique annuelle si exposition > 80 dB(A)",type:"obligatoire"},

  "Outillage bruyant":{ risques:[
    {danger:"Surdité professionnelle",situation:"Utilisation prolongée d'outillage bruyant sans EPI",dommages:"Perte auditive irréversible",gravite:3,probabilite:3}],
    actions:["Porter des protecteurs auditifs dès 85 dB(A)","Limiter la durée d'exposition quotidienne","Alterner les tâches bruyantes et silencieuses"],
    epi:["Protecteurs auditifs adaptés"],controle:"",type:"obligatoire"},

  /* ============================
     RISQUES CHIMIQUES COMPLÉMENTAIRES
     ============================ */
  "Armoire de stockage chimique":{ risques:[
    {danger:"Mélange incompatible / incendie",situation:"Produits chimiques incompatibles stockés sans séparation",dommages:"Réaction chimique dangereuse, incendie, explosion",gravite:4,probabilite:1},
    {danger:"Renversement / contact cutané",situation:"Armoire surchargée ou mal fermée",dommages:"Brûlure chimique, intoxication",gravite:3,probabilite:2}],
    actions:["Organiser le stockage selon les incompatibilités (oxydants/inflammables/corrosifs séparés)","Vérifier que l'armoire est ventilée","Afficher le plan de stockage et les FDS","Limiter les quantités stockées au strict nécessaire"],
    epi:["Gants nitrile","Lunettes de protection","Tablier de protection"],controle:"Vérification trimestrielle",type:"obligatoire"},

  "Bac de rétention":{ risques:[
    {danger:"Débordement / pollution",situation:"Bac plein ou percé, fuite non détectée",dommages:"Pollution, contact chimique, glissade",gravite:3,probabilite:2}],
    actions:["Vérifier le niveau du bac de rétention mensuellement","Purger régulièrement","Vérifier l'étanchéité du bac"],
    epi:[],controle:"Vérification mensuelle",type:"obligatoire"},

  "Rince-œil d'urgence":{ risques:[
    {danger:"Absence de rinçage immédiat en cas de projection",situation:"Rince-œil absent, inaccessible ou hors service",dommages:"Brûlure chimique oculaire grave, cécité",gravite:4,probabilite:1}],
    actions:["Vérifier le fonctionnement du rince-œil hebdomadairement","S'assurer qu'il est accessible en 10 secondes depuis les postes chimiques","Former à son utilisation"],
    epi:[],controle:"Test hebdomadaire",type:"obligatoire"},

  "Encre de tatouage":{ risques:[
    {danger:"Pigments CMR",situation:"Certaines encres contiennent des pigments classés CMR",dommages:"Risque cancérogène à long terme",gravite:4,probabilite:1},
    {danger:"Allergie / sensibilisation",situation:"Contact répété avec pigments",dommages:"Dermatite de contact, sensibilisation",gravite:2,probabilite:2}],
    actions:["Vérifier la conformité des encres avec le Règlement UE 2020/2081 (restriction pigments azoïques)","Tenir un registre des encres utilisées avec FDS","Informer les clients des risques"],
    epi:["Gants nitrile"],controle:"Vérification conformité encres annuelle",type:"obligatoire"},

  /* ============================
     ÉLECTRICITÉ
     ============================ */
  "Multiprise":{ risques:[
    {danger:"Surcharge électrique / incendie",situation:"Multiprise surchargée ou rallonge en attente permanente",dommages:"Court-circuit, incendie",gravite:3,probabilite:2}],
    actions:["Interdire l'usage de multiprises en cascade","Remplacer par des prises fixes si besoin permanent","Vérifier l'état des câbles d'alimentation"],
    epi:[],controle:"Vérification visuelle trimestrielle",type:"obligatoire"},

  "Prises en zone humide":{ risques:[
    {danger:"Électrisation",situation:"Prise non étanche en zone humide (cuisine, sanitaires)",dommages:"Électrisation, brûlure, décès",gravite:4,probabilite:1}],
    actions:["Remplacer les prises par des modèles IP44 minimum en zone humide","Vérifier la mise à la terre","Faire vérifier par un électricien qualifié"],
    epi:[],controle:"Vérification lors du contrôle électrique annuel",type:"obligatoire"},

  /* ============================
     ERGONOMIE & TMS
     ============================ */
  "Transpalette":{ risques:[
    {danger:"TMS — lombalgie",situation:"Utilisation prolongée sans formation aux bonnes postures",dommages:"Lombalgie, hernie discale",gravite:3,probabilite:3},
    {danger:"Heurt / écrasement des pieds",situation:"Charge mal équilibrée ou manque de visibilité",dommages:"Fracture des orteils",gravite:2,probabilite:3}],
    actions:["Former aux techniques de manutention avec transpalette","Vérifier l'état des roues et du mécanisme de levée","Porter des chaussures de sécurité"],
    epi:["Chaussures de sécurité"],controle:"Vérification mensuelle état général",type:"bonne_pratique"},

  "Poste informatique":{ risques:[
    {danger:"TMS — cervicalgies, tendinites",situation:"Poste écran non ajusté à la morphologie du salarié",dommages:"Troubles musculo-squelettiques chroniques",gravite:2,probabilite:4},
    {danger:"Fatigue visuelle",situation:"Écran mal orienté, luminosité inadaptée",dommages:"Céphalées, fatigue oculaire",gravite:1,probabilite:4}],
    actions:["Réaliser une évaluation ergonomique du poste écran (Décret du 14/05/1991)","Régler la hauteur de l'écran (bord supérieur au niveau des yeux)","Régler la hauteur du siège (avant-bras horizontaux)","Prévoir des pauses visuelles toutes les heures (règle 20-20-20)","Proposer un bilan ophtalmologique si exposition > 4h/jour"],
    epi:[],controle:"Évaluation ergonomique initiale + après changement matériel",type:"obligatoire"},

  /* ============================
     SANITAIRES & HYGIÈNE
     ============================ */
  "Chauffe-eau":{ risques:[
    {danger:"Légionellose",situation:"Température de l'eau chaude < 60°C dans le ballon",dommages:"Infection pulmonaire grave (maladie professionnelle)",gravite:4,probabilite:1},
    {danger:"Brûlure",situation:"Eau chaude à température excessive aux points d'usage",dommages:"Brûlure cutanée",gravite:2,probabilite:2}],
    actions:["Maintenir le ballon à 60°C minimum","Vérifier la température mensuelle","Purger périodiquement les points d'usage peu utilisés","Installer un mitigeur thermostatique aux points d'usage"],
    epi:[],controle:"Contrôle température mensuel + carnet sanitaire",type:"obligatoire"},

  "Sèche-mains électrique":{ risques:[
    {danger:"Contamination croisée",situation:"Sèche-mains mal entretenu propageant des bactéries",dommages:"Infections cutanées",gravite:2,probabilite:2}],
    actions:["Nettoyer et désinfecter régulièrement le sèche-mains","Vérifier l'absence de filtre colmaté","Préférer les essuie-mains à usage unique en zone alimentaire"],
    epi:[],controle:"Nettoyage hebdomadaire",type:"bonne_pratique"},

  /* ============================
     DIVERS MANQUANTS
     ============================ */
  "Panneau sol glissant":{ risques:[
    {danger:"Chute de plain-pied",situation:"Sol mouillé sans signalisation",dommages:"Fracture, contusion",gravite:3,probabilite:3}],
    actions:["Disposer immédiatement le panneau sol glissant dès qu'un sol est mouillé","S'assurer de la disponibilité du panneau à chaque poste"],
    epi:["Chaussures antidérapantes"],controle:"",type:"obligatoire"},

  "Miroir (angle mort)":{ risques:[
    {danger:"Collision",situation:"Angle mort dans un couloir fréquenté par des engins",dommages:"Collision, traumatisme",gravite:3,probabilite:2}],
    actions:["Installer des miroirs de sécurité aux croisements","Limiter la vitesse des engins"],
    epi:[],controle:"Vérification état miroirs mensuelle",type:"bonne_pratique"},

  "Trousse de premiers secours":{ risques:[
    {danger:"Soins inadaptés en cas d'urgence",situation:"Trousse absente, incomplète ou périmée",dommages:"Aggravation d'un accident faute de soins immédiats",gravite:3,probabilite:1}],
    actions:["Vérifier le contenu de la trousse mensuellement","Former au moins un SST (Sauveteur Secouriste du Travail) par zone (art. R4224-15 CT)","Afficher les numéros d'urgence à proximité"],
    epi:[],controle:"Vérification mensuelle du contenu",type:"obligatoire"},

  "Ciseaux de coupe":{ risques:[
    {danger:"Coupure",situation:"Manipulation sans technique ou ciseaux émoussés favorisant le dérapage",dommages:"Coupure profonde des doigts",gravite:2,probabilite:3}],
    actions:["Entretenir régulièrement les ciseaux (affûtage)","Former à la technique de coupe sécurisée","Ranger les ciseaux avec protège-lame"],
    epi:["Gants anti-coupure niveau 3 minimum"],controle:"",type:"bonne_pratique"},

  "Congélateur autonome":{ risques:[
    {danger:"Froid extrême",situation:"Manipulation prolongée sans protection",dommages:"Engelures, froid aux extrémités",gravite:2,probabilite:3},
    {danger:"Chute d'objet",situation:"Produits mal rangés tombant lors de l'ouverture",dommages:"Traumatisme pied",gravite:2,probabilite:2}],
    actions:["Fournir des gants grand froid pour les manipulations prolongées","Organiser le rangement pour éviter les chutes d'objets"],
    epi:["Gants grand froid","Chaussures de sécurité"],controle:"",type:"bonne_pratique"},

  "Poste de contrôle qualité":{ risques:[
    {danger:"TMS — postures statiques",situation:"Poste de contrôle sans réglage possible en hauteur",dommages:"Cervicalgies, tendinites des membres supérieurs",gravite:2,probabilite:4}],
    actions:["Évaluer l'ergonomie du poste","Permettre l'alternance assis/debout","Varier les tâches toutes les 30 minutes"],
    epi:[],controle:"Évaluation ergonomique",type:"inrs"},

  "Bouilloire / cafetière":{ risques:[
    {danger:"Brûlure",situation:"Renversement de liquide bouillant",dommages:"Brûlure du 1er/2e degré",gravite:2,probabilite:2}],
    actions:["Disposer la bouilloire sur une surface stable","Eviter de la placer en bordure de plan de travail"],
    epi:[],controle:"",type:"bonne_pratique"},


  "Silo / doseur poudre (ATEX)":{ risques:[
    {danger:"Explosion ATEX — Zone 22",situation:"Accumulation de poussières combustibles (farine, sucre) en espace confiné",dommages:"Explosion grave, brûlures, décès",gravite:4,probabilite:1}],
    actions:["Faire réaliser une évaluation ATEX par un expert (Directive 1999/92/CE, art. R4227-42 CT)","Classer les zones en Zone 20/21/22 selon la concentration de poussières","Utiliser exclusivement du matériel certifié ATEX dans les zones classées","Mettre en place des procédures de nettoyage préventif pour éliminer les dépôts"],
    epi:["Vêtements antistatiques","Chaussures antistatiques"],controle:"Évaluation ATEX avec technicien certifié",type:"obligatoire"},


  /* ============================
     CHANTIER — Règles spécifiques BTP
     Décret 65-48 du 8 janv. 1965, Art. R4532-1 CT (PGCSPS)
     ============================ */
  "Plan de prévention / PPSPS":{ risques:[
    {danger:"Absence de coordination sécurité",situation:"Travaux en coactivité sans plan de prévention ni PPSPS",dommages:"Accident par manque de coordination entre entreprises",gravite:4,probabilite:2}],
    actions:[
      "Rédiger un Plan de Prévention avec le donneur d'ordre si opération > 400h ou travaux dangereux (art. R4512-6 CT)",
      "Etablir un PPSPS (Plan Particulier de Sécurité et de Protection de la Santé) pour les chantiers soumis à coordination SPS (art. R4532-58 CT)",
      "Nommer un coordonnateur SPS pour les chantiers avec coactivité (art. L4532-4 CT)",
      "Organiser une inspection commune préalable avant toute intervention",
    ],
    epi:[],controle:"Avant toute opération en coactivité",type:"obligatoire"},

  "DICT / DT-DICT réseaux enterrés":{ risques:[
    {danger:"Endommagement de réseaux enterrés",situation:"Travaux de terrassement sans consultation préalable des réseaux (gaz, électricité, télécom, eau, assainissement)",dommages:"Explosion, électrisation, inondation — accidents mortels",gravite:4,probabilite:2}],
    actions:[
      "Effectuer une Déclaration de Projet de Travaux (DT) auprès de tous les gestionnaires de réseaux avant toute fouille (Décret 2011-1241 du 5/10/2011)",
      "Effectuer une DICT (Déclaration d'Intention de Commencement de Travaux) au moins 2 jours avant le démarrage",
      "Consulter le guichet unique reseaux-et-canalisations.ineris.fr",
      "Respecter les distances de sécurité autour des réseaux sensibles (gaz : excavation manuelle obligatoire à moins d'1 m)",
      "Former les compagnons à la conduite à tenir en cas d'endommagement de réseau",
    ],
    epi:["Gants isolants","Détecteur de réseaux"],controle:"Avant chaque chantier avec terrassement",type:"obligatoire"},

  "Zone de fouille / tranchée":{ risques:[
    {danger:"Eboulement / ensevelissement",situation:"Fouille non étayée ou talutée, parois verticales instables",dommages:"Ensevelissement, asphyxie, décès",gravite:4,probabilite:2},
    {danger:"Chute dans la fouille",situation:"Fouille sans protection en bordure",dommages:"Traumatisme grave",gravite:3,probabilite:2}],
    actions:[
      "Etayer ou taluder toute fouille de profondeur > 1,30 m (art. R4534-1 CT — obligation absolue)",
      "Installer des garde-corps ou des barrières en bordure de fouille",
      "Vérifier les parois avant chaque descente",
      "Prévoir un moyen d'évacuation rapide (échelle, rampe) accessible depuis le fond",
      "Ne jamais laisser du personnel seul dans une fouille profonde (travail isolé)",
    ],
    epi:["Casque de chantier","Chaussures de sécurité","Gilet haute visibilité"],controle:"Avant chaque descente + après intempéries",type:"obligatoire"},

  "Talutage / étaiement de fouille":{ risques:[
    {danger:"Effondrement de paroi",situation:"Etaiement absent ou défaillant",dommages:"Ensevelissement, décès",gravite:4,probabilite:1}],
    actions:[
      "Vérifier l'étaiement avant chaque reprise de travail",
      "Faire vérifier l'étaiement par une personne compétente (chef de chantier, BE)",
      "Renforcer l'étaiement après chaque intempérie ou vibration importante",
    ],
    epi:["Casque"],controle:"Vérification quotidienne",type:"obligatoire"},

  "Signalisation temporaire de chantier":{ risques:[
    {danger:"Accident de la route / collision",situation:"Chantier en domaine public sans signalisation réglementaire",dommages:"Accident de la route, traumatisme grave",gravite:4,probabilite:2}],
    actions:[
      "Mettre en place la signalisation temporaire conforme à l'instruction interministérielle (signalisation de chantier sur voirie)",
      "Obtenir les autorisations de voirie avant toute occupation de chaussée",
      "Former un responsable 'Chef de zone' pour les chantiers en bord de route",
      "Maintenir la signalisation en bon état pendant toute la durée du chantier",
    ],
    epi:["Gilet haute visibilité classe 3","Casque"],controle:"Avant ouverture du chantier + quotidien",type:"obligatoire"},

  "Amiante (bâtiment avant 1997)":{ risques:[
    {danger:"Inhalation de fibres d'amiante",situation:"Intervention sur bâtiment construit avant le 1er janvier 1997 sans diagnostic amiante préalable",dommages:"Mésothéliome, cancer broncho-pulmonaire — maladie professionnelle irréversible",gravite:4,probabilite:2}],
    actions:[
      "Exiger le Dossier Technique Amiante (DTA) avant toute intervention (art. R4412-97 CT)",
      "Faire réaliser un repérage amiante avant travaux (RAT) par un opérateur certifié COFRAC",
      "Si amiante détecté : faire appel à une entreprise certifiée sous-section 3 (désamiantage) ou section 4 (maintenance amiante)",
      "Former les compagnons à la sensibilisation amiante (SS4 obligatoire pour toute intervention sur matériaux amiantés)",
      "Ne jamais intervenir sur un matériau susceptible de contenir de l'amiante sans diagnostic préalable",
    ],
    epi:["Combinaison jetable type 5/6","Masque FFP3 ou APR","Gants nitrile"],controle:"Avant chaque chantier sur bâtiment avant 1997",type:"obligatoire"},

  "Poussières de silice cristalline":{ risques:[
    {danger:"Silicose / cancer pulmonaire",situation:"Perçage, découpe ou meulage de béton, pierre, brique sans aspiration ni protection",dommages:"Silicose (maladie professionnelle irréversible), cancer pulmonaire",gravite:4,probabilite:3}],
    actions:[
      "Utiliser des outils équipés d'aspiration intégrée (systèmes dits 'bas-émissifs')",
      "Travailler à l'humide pour abattre les poussières (aspersion d'eau)",
      "Porter un masque FFP2 minimum (FFP3 préférable pour opérations intensives)",
      "Respecter les VLEP : 0,1 mg/m³ pour la silice cristalline (art. R4412-149 CT)",
      "Réaliser des mesures d'empoussièrement si exposition régulière",
      "Inclure la silice dans le bilan de suivi médical renforcé",
    ],
    epi:["Masque FFP2 minimum","Lunettes de protection","Combinaison à usage unique"],controle:"Mesure d'empoussièrement si exposition > 2h/jour",type:"obligatoire"},

  "Coactivité (entreprises extérieures)":{ risques:[
    {danger:"Accident par interférence entre entreprises",situation:"Plusieurs entreprises travaillent simultanément sans coordination",dommages:"Collision, chute d'objet, électrisation par réseau d'une autre entreprise",gravite:4,probabilite:2}],
    actions:[
      "Désigner un coordonnateur SPS si opération soumise à coordination (art. L4532-4 CT)",
      "Organiser une réunion de coordination hebdomadaire minimum sur les chantiers multi-entreprises",
      "Mettre en place un plan de circulation et délimiter les zones de chaque entreprise",
      "Informer chaque sous-traitant des risques spécifiques du site et des mesures de prévention",
    ],
    epi:[],controle:"Réunion de coordination hebdomadaire",type:"obligatoire"},

  "Engins de chantier (pelle, grue, nacelle)":{ risques:[
    {danger:"Ecrasement par engin",situation:"Personnel à pied dans le rayon d'action d'un engin sans plan de circulation",dommages:"Écrasement, traumatisme fatal",gravite:4,probabilite:2},
    {danger:"Chute de charge",situation:"Levage sans zone de sécurité délimitée en dessous",dommages:"Traumatisme grave, décès",gravite:4,probabilite:1}],
    actions:[
      "Etablir un plan de circulation chantier séparant piétons et engins",
      "Désigner des guideurs de manœuvre formés (CACES requis)",
      "Délimiter et signaler la zone de levage (interdire l'accès pendant les manutentions)",
      "Vérifier la VGP des engins (annuelle pour engins > 1t)",
      "S'assurer que tous les conducteurs possèdent le CACES adapté à l'engin",
    ],
    epi:["Casque","Gilet haute visibilité classe 3","Chaussures de sécurité"],controle:"VGP annuelle + CACES à jour",type:"obligatoire"},

  "Réseaux aériens (lignes électriques)":{ risques:[
    {danger:"Electrisation par ligne électrique aérienne",situation:"Engin ou matériau trop proche d'une ligne HTA/HTB",dommages:"Electrisation, arc électrique, décès",gravite:4,probabilite:1}],
    actions:[
      "Identifier toutes les lignes aériennes avant démarrage du chantier (DT auprès du gestionnaire)",
      "Respecter les distances minimales d'approche : 3 m pour BT, 5 m pour HTA, pour les engins",
      "Faire neutraliser ou déplacer la ligne par le gestionnaire si impossible à respecter",
      "Signaler les lignes par des balisages visibles depuis le poste de conduite",
    ],
    epi:[],controle:"Avant démarrage + rappel aux conducteurs",type:"obligatoire"},

  "Intempéries / travail par temps extrême":{ risques:[
    {danger:"Hypothermie / coup de chaleur",situation:"Travail extérieur en conditions climatiques extrêmes sans mesures d'adaptation",dommages:"Hypothermie, coup de chaleur, accident lié à la perte de vigilance",gravite:3,probabilite:3},
    {danger:"Chute en hauteur par sol glissant",situation:"Toiture ou échafaudage glissant après pluie, neige ou gel",dommages:"Chute mortelle",gravite:4,probabilite:2}],
    actions:[
      "Surveiller les alertes météo (plan canicule, plan grand froid) — adapter ou suspendre les travaux en hauteur",
      "Interdire l'accès aux toitures et échafaudages par temps de gel, pluie verglaçante ou vent fort (> 100 km/h)",
      "Mettre à disposition des boissons fraîches en été et des locaux chauffés en hiver",
      "Plan canicule : pauses à l'ombre toutes les heures si température > 33°C",
    ],
    epi:["Vêtements de pluie","Vêtements chauds selon saison","Crème solaire index 50+ en été"],controle:"Suivi quotidien des alertes météo",type:"obligatoire"},


  "Machine à risque de happement (pétrin, malaxeur)":{ risques:[
    {danger:"Happement / écrasement des membres",situation:"Introduction de la main dans la cuve ou les organes en mouvement",dommages:"Écrasement, fracture, amputation",gravite:4,probabilite:1}],
    actions:["Vérifier la présence et le bon état du protecteur de cuve avant chaque utilisation","Interdire toute intervention (nettoyage, raclage) machine en marche","Vérifier le fonctionnement de l'arrêt d'urgence"],
    epi:["Gants adaptés (hors machine en marche)"],controle:"VGP annuelle machine",type:"obligatoire"},

  "Diviseuse / façonneuse":{ risques:[
    {danger:"Écrasement / coupure des doigts",situation:"Introduction de la main dans la zone de division ou de façonnage en fonctionnement",dommages:"Écrasement, coupure profonde, amputation partielle",gravite:3,probabilite:2}],
    actions:["Vérifier le protecteur et le dispositif d\u2019arrêt avant chaque service","Interdire le dégagement de pâte machine en marche","Former à l\u2019utilisation avant toute autonomie"],
    epi:["Gants adaptés (hors machine en marche)"],controle:"VGP annuelle",type:"obligatoire"},
};

/* ==================== RISQUES TRANSVERSES ==================== */
const RISQUES_TRANSVERSES = [
  { code:"RPS", nom:"Risques psychosociaux",
    condition:(pop)=> pop.salaries>0,
    situation:"Charge de travail, relations dégradées, stress chronique",
    dommages:"Épuisement professionnel, troubles anxieux",gravite:3,probabilite:2,
    actions:["Mettre en place un espace d'échange régulier sur la charge de travail","Former l'encadrement à la prévention des RPS"],type:"inrs" },
  { code:"ROUTIER", nom:"Risque routier",
    condition:(pop)=> pop.deplacements===true,
    situation:"Trajets professionnels réguliers sans politique de prévention",
    dommages:"Accident de la route, traumatisme grave",gravite:4,probabilite:1,
    actions:["Faire contrôler les véhicules professionnels","Sensibiliser aux bonnes pratiques de conduite professionnelle"],type:"obligatoire" },
  { code:"ISOLE", nom:"Travail isolé",
    condition:(pop)=> pop.travailIsole===true,
    situation:"Salarié seul sans moyen d'alerte",
    dommages:"Retard de secours, aggravation d'un accident",gravite:3,probabilite:2,
    actions:["Mettre en place un DATI ou un appel programmé","Définir une procédure d'alerte travailleur isolé"],type:"obligatoire" },
  { code:"JEUNES", nom:"Jeunes travailleurs",
    condition:(pop)=> pop.jeunesTravailleurs===true,
    situation:"Travaux interdits ou réglementés pour les mineurs, manque d'expérience",
    dommages:"Accident lié au manque d'expérience ou affectation à des travaux interdits",gravite:3,probabilite:2,
    actions:["Vérifier l'absence d'affectation à des travaux interdits aux mineurs","Renforcer l'encadrement et la formation à l'arrivée"],type:"obligatoire" },
  { code:"INTERIM", nom:"Intérimaires / apprentis / stagiaires",
    condition:(pop)=> pop.interimaires===true||pop.apprentis===true,
    situation:"Personnel temporaire moins familiarisé avec les risques du poste",
    dommages:"Accident lié au manque d'information ou d'expérience",gravite:3,probabilite:2,
    actions:["Réaliser un accueil sécurité renforcé pour tout nouvel arrivant temporaire","Désigner un tuteur"],type:"obligatoire" },
  { code:"VULNERABLE", nom:"Salariés vulnérables (indicateur collectif)",
    condition:(pop)=> pop.vulnerables===true,
    situation:"Situations de vulnérabilité signalées (sans données nominatives de santé)",
    dommages:"Aggravation d'une situation de santé par absence d'adaptation",gravite:2,probabilite:2,
    actions:["Étudier les adaptations de poste en lien avec le SPST"],type:"obligatoire" },
  { code:"AMBIANCE_THERM", nom:"Ambiances thermiques",
    condition:(pop)=> pop.salaries>0,
    situation:"Exposition à la chaleur ou au froid selon l'activité et la saison",
    dommages:"Coup de chaleur, hypothermie, baisse de vigilance",gravite:2,probabilite:2,
    actions:["Adapter l'organisation du travail lors de fortes chaleurs ou grand froid","Mettre à disposition de l'eau fraîche"],type:"inrs" },
];

/* ==================== FICHES DE POSTE PAR MÉTIER ==================== */
const FICHES_POSTE = {
  restaurant:["Cuisinier","Commis de cuisine","Serveur","Chef de rang","Plongeur","Employé polyvalent"],
  boulangerie:["Boulanger","Pâtissier","Vendeur(se)"],
  garage:["Mécanicien","Électricien auto","Réceptionnaire","Magasinier"],
  coiffeur:["Coiffeur(se)","Apprenti(e)","Coloriste"],
  tatoueur:["Tatoueur(se)","Perceur(se)"],
  pharmacie:["Pharmacien","Préparateur en pharmacie","Vendeur(se) parapharmacie"],
  cabinet_medical:["Médecin","Infirmier(ère)","Secrétaire médical(e)"],
  default:["Gérant","Employé polyvalent","Apprenti(e)"],
};

/* ==================== MENTIONS RÉGLEMENTAIRES ==================== */
const REGLEMENTAIRE = {
  base:"Document d'accompagnement établi à partir des informations transmises, des observations réalisées et du DUERP. Il constitue une aide à l'évaluation et à la priorisation des actions de prévention. Il ne se substitue ni à la responsabilité de l'employeur, ni aux vérifications réglementaires réalisées par des organismes compétents lorsque celles-ci sont requises.",
  miseAJour:"Mise à jour du DUERP : au moins annuelle à partir de 11 salariés (art. R4121-2 CT), et dans tous les cas lors de toute décision d'aménagement important ou information nouvelle. Le programme annuel de prévention (PAPRIPACT) n'est obligatoire qu'à partir de 50 salariés (art. L4121-3-1 III CT) ; en dessous, une liste d'actions consignée dans le DUERP suffit (L4121-3-1 IV CT).",
  conservation:"Chaque version du DUERP doit être conservée 40 ans par l'employeur (Décret 2022-395 du 31 mars 2022, art. R4121-4 CT). Le document doit être mis à disposition des salariés, du CSE, du médecin du travail et de l'inspection du travail.",
  hierarchie:"Art. L4121-2 CT — ordre de priorité obligatoire : 1) Supprimer le risque à la source 2) Substituer 3) Protection collective (EPC) 4) Organisation du travail 5) Formation et information 6) EPI en dernier recours.",
  mention_validation:"Ce document est une aide à l'évaluation des risques professionnels. Il ne se substitue pas au jugement du Conseil en Qualité, Sécurité et Environnement ni à la responsabilité de l'employeur.",
  mention_epi:"Les EPI sont une mesure de dernier recours (art. L4121-2 CT). Ils ne suppriment pas le risque et doivent toujours être précédés de mesures de protection collective.",
  cmr:"Pour tout agent CMR, l'employeur doit rechercher la substitution (art. L4412-2 CT), tenir un registre d'exposition nominatif conservé 40 ans (art. R4412-40 CT) et remettre une fiche d'exposition individuelle à chaque salarié concerné.",
  tva:"TVA non applicable, article 293 B du CGI.",
};

const GRILLE_COTATION = {
  gravite:[
    {val:1,label:"Faible",desc:"Blessure légère sans arrêt de travail (égratignure, contusion mineure)"},
    {val:2,label:"Modérée",desc:"Accident avec arrêt de travail, blessure réversible"},
    {val:3,label:"Grave",desc:"Incapacité permanente partielle (IPP), séquelles durables"},
    {val:4,label:"Très grave",desc:"Décès ou incapacité permanente totale"},
  ],
  probabilite:[
    {val:1,label:"Très improbable",desc:"Situation exceptionnelle, moins d'une fois par an"},
    {val:2,label:"Peu probable",desc:"Situation rare, quelques fois par an"},
    {val:3,label:"Probable",desc:"Situation fréquente, plusieurs fois par mois"},
    {val:4,label:"Très probable",desc:"Situation quotidienne ou quasi permanente"},
  ],
  niveaux:[
    {min:1,max:3,label:"Modéré",couleur:"green",action:"Surveillance — action à planifier"},
    {min:4,max:8,label:"Élevé",couleur:"orange",action:"Action corrective dans les 3 mois"},
    {min:9,max:16,label:"Critique",couleur:"red",action:"Action immédiate requise"},
  ],
};

const TRAVAUX_INTERDITS_MINEURS = [
  "Exposition agents CMR catégorie 1A/1B",
  "Rayonnements ionisants (zone réglementée)",
  "Travaux en milieu hyperbare",
  "Températures extrêmes (>50°C ou <-20°C)",
  "Installations électriques sous tension",
  "Conduite chariots élévateurs, engins (sans dérogation DREETS)",
  "Tronçonneuses, scies circulaires portatives (sans dérogation)",
  "Port de charges > 15 kg",
];

const TRAVAUX_INTERDITS_ENCEINTES = [
  "Port de charges lourdes (art. D1225-1 CT)",
  "Exposition agents CMR (art. D4152-10 CT)",
  "Bruit > 85 dB(A) (art. D4152-2 CT)",
  "Vibrations > valeurs d'action (art. D4152-2 CT)",
  "Station debout prolongée sans assise",
  "Travaux de nuit sans accord médecin du travail",
  "Agents biologiques dangereux (groupes 2, 3, 4)",
];

/* ==================== MENTIONS RGPD ==================== */
const MENTIONS_RGPD = {
  finalite:"Données collectées pour la seule finalité de l'évaluation des risques professionnels (DUERP) et du plan d'actions.",
  minimisation:"Aucune donnée nominative de santé. Les situations de vulnérabilité sont uniquement renseignées sous forme d'indicateur collectif.",
  photos:"Éviter de photographier les visages. Toute photo où une personne serait reconnaissable doit être recadrée ou supprimée.",
  conservation:"Données stockées localement sur l'appareil du consultant. Aucune transmission à un serveur tiers.",
  droits:"Le client peut demander la suppression de sa fiche et de ses visites, ainsi que l'export de ses données.",
};

/* ==================== CONFIG TARIFICATION INTELLIGENTE ==================== */
const TARIF_CONFIG = {
  effectifTranches:[
    { max:5, mult:1.0 }, { max:10, mult:1.1 }, { max:20, mult:1.2 },
    { max:50, mult:1.35 }, { max:100, mult:1.5 }, { max:Infinity, mult:1.7 }
  ],
  complexite:{ simple:1.0, moderee:1.2, complexe:1.5 },
};

function calculerPrixAdapte(prixBase, effectif, complexite="simple") {
  const eff = Number(effectif) || 1;
  const tranche = TARIF_CONFIG.effectifTranches.find(t => eff <= t.max) || TARIF_CONFIG.effectifTranches[0];
  const multC = TARIF_CONFIG.complexite[complexite] || 1;
  return Math.ceil((prixBase * tranche.mult * multC) / 10) * 10;
}

/* ==================== DÉTECTION OPPORTUNITÉS COMMERCIALES ==================== */
function detecterUpsell(visit) {
  const suggestions = [];
  const { risques, actions } = (typeof PF24_ENGINE !== 'undefined') ? PF24_ENGINE.genererRisques(visit) : { risques:[], actions:[] };

  // Fiches de poste et registre sécurité sont INCLUS dans chaque dossier DUERP — ne pas les proposer en upsell

  // Accompagnement si beaucoup d'actions
  if (actions.length > 15) suggestions.push({
    id:"accompagnement",
    raison:"Vous avez " + actions.length + " actions prioritaires → un accompagnement dans la mise en œuvre peut être proposé"
  });

  // Risque chimique / FDS
  const hasFDS = Object.values(visit.blocs||{}).some(b =>
    Object.values(b.objets||{}).some(o => o.statut==="present" && (o.observation||"").toLowerCase().includes("fds")));
  if (!hasFDS && (visit.blocsSelectionnes||[]).includes("chimiques")) suggestions.push({
    id:"chimique",
    raison:"Produits chimiques présents → vérifier et constituer le classeur FDS (Fiches de Données de Sécurité)"
  });

  // Mise à jour annuelle si dossier déjà existant (historique > 0)
  if ((visit.historique||[]).length > 1) suggestions.push({
    id:"maj",
    raison:"Ce client a déjà " + visit.historique.length + " version(s) → proposer un contrat de suivi annuel"
  });

  return suggestions;
}
