/* ================================================================
   PF24 — Convertisseur HTML → DOCX (OOXML natif)
   Génère de vrais fichiers Word compatibles Word iOS/Android/Desktop,
   Pages, LibreOffice — sans altChunk.
   Dépendance : JSZip (jszip.min.js)
   ================================================================ */

const PF24_DOCX = (() => {

  function esc(t) {
    return String(t)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
      // Retirer emojis et caractères non-XML
      .replace(/[\u{1F000}-\u{1FAFF}\u{1F1E6}-\u{1F1FF}\u{FE00}-\u{FE0F}\u{200D}]/gu, '')
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  }

  /* Couleurs PF24 par classe CSS (les <style> ne sont pas parsés, on mappe ici) */
  const CLASS_FILLS = {
    'header':'0B1B33', 'urgence':'D63B3B',
    'legal':'FFF3CD', 'epi-box':'E5F6ED',
    'crit':'D63B3B', 'risk-crit':'D63B3B',
    'elev':'E8821C', 'risk-elev':'E8821C',
    'mod':'1E9E63',  'risk-mod':'1E9E63',
    'ok':'E5F6ED', 'nok':'FDE8E8', 'av':'FFF0E0',
    'saisir':'FFFDE7', 'danger':'FDE8E8',
  };
  const DARK_FILLS = ['0B1B33','D63B3B','E8821C','1E9E63'];

  function bgFromClass(el){
    const cls = (el.getAttribute('class')||'').split(/\s+/);
    for(const c of cls){ if(CLASS_FILLS[c]) return CLASS_FILLS[c]; }
    return null;
  }

  /* Extraire le background-color d'un style inline (retourne hex sans # ou null) */
  function bgFromStyle(el) {
    const s = (el.getAttribute('style') || '') + ';' + (el.getAttribute('bgcolor') || '');
    const m = s.match(/background(?:-color)?\s*:\s*#?([0-9a-fA-F]{6})/);
    return m ? m[1].toUpperCase() : bgFromClass(el);
  }

  /* Coloration conditionnelle par contenu (Critique/Élevé/Modéré) */
  function bgFromContent(txt){
    const t = txt.trim();
    if(/^Critique/i.test(t)) return 'D63B3B';
    if(/^[ÉE]lev[ée]/i.test(t)) return 'E8821C';
    if(/^Modéré/i.test(t)) return '1E9E63';
    return null;
  }

  /* Génère les runs (<w:r>) d'un nœud inline */
  function runs(node, fmt) {
    fmt = fmt || {};
    let out = '';
    node.childNodes.forEach(ch => {
      if (ch.nodeType === 3) {
        const t = ch.textContent;
        if (t) {
          let rPr = '';
          if (fmt.bold) rPr += '<w:b/>';
          if (fmt.italic) rPr += '<w:i/>';
          if (fmt.color) rPr += `<w:color w:val="${fmt.color}"/>`;
          if (fmt.size) rPr += `<w:sz w:val="${fmt.size}"/><w:szCs w:val="${fmt.size}"/>`;
          out += `<w:r>${rPr ? '<w:rPr>' + rPr + '</w:rPr>' : ''}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>`;
        }
      } else if (ch.nodeType === 1) {
        const tag = ch.nodeName;
        if (tag === 'BR') out += '<w:r><w:br/></w:r>';
        else if (tag === 'STRONG' || tag === 'B') out += runs(ch, { ...fmt, bold: true });
        else if (tag === 'EM' || tag === 'I') out += runs(ch, { ...fmt, italic: true });
        else if (tag === 'SMALL') out += runs(ch, { ...fmt, size: 16 });
        else if (tag === 'A') out += runs(ch, fmt);
        else if (tag === 'SPAN') out += runs(ch, fmt);
        else out += runs(ch, fmt);
      }
    });
    return out;
  }

  /* Paragraphe complet */
  function para(node, opts) {
    opts = opts || {};
    let pPr = '';
    if (opts.style) pPr += `<w:pStyle w:val="${opts.style}"/>`;
    if (opts.shading) pPr += `<w:shd w:val="clear" w:color="auto" w:fill="${opts.shading}"/>`;
    if (opts.spacing) pPr += `<w:spacing w:before="${opts.spacing.before||0}" w:after="${opts.spacing.after||120}"/>`;
    const r = typeof node === 'string'
      ? `<w:r><w:t xml:space="preserve">${esc(node)}</w:t></w:r>`
      : runs(node, opts.fmt);
    const empty = '<w:r><w:t xml:space="preserve">' + (opts.padEmpty ? '\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0' : ' ') + '</w:t></w:r>';
    return `<w:p>${pPr ? '<w:pPr>' + pPr + '</w:pPr>' : ''}${r || empty}</w:p>`;
  }

  const CELL_BORDERS = '<w:tcBorders><w:top w:val="single" w:sz="4" w:color="CCCCCC"/><w:left w:val="single" w:sz="4" w:color="CCCCCC"/><w:bottom w:val="single" w:sz="4" w:color="CCCCCC"/><w:right w:val="single" w:sz="4" w:color="CCCCCC"/></w:tcBorders>';

  /* Table complète */
  function table(node) {
    let rows = '';
    const trs = node.querySelectorAll(':scope > thead > tr, :scope > tbody > tr, :scope > tr');
    trs.forEach(tr => {
      let cells = '';
      tr.querySelectorAll(':scope > th, :scope > td').forEach(cell => {
        const isTh = cell.nodeName === 'TH';
        const colspan = parseInt(cell.getAttribute('colspan') || '1');
        let bg = bgFromStyle(cell) || (isTh ? '0B1B33' : null);
        if(!bg) bg = bgFromContent(cell.textContent||'');   // Critique/Élevé/Modéré auto
        let tcPr = '<w:tcPr>';
        if (colspan > 1) tcPr += `<w:gridSpan w:val="${colspan}"/>`;
        if (bg) tcPr += `<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>`;
        tcPr += CELL_BORDERS + '<w:vAlign w:val="top"/></w:tcPr>';
        const onDark = bg && DARK_FILLS.includes(bg);
        const fmt = isTh ? { bold: true, color: 'FFFFFF', size: 16 }
                         : { size: 18, color: onDark ? 'FFFFFF' : null, bold: onDark || undefined };
        // Une cellule peut contenir plusieurs blocs — on aplatit en un paragraphe avec <br>
        cells += `<w:tc>${tcPr}${para(cell, { fmt, padEmpty: !(cell.textContent||'').trim() })}</w:tc>`;
      });
      if (cells) rows += `<w:tr>${cells}</w:tr>`;
    });
    return `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblLayout w:type="autofit"/></w:tblPr>${rows}</w:tbl><w:p/>`;
  }

  /* Parcours du body HTML */
  function walk(node) {
    let out = '';
    node.childNodes.forEach(ch => {
      if (ch.nodeType === 3) {
        if (ch.textContent.trim()) out += para(ch.textContent.trim());
        return;
      }
      if (ch.nodeType !== 1) return;
      switch (ch.nodeName) {
        case 'H1': out += para(ch, { style: 'Heading1' }); break;
        case 'H2': out += para(ch, { style: 'Heading2', shading: bgFromStyle(ch) }); break;
        case 'H3': out += para(ch, { style: 'Heading3' }); break;
        case 'P': out += para(ch, { fmt: { size: 20 } }); break;
        case 'TABLE': out += table(ch); break;
        case 'UL': case 'OL':
          ch.querySelectorAll(':scope > li').forEach(li => {
            out += `<w:p><w:pPr><w:ind w:left="360"/></w:pPr><w:r><w:t xml:space="preserve">• </w:t></w:r>${runs(li, { size: 20 })}</w:p>`;
          });
          break;
        case 'DIV': {
          const bg = bgFromStyle(ch);
          // Header boxes: rendre les enfants avec un shading
          if (bg && !ch.querySelector('table')) {
            const onDark = DARK_FILLS.includes(bg);
            ch.childNodes.forEach(sub => {
              if (sub.nodeType === 1 && sub.nodeName === 'H1')
                out += para(sub, { shading: bg, fmt: { bold:true, size:30, color: onDark?'FFFFFF':'0B1B33' } });
              else if (sub.nodeType === 1 || (sub.nodeType === 3 && sub.textContent.trim()))
                out += para(sub.nodeType === 1 ? sub : sub.textContent.trim(),
                  { shading: bg, fmt: { color: onDark ? 'FFFFFF' : null, size: 18 } });
            });
            out += '<w:p/>';
          } else {
            out += walk(ch);
          }
          break;
        }
        default: out += walk(ch);
      }
    });
    return out;
  }

  const STYLES_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr></w:rPrDefault>
  <w:pPrDefault><w:pPr><w:spacing w:after="120"/></w:pPr></w:pPrDefault></w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/>
    <w:pPr><w:spacing w:before="240" w:after="180"/><w:pBdr><w:bottom w:val="single" w:sz="12" w:color="1E9E63"/></w:pBdr></w:pPr>
    <w:rPr><w:b/><w:sz w:val="32"/><w:szCs w:val="32"/><w:color w:val="0B1B33"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/>
    <w:pPr><w:spacing w:before="240" w:after="120"/><w:shd w:val="clear" w:color="auto" w:fill="0B1B33"/></w:pPr>
    <w:rPr><w:b/><w:sz w:val="24"/><w:szCs w:val="24"/><w:color w:val="FFFFFF"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/>
    <w:pPr><w:spacing w:before="180" w:after="90"/></w:pPr>
    <w:rPr><w:b/><w:sz w:val="21"/><w:szCs w:val="21"/><w:color w:val="16294A"/></w:rPr></w:style>
</w:styles>`;

  const CONTENT_TYPES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="png" ContentType="image/png"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`;

  const RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const DOC_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  __LOGO_REL__
</Relationships>`;

  /* API principale : html string → Promise<Blob docx> */
  const LOGO_DRAWING = `<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="900000" cy="900000"/><wp:docPr id="1" name="LogoPF24"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="1" name="LogoPF24"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdLogo"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="900000" cy="900000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;

  async function fromHtml(html, opts) {
    opts = opts || {};
    if (typeof JSZip === 'undefined') throw new Error('JSZip non chargé');
    const parser = new DOMParser();
    const dom = parser.parseFromString(html, 'text/html');
    let bodyXml = walk(dom.body);
    const hasLogo = opts.logo && /^data:image\/png;base64,/.test(opts.logo);
    if (hasLogo) bodyXml = LOGO_DRAWING + bodyXml;

    const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
  xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
  xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
  xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
  <w:body>
    ${bodyXml}
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>`;

    const zip = new JSZip();
    zip.file('[Content_Types].xml', CONTENT_TYPES);
    zip.folder('_rels').file('.rels', RELS);
    const word = zip.folder('word');
    word.file('document.xml', documentXml);
    word.file('styles.xml', STYLES_XML);
    const rels = DOC_RELS.replace('__LOGO_REL__', hasLogo
      ? '<Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/logo.png"/>'
      : '');
    word.folder('_rels').file('document.xml.rels', rels);
    if (hasLogo) word.folder('media').file('logo.png', opts.logo.split(',')[1], { base64: true });

    return zip.generateAsync({
      type: 'blob',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      compression: 'DEFLATE'
    });
  }

  return { fromHtml };
})();
