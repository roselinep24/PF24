/* ================================================================
   DONNÉES CENTRALES PF24 — utilisées par tous les documents
   Aucune valeur ne doit être inventée : si absente → mention explicite.
   ================================================================ */
const A_COMPLETER = "À compléter par l'employeur : ______";
function acVal(v){ return (v!==undefined && v!==null && String(v).trim()!=="" && v!=="—") ? v : A_COMPLETER; }
function PF24_META(visit){
  const now = new Date();
  return {
    date: now.toLocaleDateString("fr-FR"),
    heure: now.toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}),
    version: (visit&&visit.historique&&visit.historique.length)||1,
  };
}
function PF24_PROFILE(visit, client){
  client = client||{};
  const cons = PF24_DB.getConsultant()||{};
  return {
    company: {
      nom: acVal(client.nom), siret: acVal(client.siret), ape: client.ape||"",
      adresse: acVal(client.adresse), activite: acVal(client.activite),
      effectif: (client.salaries!==undefined&&client.salaries!=="")?client.salaries:A_COMPLETER,
      dirigeant: acVal(client.valideur||client.contact),
      fonctionDirigeant: client.fonctionDirigeant||"Dirigeant",
      telephone: client.telephone||"", email: client.email||"",
    },
    prevention: {
      spst: acVal(client.spst), spstTel: client.spstTel||A_COMPLETER,
      referent: client.referentSecurite||A_COMPLETER, referentTel: client.referentTel||"",
      trousse: client.trousseLocalisation||A_COMPLETER,
      rassemblement: client.pointRassemblement||A_COMPLETER,
    },
    mission: {
      consultant: acVal(cons.nom), fonction: cons.fonction||"Conseil en Qualité, Sécurité et Environnement",
      email: cons.email||"", telephone: cons.telephone||"",
    },
    meta: PF24_META(visit),
  };
}
/* PF24 V3 — Générateur PDF premium : DUERP, Devis, Factures */
const PF24_PDF = (() => {
  const NAVY=[11,27,51], WHITE=[255,255,255], GREY=[91,100,114],
    GREEN=[30,158,99], ORANGE=[232,130,28], RED=[214,59,59], LINE=[226,230,237];
  function c(col){ return col==="red"?RED:col==="orange"?ORANGE:GREEN; }
  function hdr(doc,title){ doc.setFillColor(...NAVY); doc.rect(0,0,210,22,"F"); doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(12); doc.text("PF24 — Prévention Facile",14,14); doc.setFontSize(8.5); doc.setFont("helvetica","normal"); doc.text(title,196,14,{align:"right"}); }
  function ftr(doc,pg){ doc.setFontSize(8); doc.setTextColor(...GREY);
    const pp=((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage;
    doc.text(`${pp||"PF24 QSE — Prévention Facile"} — Page ${pg}`,105,290,{align:"center"}); }
  function addLogo(doc,x,y,s){ try{ if(window.PF24_LOGO) doc.addImage(window.PF24_LOGO,"PNG",x,y,s,s); }catch(e){} }
  function formatPrix(n){ return Number(n||0).toFixed(2).replace(".",",")}

  /* ======================== DEVIS PDF ======================== */
  async function generateDevis(devis, client, consultant){
    const {jsPDF}=window.jspdf; const doc=new jsPDF({unit:"mm",format:"a4"});
    addLogo(doc,180,8,16);
    // Header navy bar
    doc.setFillColor(...NAVY); doc.rect(0,0,210,50,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(22);
    doc.text("DEVIS",14,22);
    doc.setFontSize(12); doc.text(devis.numero,14,32);
    doc.setFontSize(9); doc.setFont("helvetica","normal");
    doc.text("Date : "+new Date(devis.date).toLocaleDateString("fr-FR"),14,41);
    doc.text("Valable 30 jours",14,47);
    // Consultant block
    doc.setTextColor(...NAVY); doc.setFontSize(9.5); doc.setFont("helvetica","bold");
    doc.text(consultant.nom||"Consultant PF24",140,32); doc.setFont("helvetica","normal");
    doc.text(consultant.activite||"",140,38); doc.text(consultant.email||"",140,44);
    doc.text(consultant.telephone||"",140,50);
    // Client block
    doc.setFillColor(247,249,251); doc.roundedRect(14,58,85,40,3,3,"F");
    doc.setFont("helvetica","bold"); doc.setFontSize(9); doc.setTextColor(...GREY);
    doc.text("CLIENT",18,66); doc.setTextColor(...NAVY); doc.setFontSize(11);
    doc.text(client.nom||"",18,73); doc.setFontSize(9); doc.setFont("helvetica","normal");
    doc.text(client.adresse||"",18,79); doc.text(client.email||"",18,85); doc.text(client.telephone||"",18,91);
    // Prestation tableau
    doc.autoTable({ startY:108,
      head:[["Prestation","Qté","Prix unitaire","Total"]],
      body:devis.lignes.map(l=>{ const nom=l.remise>0?l.nom+" (offre -"+l.remise+"%)":l.nom; return [nom,l.qte,formatPrix(l.prixUnit)+" €",formatPrix(l.total)+" €"]; }),
      styles:{fontSize:9.5,cellPadding:3.5},
      headStyles:{fillColor:NAVY,textColor:255,fontSize:9},
      columnStyles:{0:{cellWidth:100},1:{cellWidth:20,halign:"center"},2:{cellWidth:35,halign:"right"},3:{cellWidth:30,halign:"right"}},
    });
    const y=doc.lastAutoTable.finalY+8;
    // Total
    doc.setFillColor(...NAVY); doc.roundedRect(130,y,66,24,3,3,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(11);
    doc.text("TOTAL HT",134,y+9); doc.setFontSize(16);
    doc.text(formatPrix(devis.total)+" €",194,y+18,{align:"right"});
    // TVA mention
    doc.setTextColor(...GREY); doc.setFontSize(8.5); doc.setFont("helvetica","italic");
    doc.text(REGLEMENTAIRE.tva,14,y+10);
    // Terms
    doc.setTextColor(80,80,80); doc.setFont("helvetica","normal"); doc.setFontSize(8.5);
    doc.text("Ce devis est valable 30 jours à compter de sa date d'émission.",14,y+18);
    if(devis.commentaire) doc.text("Commentaire : "+devis.commentaire,14,y+25);
    // Signature
    doc.setDrawColor(...LINE); doc.line(14,y+45,90,y+45); doc.line(120,y+45,196,y+45);
    doc.setFontSize(8.5); doc.setTextColor(...GREY);
    doc.text("Signature consultant",52,y+50,{align:"center"}); doc.text("Bon pour accord — Signature client",158,y+50,{align:"center"});
    return doc;
  }

  /* ======================== FACTURE PDF ======================== */
  async function generateFacture(facture, client, consultant){
    const {jsPDF}=window.jspdf; const doc=new jsPDF({unit:"mm",format:"a4"});
    addLogo(doc,180,8,16);
    doc.setFillColor(...NAVY); doc.rect(0,0,210,50,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(22);
    doc.text("FACTURE",14,22); doc.setFontSize(12); doc.text(facture.numero,14,32);
    doc.setFontSize(9); doc.setFont("helvetica","normal");
    doc.text("Date : "+new Date(facture.date).toLocaleDateString("fr-FR"),14,41);
    const ech=facture.dateEcheance?new Date(facture.dateEcheance).toLocaleDateString("fr-FR"):"30 jours";
    doc.text("Échéance : "+ech,14,47);
    doc.setTextColor(...NAVY); doc.setFontSize(9.5); doc.setFont("helvetica","bold");
    doc.text(consultant.nom||"Consultant PF24",140,32); doc.setFont("helvetica","normal"); doc.setFontSize(9);
    doc.text(consultant.activite||"",140,38); doc.text(consultant.email||"",140,44); doc.text(consultant.telephone||"",140,50);
    doc.setFillColor(247,249,251); doc.roundedRect(14,58,85,40,3,3,"F");
    doc.setFont("helvetica","bold"); doc.setFontSize(9); doc.setTextColor(...GREY);
    doc.text("FACTURER À",18,66); doc.setTextColor(...NAVY); doc.setFontSize(11);
    doc.text(client.nom||"",18,73); doc.setFontSize(9); doc.setFont("helvetica","normal");
    doc.text(client.adresse||"",18,79); doc.text(client.email||"",18,85); if(client.siret) doc.text("SIRET : "+client.siret,18,91);
    // Statut badge
    const statutCols={"payee":[30,158,99],"impayee":[214,59,59],"envoyee":[232,130,28]};
    const sc=statutCols[facture.statut]||[91,100,114];
    doc.setFillColor(...sc); doc.roundedRect(130,60,66,22,3,3,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(11);
    const statLabels={payee:"✓ PAYÉE",impayee:"⚠ IMPAYÉE",envoyee:"📤 ENVOYÉE",brouillon:"BROUILLON"};
    doc.text(statLabels[facture.statut]||facture.statut,163,74,{align:"center"});
    doc.autoTable({ startY:108,
      head:[["Prestation","Qté","Prix unitaire","Total"]],
      body:facture.lignes.map(l=>[l.nom,l.qte,formatPrix(l.prixUnit)+" €",formatPrix(l.total)+" €"]),
      styles:{fontSize:9.5,cellPadding:3.5},
      headStyles:{fillColor:NAVY,textColor:255,fontSize:9},
      columnStyles:{0:{cellWidth:100},1:{cellWidth:20,halign:"center"},2:{cellWidth:35,halign:"right"},3:{cellWidth:30,halign:"right"}},
    });
    const y=doc.lastAutoTable.finalY+8;
    doc.setFillColor(...NAVY); doc.roundedRect(110,y,86,34,3,3,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","normal"); doc.setFontSize(9.5);
    doc.text("Total HT :",114,y+9); doc.text(formatPrix(facture.total)+" €",194,y+9,{align:"right"});
    if(facture.acompte>0){ doc.text("Acompte versé :",114,y+17); doc.text("-"+formatPrix(facture.acompte)+" €",194,y+17,{align:"right"}); }
    doc.setFont("helvetica","bold"); doc.setFontSize(13);
    doc.text("Solde à régler :",114,y+28); doc.text(formatPrix(facture.solde||facture.total)+" €",194,y+28,{align:"right"});
    doc.setTextColor(...GREY); doc.setFontSize(8); doc.setFont("helvetica","italic");
    doc.text(REGLEMENTAIRE.tva,14,y+10);
    doc.text("Paiement par virement bancaire — Coordonnées sur demande.",14,y+17);
    if(facture.commentaire) doc.text(facture.commentaire,14,y+24);
    return doc;
  }

  /* ======================== DOSSIER DUERP PDF ======================== */
  async function generateDossier(visit, client, risques, actions, score, scoreConf){
    const {jsPDF}=window.jspdf; const doc=new jsPDF({unit:"mm",format:"a4"});
    addLogo(doc,178,10,18);
    const consultant=PF24_DB.getConsultant();
    const versionNum=(visit.historique||[]).length||1;
    let pg=1;

    // === PAGE 1 COUVERTURE ===
    doc.setFillColor(...NAVY); doc.rect(0,0,210,297,"F");
    doc.setFillColor(...WHITE); doc.roundedRect(76,28,58,58,6,6,"F");
    if(window.PF24_LOGO){ try{ doc.addImage(window.PF24_LOGO,"PNG",80,32,50,50); }catch(e){
      doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(26); doc.text("PF24",105,62,{align:"center"}); }
    } else { doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(26); doc.text("PF24",105,62,{align:"center"}); }
    doc.setTextColor(...WHITE); doc.setFontSize(10); doc.setFont("helvetica","normal");
    doc.text("QSE — Qualité · Sécurité · Environnement",105,98,{align:"center"});
    doc.setFontSize(20); doc.setFont("helvetica","bold");
    doc.text("Dossier DUERP & Plan d'actions",105,140,{align:"center"});
    doc.setDrawColor(...WHITE); doc.line(60,152,150,152);
    doc.setFontSize(16); doc.text(client.nom||"",105,172,{align:"center"});
    doc.setFontSize(10); doc.setFont("helvetica","normal");
    doc.text(client.activite||"",105,180,{align:"center"});
    doc.text(client.adresse||"",105,187,{align:"center"});
    if(client.photoId){ try{ const du=await PF24_DB.getPhoto(client.photoId); if(du) doc.addImage(du,"JPEG",65,198,80,48,undefined,"FAST"); }catch(e){} }
    doc.setFontSize(9); doc.text(`Date : ${new Date().toLocaleDateString("fr-FR")}   •   Version DUERP v${versionNum}`,105,268,{align:"center"});
    doc.text(`Réalisé par : ${consultant.nom||"Consultant PF24"} — ${consultant.email||""}`,105,275,{align:"center"});

    // === PAGE 2 LETTRE DIRIGEANT ===
    // === PAGE SOMMAIRE / CADRE DE LA MISSION ===
    doc.addPage(); pg++; hdr(doc,"Sommaire");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Sommaire",14,33);
    doc.setFont("helvetica","normal"); doc.setFontSize(10); doc.setTextColor(...NAVY);
    const somItems=["1. Lettre au dirigeant","2. Tableau de bord des risques","3. Grille de cotation (référentiel G × P)","4. Mise à disposition du DUERP","5. Populations exposées","6. Actions prioritaires (Top 5)","7. Rapport détaillé par unité de travail","8. Document Unique (DUERP)","9. "+(Number(client.salaries)>=50?"PAPRIPACT":"Liste des actions de prévention"),"10. Synthèse de conformité réglementaire","11. Fiches de poste — Registre — Historique","12. Validation et signatures"];
    somItems.forEach((s,i)=>doc.text(s,18,46+i*8));
    // Cadre de la mission
    const ySom=46+somItems.length*8+8;
    doc.setFillColor(244,246,249); doc.roundedRect(14,ySom,182,80,3,3,"F");
    doc.setFont("helvetica","bold"); doc.setFontSize(10);
    doc.text("Cadre et limites de la mission",18,ySom+9);
    doc.setFont("helvetica","normal"); doc.setFontSize(8.5); doc.setTextColor(...GREY);
    const limites=[
      "Document d'accompagnement établi à partir des informations transmises, des observations réalisées",
      "et du DUERP. Il constitue une aide à l'évaluation et à la priorisation des actions de prévention.",
      "Il ne se substitue ni à la responsabilité de l'employeur, ni aux vérifications réglementaires",
      "réalisées par des organismes compétents lorsque celles-ci sont requises.",
      "PF24 QSE n'est pas un organisme certificateur, de contrôle technique ou d'inspection réglementaire.",
      "Les constats formulés reposent sur les éléments disponibles à la date de l'intervention.",
      "Les vérifications réglementaires (électricité, extincteurs, gaz, ventilation…) n'ont pas fait l'objet d'un",
      "audit technique : seule la présence ou l'absence des justificatifs a été relevée.",
      "PF24 QSE ne garantit ni la conformité globale ni l'absence de risque : l'employeur demeure seul",
      "responsable de la prévention (L4121-1 CT), de la mise à jour et de la mise en œuvre des actions.",
      "Document confidentiel — diffusion restreinte à l'entreprise et aux personnes habilitées.",
    ];
    limites.forEach((l,i)=>doc.text(l,18,ySom+17+i*6));
    ftr(doc,pg);

    doc.addPage(); pg++; hdr(doc,"Lettre au dirigeant");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Madame, Monsieur,",14,38);
    doc.setFont("helvetica","normal"); doc.setFontSize(11); doc.setTextColor(40,40,40);
    const lettre="Ce dossier présente l'évaluation des risques professionnels réalisée sur votre établissement. Il a pour objectif de vous aider à respecter vos obligations réglementaires (articles L4121-1 à L4121-3 et R4121-1 du Code du travail), à protéger vos salariés et à prioriser les actions de prévention.\n\nIl comprend le Document Unique d'Évaluation des Risques Professionnels (DUERP) par unité de travail, un plan d'actions de prévention priorisé, un rapport de visite avec photos, les fiches de poste sécurité et le registre de sécurité simplifié.\n\nNous restons à votre disposition pour la mise en œuvre de ces actions et la mise à jour annuelle de ce document.";
    doc.text(doc.splitTextToSize(lettre,182),14,52);
    doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.setFont("helvetica","normal");
    doc.text(doc.splitTextToSize(REGLEMENTAIRE.base,182),14,178);
    doc.text(doc.splitTextToSize(REGLEMENTAIRE.mention_validation,182),14,198);
    doc.setFont("helvetica","italic"); doc.setTextColor(...NAVY); doc.setFontSize(10);
    doc.text(consultant.nom||"Consultant PF24",14,230);
    ftr(doc,pg);

    // === PAGE 3 TABLEAU DE BORD ===
    doc.addPage(); pg++; hdr(doc,"Tableau de bord");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Synthèse de la visite",14,33);
    const blocs=Object.keys(visit.blocs||{}).length;
    const objets=Object.values(visit.blocs||{}).reduce((s,b)=>s+Object.values(b.objets||{}).filter(o=>o.statut==="present").length,0);
    const photos=(visit.photos||[]).length;
    const salaries=Object.values(visit.population||{}).reduce((s,p)=>s+Number(p.exposes||0),0);
    const tiles=[["Unités de travail",blocs],["Objets observés",objets],["Risques identifiés",risques.length],["Actions proposées",actions.length],["Risques critiques",risques.filter(r=>r.couleur==="red").length],["Salariés exposés",salaries],["Photos",photos],["Version DUERP","v"+versionNum]];
    let ty=44; tiles.forEach((t,i)=>{ const col=i%2,row=Math.floor(i/2); const x=14+col*97,y=ty+row*26; doc.setDrawColor(...LINE); doc.roundedRect(x,y,90,20,3,3); doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.setFont("helvetica","normal"); doc.text(String(t[0]),x+5,y+8); doc.setFontSize(14); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.text(String(t[1]),x+5,y+16); });
    ftr(doc,pg);

    // === PAGE GRILLE DE COTATION ===
    doc.addPage(); pg++; hdr(doc,"Grille de cotation");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Grille de cotation des risques",14,33);
    doc.setFontSize(9); doc.setFont("helvetica","normal"); doc.setTextColor(...GREY);
    doc.text("Référentiel G × P utilisé dans ce DUERP — Art. L4121-2 CT",14,41);

    // Gravité
    doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(...NAVY);
    doc.text("Gravité (G)",14,54);
    doc.autoTable({ startY:58,
      head:[["Valeur","Niveau","Description"]],
      body:GRILLE_COTATION.gravite.map(g=>[g.val,g.label,g.desc]),
      styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255},
      columnStyles:{0:{cellWidth:20,halign:"center"},1:{cellWidth:38}},
    });

    // Probabilité
    const yP=doc.lastAutoTable.finalY+10;
    doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(...NAVY);
    doc.text("Probabilité / Fréquence d'exposition (P)",14,yP);
    doc.autoTable({ startY:yP+4,
      head:[["Valeur","Niveau","Description"]],
      body:GRILLE_COTATION.probabilite.map(p=>[p.val,p.label,p.desc]),
      styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255},
      columnStyles:{0:{cellWidth:20,halign:"center"},1:{cellWidth:38}},
    });

    // Niveaux de risque
    const yN=doc.lastAutoTable.finalY+10;
    doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(...NAVY);
    doc.text("Niveaux de risque (G × P)",14,yN);
    doc.autoTable({ startY:yN+4,
      head:[["Niveau (G×P)","Qualification","Action requise"]],
      body:[["1 à 3","Modéré","Surveillance — planifier une action"],["4 à 8","Élevé","Action corrective dans les 3 mois"],["9 à 16","Critique","Action immédiate requise"]],
      styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255},
      columnStyles:{0:{cellWidth:24,halign:"center"},1:{cellWidth:28,halign:"center"}},
      didParseCell:function(dta){ if(dta.section==="body"&&dta.column.index===1){ const t=String(dta.cell.raw);
        dta.cell.styles.textColor=255; dta.cell.styles.fontStyle="bold";
        dta.cell.styles.fillColor = t==="Critique"?RED:t==="Élevé"?ORANGE:GREEN; } },
    });

    // Hiérarchie prévention
    const yH=doc.lastAutoTable.finalY+10;
    doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(...NAVY);
    doc.text("Hiérarchie des mesures de prévention — Art. L4121-2 CT",14,yH);
    doc.autoTable({ startY:yH+4,
      head:[["Priorité","Mesure","Principe"]],
      body:[
        ["1","Suppression du risque à la source","Éliminer le danger (substitution, remplacement)"],
        ["2","Protection collective (EPC)","Isoler le danger (capot, garde-corps, extraction…)"],
        ["3","Organisation du travail","Rotation des postes, limitation de l'exposition"],
        ["4","Formation et information","Procédures, signalisation, accueil sécurité"],
        ["5","EPI — dernier recours","Gants, masques, casques : uniquement si les mesures 1 à 4 sont insuffisantes"],
      ],
      styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255},
      columnStyles:{0:{cellWidth:30},1:{cellWidth:50}},
    });

    // Conservation 40 ans
    const y40=doc.lastAutoTable.finalY+10;
    doc.setFillColor(255,243,205); doc.roundedRect(14,y40,182,22,3,3,"F");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(9);
    doc.text("! OBLIGATION DE CONSERVATION",18,y40+8);
    doc.setFont("helvetica","normal"); doc.setFontSize(8.5);
    doc.text("Chaque version du DUERP doit être conservée pendant 40 ans par l'employeur",18,y40+15);
    doc.text("(Décret n°2022-395 du 31 mars 2022, art. R4121-4 CT).",18,y40+20);
    ftr(doc,pg);

    // === PAGE MISE À DISPOSITION ===
    doc.addPage(); pg++; hdr(doc,"Mise à disposition");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Mise à disposition du DUERP",14,33);
    doc.setFontSize(9); doc.setFont("helvetica","normal"); doc.setTextColor(...GREY);
    doc.text("Art. R4121-4 CT — Le DUERP doit être mis à disposition des salariés, du CSE, du médecin du travail et de l'inspection du travail.",14,41);
    const nbSal = Number(client.salaries)||0;
    const madRows = [];
    if(nbSal>0) madRows.push([new Date().toLocaleDateString("fr-FR"),"Médecin du travail / SPST",client.spst||"À renseigner",""]);
    if(nbSal>=11) madRows.push(["","CSE (obligatoire à partir de 11 salariés — L2311-2 CT)","Élus du personnel",""]);
    madRows.push(["","Inspection du travail","Sur demande",""]);
    madRows.push(...Array(3).fill(["","Salarié (facultatif — traçabilité recommandée)","Nom / poste : ______________",""]));
    doc.autoTable({ startY:48,
      head:[["Date","Document tenu à disposition de","Qualité / précision","Visa"]],
      body:madRows,
      styles:{fontSize:9,cellPadding:4}, headStyles:{fillColor:NAVY,textColor:255},
      columnStyles:{3:{cellWidth:32}},
    });
    const yAvis=doc.lastAutoTable.finalY+8;
    doc.setFillColor(229,246,237); doc.roundedRect(14,yAvis,182,24,3,3,"F");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(9);
    doc.text("Obligation d'affichage (art. R4121-4 CT)",18,yAvis+8);
    doc.setFont("helvetica","normal"); doc.setFontSize(8.5);
    doc.text("Un avis indiquant les modalités d'accès et de consultation du DUERP doit être affiché sur le lieu",18,yAvis+14);
    doc.text("de travail, à la même place que le règlement intérieur le cas échéant. L'émargement individuel",18,yAvis+19);
    doc.setFont("helvetica","italic");
    doc.text("des salariés n'est pas obligatoire mais constitue une preuve utile en cas de contrôle ou de litige.",18,yAvis+24);
    doc.setFont("helvetica","normal");
    const yMaj=yAvis+32;
    doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.setFont("helvetica","italic");
    doc.text("Conservation : durée du DUERP + 40 ans (Décret 2022-395).",14,yMaj);
    ftr(doc,pg);

    // === PAGE POPULATIONS EXPOSÉES ===
    doc.addPage(); pg++; hdr(doc,"Populations exposées");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Répartition des populations exposées",14,33);
    doc.setFontSize(9); doc.setTextColor(...GREY); doc.setFont("helvetica","normal");
    doc.text(`Effectif total déclaré : ${client.salaries||"—"}  (H : ${client.hommes||"—"} / F : ${client.femmes||"—"})`,14,41);
    const popRows=Object.entries(visit.population||{}).map(([bid,p])=>{ const bn=BLOCS[bid]?BLOCS[bid].nom:bid; return [bn,p.exposes||0,p.hommes||0,p.femmes||0,[p.apprentis&&"Appr.",p.interimaires&&"Intér.",p.jeunesTravailleurs&&"Jeunes",p.travailIsole&&"Isolé"].filter(Boolean).join(", ")||"—",p.expoDiff?"Oui":"Non"]; });
    doc.autoTable({ startY:48, head:[["Unité de travail","Exposés","H","F","Populations particulières","Expo H/F"]], body:popRows.length?popRows:[["—","—","—","—","—","—"]], styles:{fontSize:8.5,cellPadding:2.5}, headStyles:{fillColor:NAVY,textColor:255,fontSize:8}, alternateRowStyles:{fillColor:[247,249,251]} });
    ftr(doc,pg);

    // === PAGE TOP 5 PRIORITÉS ===
    doc.addPage(); pg++; hdr(doc,"Priorités");
    doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15);
    doc.text("Les 5 actions prioritaires",14,33);
    PF24_ENGINE.top5(actions).forEach((a,i)=>{ const ny=46+i*24; doc.setFillColor(...c(a.priorite==="Critique"?"red":a.priorite==="Élevée"?"orange":"green")); doc.circle(20,ny+4,5,"F"); doc.setTextColor(...WHITE); doc.setFontSize(9); doc.setFont("helvetica","bold"); doc.text(String(i+1),20,ny+5.5,{align:"center"}); doc.setTextColor(...NAVY); doc.setFontSize(11); doc.setFont("helvetica","bold"); doc.text(a.action,30,ny+3,{maxWidth:165}); doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.setFont("helvetica","normal"); doc.text(`${a.bloc}  •  ${a.priorite}  •  Délai : ${a.delai}`,30,ny+10); });
    ftr(doc,pg);

    // === PAGES PAR UNITÉ ===
    for(const blocId of Object.keys(visit.blocs||{})){ const bs=visit.blocs[blocId]; const bn=BLOCS[blocId]?BLOCS[blocId].nom:blocId; const objetsP=Object.entries(bs.objets||{}).filter(([,o])=>o.statut==="present"); if(!objetsP.length) continue;
      doc.addPage(); pg++; hdr(doc,"Rapport — "+bn);
      doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text(bn,14,33);
      doc.setFontSize(9); doc.setTextColor(...GREY); doc.setFont("helvetica","normal");
      doc.text(`${objetsP.length} objet(s) observé(s)`,14,41);
      let by=50;
      risques.filter(r=>r.unite===bn).slice(0,6).forEach(r=>{ doc.setFillColor(...c(r.couleur)); doc.roundedRect(14,by,5,13,1,1,"F"); doc.setTextColor(...NAVY); doc.setFontSize(10); doc.setFont("helvetica","bold"); doc.text(r.danger,23,by+5,{maxWidth:170}); doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.setFont("helvetica","normal"); doc.text(`${r.objet} — Niveau ${r.niveau} (${r.priorite})`,23,by+11); by+=17; });
      const photosB=(visit.photos||[]).filter(p=>p.blocId===blocId);
      if(photosB.length&&by<220){ by+=4; let px=14; for(const ph of photosB.slice(0,4)){ try{ const du=await PF24_DB.getPhoto(ph.id); if(du) doc.addImage(du,"JPEG",px,by,42,32,undefined,"FAST"); }catch(e){} px+=46; } }
      ftr(doc,pg);
    }

    // === SECTION DUERP ===
    doc.addPage(); pg++; hdr(doc,"DUERP"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text("Document Unique d'Évaluation des Risques",14,33);
    // Couleur conditionnelle pour le risque résiduel
    doc.autoTable({ startY:40,
      head:[["Unité","Danger","Dommages","Mesures existantes","G","P init.","Niv. initial","Maîtrise","P résid.","Risque résiduel"]],
      body:risques.map(r=>{
        const nI=r.niveauInitial||r.niveau;
        const nR=r.niveau;
        return [r.unite,r.danger,r.dommages,r.mesuresExistantes,
                r.gravite,r.probabiliteInitiale||r.probabilite,nI,r.maitrise||"—",r.probabilite,nR];
      }),
      styles:{fontSize:7,cellPadding:1.8},
      headStyles:{fillColor:NAVY,textColor:255,fontSize:7},
      alternateRowStyles:{fillColor:[247,249,251]},
      columnStyles:{0:{cellWidth:14},1:{cellWidth:22},2:{cellWidth:22},3:{cellWidth:28},
                    4:{cellWidth:7},5:{cellWidth:10},6:{cellWidth:14},
                    7:{cellWidth:14},8:{cellWidth:10},9:{cellWidth:14}},
      didParseCell:function(data){
        if(data.column.index===9 && data.section==='body'){
          const v=Number(data.cell.raw);
          if(v>=12) data.cell.styles.fillColor=RED; // Critique
          else if(v>=6) data.cell.styles.fillColor=ORANGE;
          else if(v>0) data.cell.styles.fillColor=GREEN;
          data.cell.styles.textColor=WHITE;
        }
        if(data.column.index===6 && data.section==='body'){
          const v=Number(data.cell.raw);
          if(v>=12) data.cell.styles.fillColor=[220,180,180];
          else if(v>=6) data.cell.styles.fillColor=[240,210,180];
        }
      },
      didDrawPage:()=>ftr(doc,doc.internal.getNumberOfPages()) });

    // === SECTION PAPRIPACT ===
    doc.addPage(); pg=doc.internal.getNumberOfPages(); hdr(doc,"PAPRIPACT"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text(Number(client.salaries)>=50?"Programme annuel de prévention (PAPRIPACT)":"Liste des actions de prévention (L4121-3-1 IV CT)",14,33);
    doc.autoTable({ startY:40, head:[["Action","Risque","Priorité","Responsable","Délai","Coût","Preuve","Statut"]], body:actions.map(a=>[a.action,a.risqueAssocie,a.priorite,a.responsable,a.delai,a.cout,a.preuve,a.statut]), styles:{fontSize:7.5,cellPadding:2}, headStyles:{fillColor:NAVY,textColor:255,fontSize:7.5}, alternateRowStyles:{fillColor:[247,249,251]}, didDrawPage:()=>ftr(doc,doc.internal.getNumberOfPages()) });

    // === SECTION CONFORMITÉ ===
    doc.addPage(); pg=doc.internal.getNumberOfPages(); hdr(doc,"Conformité"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text("Synthèse de conformité réglementaire",14,33);
    const confRows=[
      ["Obligation","Statut / Observation","Base legale"],
      ["DUERP - Document Unique (creation / mise a jour)", versionNum>0?"Presente - Version "+versionNum+" - "+new Date().toLocaleDateString("fr-FR"):"A creer - non presente","Art. L4121-1, R4121-1 CT"],
      ["Conservation 40 ans des versions successives","A assurer par l'employeur (archivage physique ou numerique)","Decret 2022-395 du 31/03/2022"],
      ["Mise a disposition des salaries et du CSE","Voir page Mise a disposition","Art. R4121-4 CT"],
      ["Extincteurs - verification annuelle",(visit.registre||{})["Extincteurs"]?.statut==="conforme"?"Conforme":(visit.registre||{})["Extincteurs"]?.statut==="non_conforme"?"Non conforme — voir plan d'actions":"A verifier","Art. R4227-39 CT + NF S61-919"],
      ["Installation electrique - verification annuelle",(visit.registre||{})["Installation electrique"]?.statut==="conforme"?"Conforme":"A verifier","Art. R4226-14 CT"],
      ["Trousse de premiers secours",(visit.registre||{})["Trousse de secours"]?.statut==="conforme"?"Presente et complete":"A verifier","Art. R4224-14 CT"],
      ["Sauveteur Secouriste du Travail (SST)",risques.length>0?"Recommande (1 par zone de travail)":"Non applicable","Art. R4224-15 CT"],
      ["Formation securite - accueil nouveaux arrivants",(visit.registre||{})["Formations securite"]?.statut==="conforme"?"Realisee":"A planifier","Art. L4141-2, R4141-3 CT"],
      ["Exercice d'evacuation incendie","Semestriel si consigne incendie obligatoire (>50 pers. ou matieres inflammables), sinon annuel recommande","Art. R4227-39 CT"],
      ["Affichages obligatoires (consignes incendie, reglement interieur)","A verifier","Art. L1311-2 CT"],
      ["Registre du personnel","A tenir par l'employeur","Art. L1221-13 CT"],
      ["FDS produits chimiques disponibles",(visit.blocsSelectionnes||[]).includes("chimiques")? ((visit.registre||{})["FDS (fiches de données de sécurité)"]?.statut==="conforme"?"Conforme":"A verifier - produits chimiques detectes"):"Non applicable pour cette activite","Art. R4412-38 CT"],
      ["Evaluation RPS formalisee",risques.some(r=>r&&r.unite&&r.unite.includes("RPS"))?"Presente dans ce DUERP":"A integrer lors de la prochaine mise a jour","Art. L4121-1 CT + Accord ANI 2008"],
      ["Visite medicale de reprise / suivi SPST",client.spst?"SPST : "+client.spst:"Coordonnees SPST a renseigner","Art. R4624-22 CT"],
    ];
    doc.autoTable({ startY:42,
      head:[["Obligation reglementaire","Statut","Base legale"]],
      body:confRows.slice(1),      styles:{fontSize:7.5,cellPadding:2.5},
      headStyles:{fillColor:NAVY,textColor:255,fontSize:8},
      alternateRowStyles:{fillColor:[247,249,251]},
      columnStyles:{0:{cellWidth:70},1:{cellWidth:72},2:{cellWidth:40}},
    });

    // === FICHES DE POSTE ===
    doc.addPage(); pg=doc.internal.getNumberOfPages(); hdr(doc,"Fiches de poste"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text("Fiches de poste sécurité simplifiées",14,33);
    const postes=(FICHES_POSTE[visit.metierId]||FICHES_POSTE.default); let fy=44;
    postes.forEach(p=>{ doc.setDrawColor(...LINE); doc.roundedRect(14,fy,182,26,3,3); doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(...NAVY); doc.text(p,20,fy+9); doc.setFont("helvetica","normal"); doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.text("Risques principaux : voir DUERP — EPI requis : voir tableau DUERP",20,fy+17,{maxWidth:170}); doc.text("Formations recommandées : Accueil sécurité, gestes et postures, EPI.",20,fy+23,{maxWidth:170}); fy+=32; });

    // === REGISTRE SÉCURITÉ ===
    doc.addPage(); pg=doc.internal.getNumberOfPages(); hdr(doc,"Registre de sécurité"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text("Registre de sécurité simplifié",14,33);
    const regItems=["Extincteurs","Installation électrique","Gaz (si applicable)","Ventilation (si applicable)","Équipements soumis à vérification","Trousse de secours","FDS (fiches de données de sécurité)","Formations sécurité","Consignes incendie","Plan d'évacuation"];
    doc.autoTable({ startY:42, head:[["Rubrique","Statut","Observation"]], body:regItems.map(r=>{ const item=(visit.registre||{})[r]||{}; const sl=item.statut==="conforme"?"Conforme":item.statut==="non_conforme"?"Non conforme":item.statut==="a_verifier"?"A verifier":"—"; return [r,sl,item.observation||"—"]; }), styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255}, alternateRowStyles:{fillColor:[247,249,251]} });

    // === HISTORIQUE ===
    if((visit.historique||[]).length){ doc.addPage(); pg=doc.internal.getNumberOfPages(); hdr(doc,"Historique"); doc.setTextColor(...NAVY); doc.setFont("helvetica","bold"); doc.setFontSize(15); doc.text("Historique des versions",14,33);
      doc.autoTable({ startY:42, head:[["Version","Date","Auteur","Motif"]], body:visit.historique.map(v=>["v"+v.numero,new Date(v.date).toLocaleDateString("fr-FR"),v.auteur,v.motif]), styles:{fontSize:9,cellPadding:3}, headStyles:{fillColor:NAVY,textColor:255}, alternateRowStyles:{fillColor:[247,249,251]} }); }

    // === PAGE FINALE ===
    doc.addPage(); doc.setFillColor(...NAVY); doc.rect(0,0,210,297,"F");
    doc.setTextColor(...WHITE); doc.setFont("helvetica","bold"); doc.setFontSize(18); doc.text("Conclusion",105,48,{align:"center"});
    doc.setFont("helvetica","normal"); doc.setFontSize(10);
    doc.text(doc.splitTextToSize(REGLEMENTAIRE.miseAJour,165),105,65,{align:"center"});
    doc.text(doc.splitTextToSize(REGLEMENTAIRE.mention_validation,165),105,95,{align:"center"});
    doc.setFont("helvetica","bold"); doc.setFontSize(10);
    doc.text(`Document v${versionNum} — Prochaine mise à jour recommandée sous 12 mois`,105,150,{align:"center"});
    doc.setDrawColor(...WHITE); doc.line(28,215,90,215); doc.line(120,215,182,215);
    doc.setFont("helvetica","normal"); doc.setFontSize(9);
    doc.text("Signature consultant"+(consultant.nom?" ("+consultant.nom+")":""),59,222,{align:"center"});
    doc.text("Signature client"+(client.valideur?" ("+client.valideur+")":""),151,222,{align:"center"});
    doc.text("PF24 QSE  •  "+new Date().toLocaleDateString("fr-FR")+"  •  Conservation obligatoire 40 ans (Décret 2022-395)",105,278,{align:"center",maxWidth:180});

    return doc;
  }

  return { generateDossier, generateDevis, generateFacture };
})();

/* ================================================================
   EXPORT WORD — DUERP éditable (.doc / HTML Word-compatible)
   Le client peut modifier le document, ajouter des observations,
   compléter les mesures et enregistrer sous Word.
   ================================================================ */
function generateDossierWord(visit, client, risques, actions, score, scoreConf) {
  const consultant = PF24_DB.getConsultant();
  const date = new Date().toLocaleDateString('fr-FR');
  const version = (visit.historique||[]).length || 1;

  const style = `
    body { font-family: Arial, sans-serif; font-size: 10pt; color: #0B1B33; margin: 2cm; }
    h1 { font-size: 16pt; color: #0B1B33; border-bottom: 3px solid #1E9E63; padding-bottom: 6pt; }
    h2 { font-size: 13pt; color: #0B1B33; margin-top: 18pt; border-bottom: 1px solid #ccc; padding-bottom: 4pt; }
    h3 { font-size: 11pt; color: #16294A; }
    table { border-collapse: collapse; width: 100%; margin: 10pt 0; font-size: 8.5pt; }
    th { background: #0B1B33; color: white; padding: 5pt 4pt; text-align: left; font-size: 8pt; }
    td { border: 1px solid #ccc; padding: 4pt; vertical-align: top; }
    tr:nth-child(even) td { background: #F4F6F9; }
    .crit { background: #D63B3B !important; color: white; font-weight: bold; text-align: center; }
    .elev { background: #E8821C !important; color: white; font-weight: bold; text-align: center; }
    .mod  { background: #1E9E63 !important; color: white; font-weight: bold; text-align: center; }
    .center { text-align: center; }
    .header-box { background: #0B1B33; color: white; padding: 16pt; margin-bottom: 14pt; }
    .header-box h1 { color: white; border: none; margin: 0 0 6pt 0; }
    .meta { font-size: 9pt; opacity: 0.8; }
    .note { font-size: 8.5pt; color: #5B6472; font-style: italic; margin: 6pt 0; }
    .action-row td { border: 1px solid #ccc; }
    .page-break { page-break-before: always; }
  `;

  function nivClass(n) { return n >= 12 ? 'crit' : n >= 6 ? 'elev' : 'mod'; }
  function niv(n)      { return n >= 12 ? 'Critique' : n >= 6 ? 'Élevé' : 'Modéré'; }

  // ---- TABLEAU DUERP ----
  const duerpRows = risques.map(r => {
    const nI = r.niveauInitial || r.niveau;
    const nR = r.niveau;
    return `<tr>
      <td>${r.unite}</td>
      <td>${r.danger}</td>
      <td>${r.situation}</td>
      <td>${r.dommages}</td>
      <td>${r.mesuresExistantes}</td>
      <td class="center">${r.gravite}</td>
      <td class="center ${nivClass(nI)}">${nI}<br><small>${niv(nI)}</small></td>
      <td class="center">${(r.maitrise||'—').charAt(0).toUpperCase()+(r.maitrise||'—').slice(1)}</td>
      <td class="center">${r.probabilite}</td>
      <td class="center ${nivClass(nR)}">${nR}<br><small>${niv(nR)}</small></td>
    </tr>`;
  }).join('');

  // ---- TABLEAU PAPRIPACT ----
  const papripactRows = actions.map((a,i) => `<tr>
    <td>${a.id||('A'+String(i+1).padStart(3,'0'))}</td>
    <td>${a.bloc||'—'}</td>
    <td>${a.risqueAssocie||'—'}</td>
    <td>${a.action}</td>
    <td class="center ${nivClass(a.priorite==='Critique'?12:(a.priorite==='Élevée'||a.priorite==='Elevée')?8:4)}">${a.priorite}</td>
    <td>${a.responsable||'—'}</td>
    <td>${a.delai||'—'}</td>
    <td>${a.cout||'À chiffrer'}</td>
    <td>${a.statut||'À faire'}</td>
    <td class="saisir"> </td>
    <td class="saisir">${a.commentaire||' '}</td>
    <td>${a.preuve||'—'}</td>
  </tr>`).join('');

  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta charset="utf-8">
  <title>DUERP ${client.nom||''}</title>
  <style>${style}</style>
</head>
<body>

<div class="header-box">
  <h1>Document Unique d'Évaluation des Risques Professionnels</h1>
  <div class="meta">
    Établissement : <strong>${client.nom||'—'}</strong><br>
    Activité : ${client.activite||'—'} — Effectif : ${client.salaries||'—'} salarié(s) — SIRET : ${client.siret||'—'}
  </div>
  <div class="meta" style="margin-top:6pt;">
    Rédigé par : ${consultant.nom||'Consultant PF24'}<br>
    Généré le ${date} à ${new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})} — Version : v${version}
  </div>
</div>

<div class="legal">Ce document a été établi sur la base des informations communiquées par l'employeur et des observations disponibles à la date de génération. Toute évolution de l'activité, des locaux, des effectifs, des équipements, des produits utilisés ou de l'organisation du travail peut nécessiter une mise à jour. La mise à jour, la diffusion et la mise en œuvre des mesures de prévention relèvent de la responsabilité de l'employeur.</div>
<p class="note">⚠️ Ce document a été établi sur la base des informations transmises à la date de l'intervention.
Toute évolution de l'activité, des locaux, des effectifs ou des équipements peut nécessiter une mise à jour.
La responsabilité de la mise à jour du DUERP incombe à l'employeur.</p>

<!-- ========== SECTION 1 : GRILLE ========== -->
<h2>1. Grille de cotation des risques (référentiel)</h2>
<p class="note">Référentiel G × P appliqué dans le présent document — hiérarchie des mesures : art. L4121-2 CT. La cotation constitue un outil d'aide à la décision et ne remplace pas l'analyse de l'employeur.</p>
<table>
  <thead><tr><th>Valeur</th><th>Gravité (G)</th><th>Probabilité (P)</th></tr></thead>
  <tbody>
    <tr><td>1</td><td>Blessure légère sans arrêt</td><td>Très improbable (moins d'une fois/an)</td></tr>
    <tr><td>2</td><td>Accident avec arrêt de travail</td><td>Peu probable (quelques fois/an)</td></tr>
    <tr><td>3</td><td>Incapacité permanente partielle</td><td>Probable (plusieurs fois/mois)</td></tr>
    <tr><td>4</td><td>Décès ou incapacité totale</td><td>Très probable (quotidien)</td></tr>
  </tbody>
</table>
<table>
  <thead><tr><th>Niveau (G×P)</th><th>Qualification</th><th>Action requise</th></tr></thead>
  <tbody>
    <tr><td>1 à 3</td><td class="mod">Modéré</td><td>Surveillance — action à planifier</td></tr>
    <tr><td>4 à 8</td><td class="elev">Élevé</td><td>Action corrective dans les 3 mois</td></tr>
    <tr><td>9 à 16</td><td class="crit">Critique</td><td>Action immédiate requise</td></tr>
  </tbody>
</table>
<div class="legal"><strong>Conservation obligatoire :</strong> chaque version du DUERP doit être conservée pendant 40 ans par l'employeur (Décret n°2022-395 du 31 mars 2022, art. R4121-4 CT). Le document est tenu à la disposition des salariés, du CSE, du médecin du travail (SPST) et de l'inspection du travail.</div>

<!-- ========== SECTION 2 : DUERP ========== -->
<h2>2. Document Unique d'Évaluation des Risques (DUERP)</h2>
<div class="legal">RPS — L'évaluation des risques psychosociaux repose sur les informations disponibles au moment de l'intervention. Une analyse approfondie des facteurs organisationnels, relationnels et managériaux peut nécessiter des entretiens complémentaires avec les salariés, l'encadrement et/ou le SPST. L'approche retenue est une approche de prévention (charge de travail, horaires, autonomie, relations de travail, incivilités, travail isolé, exigences émotionnelles, insécurité de la situation de travail) et non un diagnostic médical.</div>
<p class="note">G = Gravité &nbsp;|&nbsp; P init. = Probabilité initiale (avant mesures) &nbsp;|&nbsp;
Niv. initial = Risque avant mesures &nbsp;|&nbsp; Maîtrise = Niveau de maîtrise constaté &nbsp;|&nbsp;
P résid. = Probabilité résiduelle &nbsp;|&nbsp; Risque résiduel = Risque après mesures existantes</p>

<table>
  <thead>
    <tr>
      <th>Unité de travail</th>
      <th>Danger</th>
      <th>Situation dangereuse</th>
      <th>Dommages potentiels</th>
      <th>Mesures existantes / observations</th>
      <th>G</th>
      <th>Niv. initial</th>
      <th>Maîtrise</th>
      <th>P résid.</th>
      <th>Risque résiduel</th>
    </tr>
  </thead>
  <tbody>${duerpRows}</tbody>
</table>

<!-- ========== SECTION 3 : PLAN D'ACTIONS ========== -->
<h2 class="page-break">3. ${Number(client.salaries)>=50?"Programme annuel de prévention (PAPRIPACT)":"Liste des actions de prévention"}</h2>
<p class="note">${Number(client.salaries)>=50
  ?"Art. L4121-3-1 III CT — programme annuel obligatoire à partir de 50 salariés, présenté au CSE. Il fixe la liste détaillée des mesures, leurs conditions d'exécution, les ressources et le calendrier."
  :"Art. L4121-3-1 IV CT — pour les entreprises de moins de 50 salariés, les résultats de l'évaluation débouchent sur une liste d'actions de prévention consignée dans le DUERP (le PAPRIPACT formel ne s'impose qu'à partir de 50 salariés)."}</p>
<p class="note">${Number(client.salaries)>=11
  ?"Mise à jour du DUERP : au moins annuelle (art. R4121-2 CT — entreprise d'au moins 11 salariés), ainsi qu'à chaque aménagement important ou information nouvelle."
  :"Mise à jour du DUERP : lors de toute décision d'aménagement important ou information nouvelle (art. R4121-2 CT). L'obligation de mise à jour annuelle systématique ne s'applique qu'à partir de 11 salariés — une revue annuelle reste recommandée."}</p>
<p class="note">Tableau de pilotage : les colonnes «Date de réalisation» et «Observations» sont à compléter par l'employeur au fil de la mise en œuvre.</p>
<table>
  <thead>
    <tr>
      <th>N°</th><th>Unité</th><th>Danger / risque</th><th>Action à mettre en œuvre</th>
      <th>Priorité</th><th>Responsable</th><th>Échéance</th><th>Budget estimé</th>
      <th>Statut</th><th>Date de réalisation</th><th>Observations</th><th>Preuve / indicateur</th>
    </tr>
  </thead>
  <tbody>${papripactRows}</tbody>
</table>

<!-- ========== SECTION 4 : HISTORIQUE ========== -->
<h2 class="page-break">4. Historique des versions</h2>
<p class="note">Chaque mise à jour est tracée avec son motif (décision d'aménagement important, information nouvelle, évolution de l'activité — art. R4121-2 CT). Chaque version est conservée 40 ans.</p>
<table>
  <thead><tr><th>Version</th><th>Date</th><th>Auteur</th><th>Nature de la modification</th><th>Validation employeur</th><th>Signature / visa</th></tr></thead>
  <tbody>
    ${(visit.historique&&visit.historique.length?visit.historique:[{numero:1,date:new Date().toISOString(),motif:"Création initiale du DUERP",auteur:consultant.nom||A_COMPLETER}]).map(h=>`<tr><td>v${h.numero||'—'}</td><td>${h.date?new Date(h.date).toLocaleDateString('fr-FR'):'—'}</td><td>${h.auteur||'—'}</td><td>${h.motif||'—'}</td><td class="saisir">À compléter</td><td class="saisir"> </td></tr>`).join('')}
    <tr><td class="saisir"> </td><td class="saisir"> </td><td class="saisir"> </td><td class="saisir"> </td><td class="saisir"> </td><td class="saisir"> </td></tr>
  </tbody>
</table>

<!-- ========== SECTION 5 : PARTICIPATION ========== -->
<h2 class="page-break">5. Participation des salariés et informations recueillies</h2>
<p>L'évaluation des risques a été conduite avec la participation des salariés concernés et, le cas échéant, des représentants du personnel (art. L4121-3 CT). Les informations exploitées proviennent : des déclarations du dirigeant et des salariés présents, des observations visuelles réalisées lors de la visite, et des documents présentés le jour de l'intervention.</p>
<table><tr><th style="width:40%">Salariés / personnes ayant contribué</th><td class="saisir"> </td></tr>
<tr><th>Documents présentés lors de la visite</th><td class="saisir"> </td></tr></table>

<!-- ========== SECTION 6 : MISE À DISPOSITION ========== -->
<h2>6. Modalités de mise à disposition du DUERP</h2>
<p>Le DUERP est tenu à la disposition des salariés${Number(client.salaries)>=11?", du CSE":""}, du médecin du travail (SPST) et de l'inspection du travail (art. R4121-4 CT). Un avis indiquant les modalités de consultation est affiché sur le lieu de travail, à la même place que le règlement intérieur le cas échéant.</p>
<table><tr><th style="width:40%">Lieu / support de consultation</th><td class="saisir">Ex. : classeur au bureau, dossier partagé…</td></tr>
<tr><th>Avis affiché le</th><td class="saisir"> </td></tr></table>

<!-- ========== SECTION 7 : LIMITES ========== -->
<h2>7. Limites de la mission</h2>
<p class="note">Le présent document repose exclusivement sur les informations transmises par l'entreprise et les observations réalisées à la date de la visite. Les vérifications réglementaires (installations électriques, extincteurs, gaz, ventilation, etc.) n'ont pas fait l'objet d'un audit technique par le rédacteur : seule la présence ou l'absence des justificatifs présentés a été relevée. Toute évolution de l'activité, des locaux, des effectifs ou des équipements postérieure à la visite nécessite une mise à jour. <strong>PF24 QSE ne garantit ni la conformité réglementaire globale de l'établissement ni l'absence de risque : l'employeur demeure seul responsable de la prévention (art. L4121-1 CT), de la mise à jour du DUERP et de la mise en œuvre effective des actions.</strong> Document confidentiel — diffusion restreinte à l'entreprise et aux personnes habilitées.</p>

<h3>Glossaire</h3>
<table>
  <tr><th style="width:22%">DUERP</th><td>Document Unique d'Évaluation des Risques Professionnels</td></tr>
  <tr><th>G / P</th><td>Gravité / Probabilité (grille de cotation, section 1)</td></tr>
  <tr><th>EPC / EPI</th><td>Équipement de Protection Collective / Individuelle</td></tr>
  <tr><th>SPST</th><td>Service de Prévention et de Santé au Travail (ex-médecine du travail)</td></tr>
  <tr><th>CSE</th><td>Comité Social et Économique (obligatoire à partir de 11 salariés)</td></tr>
  <tr><th>PAPRIPACT</th><td>Programme Annuel de Prévention (obligatoire à partir de 50 salariés)</td></tr>
  <tr><th>VLEP</th><td>Valeur Limite d'Exposition Professionnelle</td></tr>
  <tr><th>TMS / RPS</th><td>Troubles Musculo-Squelettiques / Risques Psycho-Sociaux</td></tr>
  <tr><th>ATEX</th><td>Atmosphère Explosive</td></tr>
  <tr><th>DATI</th><td>Dispositif d'Alarme pour Travailleur Isolé</td></tr>
</table>

<!-- ========== SECTION 8 : SIGNATURES ========== -->
<h2 class="page-break">8. Validation et signatures</h2>
<table>
  <tr>
    <td style="width:50%;padding:30pt;min-height:80pt;">
      <strong>Conseil en Qualité, Sécurité et Environnement</strong><br>
      Nom : ${acVal(consultant.nom)}<br>
      Fonction : ${consultant.fonction||'Conseil QSE'}<br>
      Date : ${date}<br><br><br>
      Signature :
    </td>
    <td style="width:50%;padding:30pt;min-height:80pt;">
      <strong>Validation employeur</strong><br>
      Nom : ${acVal(client.valideur||client.contact)}<br>
      Fonction : ${client.fonctionDirigeant||'Dirigeant'}<br>
      Date :<br><br><br>
      Signature :
    </td>
  </tr>
</table>

<p class="note" style="margin-top:20pt;">
  Prochaine révision recommandée : ${client.prochainMaj || 'à définir'}<br>
  PF24 QSE — ${consultant.email||'contact@pf24qse.fr'} — Document généré le ${date}
</p>

<p class="note" style="text-align:center;margin-top:14pt;border-top:1pt solid #E3E8F0;padding-top:6pt;">${((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage||'PF24 QSE — Prévention Facile'}</p>
</body>
</html>`;

  return html;
}


/* ================================================================
   REGISTRE DE SÉCURITÉ — Word éditable
   Base légale : Art. L4711-1, R4323-1 à R4323-3 CT, R4227-39,
   gaz (professionnel qualifié), R125-2 CCH (ascenseurs)
   ================================================================ */
function generateRegistreWord(visit, client, risques) {
  const consultant = PF24_DB.getConsultant();
  const date = new Date().toLocaleDateString('fr-FR');

  const style = `
    body{font-family:Arial,sans-serif;font-size:10pt;color:#0B1B33;margin:2cm;}
    h1{font-size:15pt;color:#0B1B33;border-bottom:3px solid #E8821C;padding-bottom:6pt;}
    h2{font-size:12pt;color:#0B1B33;margin-top:16pt;background:#F4F6F9;padding:5pt 8pt;border-left:4px solid #0B1B33;}
    h3{font-size:10pt;color:#16294A;margin-top:10pt;}
    table{border-collapse:collapse;width:100%;margin:8pt 0;font-size:8.5pt;}
    th{background:#0B1B33;color:white;padding:5pt 4pt;text-align:left;font-size:8pt;}
    td{border:1px solid #ccc;padding:4pt;vertical-align:top;}
    tr:nth-child(even) td{background:#F9FAFB;}
    .ok{background:#E5F6ED;color:#1E9E63;font-weight:bold;text-align:center;}
    .nok{background:#FDE8E8;color:#D63B3B;font-weight:bold;text-align:center;}
    .av{background:#FFF0E0;color:#E8821C;font-weight:bold;text-align:center;}
    .note{font-size:8pt;color:#5B6472;font-style:italic;margin:4pt 0;}
    .legal{background:#FFF3CD;border-left:4px solid #E8821C;padding:8pt 12pt;margin:8pt 0;font-size:8.5pt;}
    .header{background:#0B1B33;color:white;padding:14pt;margin-bottom:12pt;}
    .header h1{color:white;border:none;margin:0;}
    .saisir{min-width:60pt;background:#FFFDE7;}
    .page-break{page-break-before:always;}
  `;

  // Vérifications périodiques obligatoires
  const verifs = [
    { equipement:"Installations électriques", base:"Art. R4226-14 CT", freq:"Annuelle", organisme:"Organisme compétent / organisme accrédité si requis" },
    { equipement:"Extincteurs", base:"Art. R4227-39 CT + NF S61-919", freq:"Annuelle", organisme:"Technicien certifié" },
    { equipement:"Éclairage de sécurité (BAES)", base:"Règlement ERP art. EC14 (arrêté 25/06/1980)", freq:"Mensuelle (fonctionnement) / Annuelle (autonomie)", organisme:"Responsable désigné / technicien" },
    { equipement:"Alarme incendie (SSI)", base:"IT246, NF S61-933", freq:"Semestrielle (selon catégorie du SSI)", organisme:"Technicien qualifié" },
    { equipement:"Portes coupe-feu / désenfumage", base:"IT246", freq:"Annuelle", organisme:"Technicien qualifié" },
    { equipement:"Appareils de levage (pont, chariot…)", base:"Art. R4323-22 à 28 CT", freq:"Semestrielle si charge > 1t, annuelle sinon", organisme:"Organisme compétent / accrédité si requis" },
    { equipement:"Installation gaz", base:"Règlement ERP art. GZ (le cas échéant) — bonne pratique", freq:"Entretien annuel", organisme:"Professionnel Gaz (PG)" },
    { equipement:"Chaudière (4 à 400 kW)", base:"Art. R224-41-4 et s. Code env. (décret 2020-912)", freq:"Entretien annuel", organisme:"Professionnel qualifié" },
    { equipement:"Ascenseurs / élévateurs", base:"Art. R125-2 CCH", freq:"Visites périodiques selon contrat (≈ 6 semaines)", organisme:"Prestataire de maintenance agréé" },
    { equipement:"EPI (harnais, appareils respiratoires…)", base:"Art. R4323-99 CT", freq:"Selon préconisation fabricant (min. annuelle)", organisme:"Responsable désigné ou prestataire" },
    { equipement:"Machines et équipements de travail", base:"Art. R4322-1 CT", freq:"Selon préconisation (min. annuelle)", organisme:"Technicien compétent" },
    { equipement:"Installations de ventilation / aération", base:"Art. R4222-20 à R4222-22 CT", freq:"Annuelle (contrôle des débits et de l'état)", organisme:"Technicien compétent" },
    { equipement:"Trousse de premiers secours", base:"Art. R4224-14 CT", freq:"Vérification régulière du contenu", organisme:"Responsable désigné" },
  ];

  // Pré-remplissage depuis les objets observés de la visite
  const objPresents = Object.values(visit.blocs||{})
    .flatMap(b=>Object.entries(b.objets||{}).filter(([,o])=>o.statut==='present').map(([k,o])=>({nom:k,obs:o.observation||'',maitrise:o.maitrise||''})));
  const regVisit = visit.registre || {};

  function prefillStatut(item) {
    const r = regVisit[item];
    if(r && r.statut==='conforme') return '✔ Conforme (saisi lors de la visite)';
    if(r && r.statut==='non_conforme') return "✗ Non conforme — voir plan d\u2019actions";
    if(r && r.statut==='a_verifier') return '⚠ À vérifier';
    return '';
  }
  function prefillObs(item) {
    const r = regVisit[item];
    return (r && r.observation) ? r.observation : '';
  }

  const verifRows = verifs.map(v => `<tr>
    <td>${v.equipement}</td>
    <td>${v.base}</td>
    <td>${v.freq}</td>
    <td>${v.organisme}</td>
    <td class="saisir">${prefillStatut(v.equipement)}</td>
    <td class="saisir">${prefillObs(v.equipement)}</td>
    <td class="saisir"> </td>
    <td class="saisir"> </td>
    <td class="saisir"> </td>
  </tr>`).join('');

  // Formations
  const formations = [
    { formation:"Formation à la sécurité (accueil)", base:"Art. L4141-2, R4141-3 CT", destinataires:"Tout salarié à l'embauche ou changement de poste", freq:"Dès l'embauche" },
    { formation:"Formation incendie / évacuation", base:"Art. R4227-39 CT", destinataires:"Tout le personnel (dont équipiers de 1re intervention)", freq:"À l'embauche + exercices périodiques (semestriels si consigne obligatoire)" },
    { formation:"Formation gestes et postures (PRAP)", base:"Art. R4541-1 CT", destinataires:"Salariés exposés à la manutention manuelle", freq:"Recommandé par INRS" },
    { formation:"Formation SST (Sauveteur Secouriste du Travail)", base:"Art. R4224-15 CT", destinataires:"Au moins un SST par atelier / zone de travail dangereuse", freq:"Tous les 2 ans (recyclage)" },
    { formation:"Information sur les risques chimiques / FDS", base:"Art. R4412-38 CT", destinataires:"Salariés exposés à des produits chimiques", freq:"À l'embauche + lors de tout nouveau produit" },
    { formation:"Habilitation électrique (BS, BE, B1…)", base:"Art. R4544-9 CT, NF C18-510", destinataires:"Salariés intervenant sur ou près d'installations électriques", freq:"Recyclage recommandé tous les 3 ans" },
  ];

  const formRows = formations.map(f => `<tr>
    <td>${f.formation}</td>
    <td>${f.base}</td>
    <td>${f.destinataires}</td>
    <td>${f.freq}</td>
    <td class="saisir"> </td>
    <td class="saisir"> </td>
  </tr>`).join('');

  // Accidents bénins
  const accidentCols = ['Date','Salarié concerné','Nature de l\'accident','Siège de la lésion','Circonstances','Témoins','Soins dispensés','Déclaration AT'];
  const accidentHeader = accidentCols.map(c=>`<th>${c}</th>`).join('');
  const accidentRows = Array(5).fill(0).map(()=>`<tr>${Array(8).fill('<td class="saisir">&nbsp;</td>').join('')}</tr>`).join('');

  return `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Registre de sécurité — ${client.nom||''}</title><style>${style}</style></head>
<body>

<div class="header">
  <h1>Registre de sécurité</h1>
  <div style="font-size:9pt;opacity:.85;margin-top:6pt;">
    Établissement : <strong>${client.nom||'—'}</strong><br>
    Activité : ${client.activite||'—'} — Effectif : ${client.salaries||'—'} salarié(s) — SIRET : ${client.siret||'—'}<br>
    Adresse : ${client.adresse||'—'} &nbsp;|&nbsp;
    Rédigé par : ${consultant.nom||'PF24'} &nbsp;|&nbsp; Date : ${date}
  </div>
</div>

<div class="legal">Ce document a été établi sur la base des informations communiquées par l'employeur et des observations disponibles à la date de génération. Toute évolution de l'activité, des locaux, des effectifs, des équipements, des produits utilisés ou de l'organisation du travail peut nécessiter une mise à jour. La mise à jour, la diffusion et la mise en œuvre des mesures de prévention relèvent de la responsabilité de l'employeur.</div>
<p class="note">Base légale principale : Art. L4711-1 du Code du travail — Ce registre doit être tenu à disposition de l'inspection du travail,
du médecin du travail et du CSE/CSST. Il doit être conservé 5 ans minimum.</p>

<!-- ===== 1. VÉRIFICATIONS PÉRIODIQUES ===== -->
<h2>1. Vérifications périodiques réglementaires</h2>
<p class="note"><strong>Tableau de suivi à compléter et tenir à jour par l'employeur.</strong> Complétez les colonnes "Date prévue", "Date réalisée", "Organisme" et "N° rapport" à chaque vérification. Les fréquences indiquées sont données à titre indicatif ou usuel et doivent être vérifiées selon la réglementation applicable, les équipements présents, les notices fabricants et les prescriptions de l'assureur.</p>
<table>
  <thead>
    <tr>
      <th>Équipement / Installation</th>
      <th>Base légale</th>
      <th>Fréquence obligatoire</th>
      <th>Prestataire recommandé</th>
      <th>Date prévue</th>
      <th>Date réalisée</th>
      <th>Organisme intervenant</th>
      <th>N° rapport / observation</th>
      <th>Action corrective / échéance</th>
    </tr>
  </thead>
  <tbody>${verifRows}</tbody>
</table>

<!-- ===== 2. FORMATIONS SÉCURITÉ ===== -->
<h2 class="page-break">2. Suivi des formations sécurité</h2>
<p class="note">Art. L4141-1 CT — L'employeur est tenu d'organiser une formation pratique et appropriée en matière de sécurité.</p>
<table>
  <thead>
    <tr>
      <th>Formation</th>
      <th>Base légale</th>
      <th>Personnes concernées</th>
      <th>Fréquence</th>
      <th>Date réalisée</th>
      <th>Participants / observations</th>
    </tr>
  </thead>
  <tbody>${formRows}</tbody>
</table>

<!-- ===== 3. EXERCICES ÉVACUATION ===== -->
<h2>3. Exercices d'évacuation</h2>
<p class="note">Art. R4227-39 CT — Essais et exercices périodiques (semestriels lorsque la consigne incendie est obligatoire : plus de 50 personnes ou matières inflammables, art. R4227-37).</p>
<table>
  <thead><tr><th>Date</th><th>Heure</th><th>Durée (min)</th><th>Nombre de participants</th><th>Observations / points à améliorer</th><th>Responsable</th></tr></thead>
  <tbody>
    ${Array(4).fill(`<tr>${Array(6).fill('<td class="saisir">&nbsp;</td>').join('')}</tr>`).join('')}
  </tbody>
</table>

<!-- ===== 4. ACCIDENTS BÉNINS ===== -->
<h2 class="page-break">4. Registre des accidents bénins</h2>
<p class="note">Art. R441-3 CSS — En lieu et place de la déclaration d'accident du travail. <strong>Cette section ne doit être utilisée que si l'entreprise remplit les conditions réglementaires applicables (présence d'un SST, moyens de secours, registre coté). À défaut, tout accident du travail doit être déclaré à la CPAM selon la procédure normale (48 h).</strong> Conserver 5 ans.</p>
<table>
  <thead><tr>${accidentHeader}</tr></thead>
  <tbody>${accidentRows}</tbody>
</table>

<!-- ===== 5. SIGNATURES ===== -->
<h2>5. Mise à jour et signatures</h2>
<table>
  <tr>
    <td style="padding:20pt;width:50%">
      <strong>Validation employeur</strong><br>
      Nom : ${acVal(client.valideur||client.contact)}<br>
      Fonction : ${client.fonctionDirigeant||'Dirigeant'}<br>
      Date de première mise en service : ${date}<br><br>
      Signature :<br><br><br>
    </td>
    <td style="padding:20pt;width:50%">
      <strong>Conseil en Qualité, Sécurité et Environnement</strong><br>
      Nom : ${consultant.nom||'—'}<br>
      Date : ${date}<br><br>
      Signature :<br><br><br>
    </td>
  </tr>
</table>

<p class="note" style="margin-top:16pt;">
  Prochain contrôle recommandé : ${client.prochainMaj||'—'} &nbsp;|&nbsp;
  PF24 QSE — ${consultant.email||'contact@pf24qse.fr'} — Document généré le ${date}
</p>

<p class="note" style="text-align:center;margin-top:14pt;border-top:1pt solid #E3E8F0;padding-top:6pt;">${((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage||'PF24 QSE — Prévention Facile'}</p>
</body></html>`;
}

/* ================================================================
   FICHES DE POSTE SÉCURITÉ — Word éditable
   Base légale : Art. L4141-1, R4141-1 CT (information et formation)
   ================================================================ */
function generateFichesPosteWord(visit, client, risques) {
  const consultant = PF24_DB.getConsultant();
  const date = new Date().toLocaleDateString('fr-FR');
  const postes = (FICHES_POSTE[visit.metierId]||FICHES_POSTE.default);

  const style = `
    body{font-family:Arial,sans-serif;font-size:10pt;color:#0B1B33;margin:2cm;}
    h1{font-size:15pt;color:#0B1B33;border-bottom:3px solid #1E9E63;padding-bottom:6pt;}
    h2{font-size:12pt;color:white;background:#0B1B33;padding:6pt 10pt;margin-top:20pt;}
    table{border-collapse:collapse;width:100%;margin:8pt 0;font-size:9pt;}
    th{background:#F4F6F9;color:#0B1B33;padding:5pt;text-align:left;font-weight:bold;border:1px solid #ccc;font-size:9pt;}
    td{border:1px solid #ccc;padding:5pt;vertical-align:top;}
    .risk-crit{background:#FDE8E8;font-weight:bold;}
    .risk-elev{background:#FFF0E0;}
    .risk-mod{background:#E5F6ED;}
    .note{font-size:8pt;color:#5B6472;font-style:italic;}
    .legal{background:#FFF3CD;border-left:4px solid #E8821C;padding:8pt 12pt;margin:8pt 0;font-size:8.5pt;}
    .header{background:#0B1B33;color:white;padding:14pt;margin-bottom:14pt;}
    .header h1{color:white;border:none;margin:0;}
    .page-break{page-break-before:always;}
    .urgence{background:#D63B3B;color:white;padding:8pt;font-weight:bold;margin-top:10pt;}
    .epi-box{background:#E5F6ED;border:1px solid #1E9E63;padding:8pt;margin:6pt 0;}
  `;

  const urgenceNums = `
    <div class="urgence">Numéros d'urgence — à afficher sur ce document</div>
    <table style="margin-top:6pt;">
      <tr><th>Service</th><th>Numéro</th><th>Précisions</th></tr>
      <tr><td>SAMU</td><td><strong>15</strong></td><td>Urgence médicale</td></tr>
      <tr><td>Pompiers</td><td><strong>18</strong></td><td>Incendie, secours</td></tr>
      <tr><td>Police / Gendarmerie</td><td><strong>17</strong></td><td> </td></tr>
      <tr><td>Numéro d'urgence européen</td><td><strong>112</strong></td><td>Depuis tout téléphone</td></tr>
      <tr><td>Urgence sourds / malentendants</td><td><strong>114</strong></td><td>SMS, visio, tchat — urgence114.fr</td></tr>
      <tr><td>Centre antipoison</td><td><strong>01 40 05 48 48</strong></td><td>Île-de-France (24h/24)</td></tr>
      <tr><td>SPST (médecin du travail)</td><td>Tél. : ${client.spstTel||'_______________'}</td><td>Service : ${client.spst||'_______________'}</td></tr>
      <tr><td>Référent sécurité interne</td><td>Tél. : ${client.referentTel||'_______________'}</td><td>Nom : ${client.referentSecurite||'_______________'}</td></tr>
      <tr><td>Localisation trousse de secours</td><td colspan="2">${client.trousseLocalisation||A_COMPLETER}</td></tr>
      <tr><td>Point de rassemblement</td><td colspan="2">${client.pointRassemblement||A_COMPLETER}</td></tr>
    </table>`;

  const fichesHtml = postes.map((poste, idx) => {
    // Risques liés à ce poste (tous les risques de la visite)
    const riskRows = risques.slice(0, 8).map(r => `<tr class="${r.niveau>=12?'risk-crit':r.niveau>=6?'risk-elev':'risk-mod'}">
      <td>${r.danger}</td>
      <td>${r.situation}</td>
      <td>${r.dommages}</td>
      <td>${r.mesuresExistantes||'Voir plan d\'actions'}</td>
      <td style="text-align:center;">${r.niveau>=12?'🔴 Critique':r.niveau>=6?'🟠 Élevé':'🟢 Modéré'}</td>
    </tr>`).join('');

    return `<h2 ${idx>0?'class="page-break"':''}>Fiche de poste sécurité — ${poste}</h2>
    <table>
      <tr>
        <th style="width:30%">Établissement</th><td>${client.nom||'—'}</td>
        <th style="width:20%">Date</th><td>${date}</td>
      </tr>
      <tr>
        <th>Intitulé du poste</th><td>${poste}</td>
        <th>Secteur / Unité</th><td>${client.activite||'—'}</td>
      </tr>
      <tr>
        <th>Effectif concerné</th><td>À compléter : _______</td>
        <th>Responsable hiérarchique</th><td>À compléter : _______</td>
      </tr>
    </table>

    <h3>Risques liés au poste et mesures de prévention</h3>
    <p class="note">Source : Document Unique d'Évaluation des Risques — v${(visit.historique||[]).length||1} du ${date}</p>
    <table>
      <thead><tr>
        <th>Danger identifié</th>
        <th>Situation dangereuse</th>
        <th>Dommages potentiels</th>
        <th>Mesures existantes</th>
        <th>Niveau de risque issu du DUERP</th>
      </tr></thead>
      <tbody>${riskRows}</tbody>
    </table>

    <div class="epi-box">
      <strong>Équipements de Protection Individuelle (EPI) obligatoires pour ce poste</strong><br>
      <span style="font-size:8pt;font-style:italic;">Les EPI sont fournis gratuitement par l'employeur, entretenus et remplacés si nécessaire (art. R4323-95 CT) — mesure de dernier recours (art. L4121-2 CT).</span><br>
      <table style="margin-top:6pt;">
        <tr><th>EPI</th><th>Norme / Marquage CE</th><th>Fréquence de vérification</th><th>Fourni par l'employeur</th></tr>
        ${getEPIPourMetier(visit.metierId).map(e=>`<tr><td>${e.epi}</td><td>${e.norme}</td><td>${e.verif}</td><td>☐ Oui</td></tr>`).join('')}
        <tr><td class="saisir"> </td><td class="saisir"> </td><td class="saisir"> </td><td>☐ Oui</td></tr>
      </table>
    </div>

    <h3>Interdictions au poste</h3>
    <table>
      <tr><td>• Intervenir sur une machine en fonctionnement ou neutraliser un protecteur de sécurité</td></tr>
      <tr><td>• Utiliser un équipement sans y avoir été formé et autorisé</td></tr>
      <tr><td>• Salariés de moins de 18 ans : travaux sur machines dangereuses interdits sans dérogation (art. D4153-28 CT)</td></tr>
      <tr><td class="saisir">• Interdictions spécifiques au poste : ______________________________</td></tr>
    </table>

    <h3>Aptitudes et surveillance médicale</h3>
    <table>
      <tr><th style="width:55%">Visite d'information et de prévention (VIP)</th><td>Dans les 3 mois suivant la prise de poste (art. R4624-10 CT)</td></tr>
      <tr><th>Suivi individuel renforcé (SIR)</th><td>Si exposition à risques particuliers — CMR, hauteur avec habilitation, etc. (art. R4624-22 et 23 CT)</td></tr>
      <tr><th>Travail de nuit</th><td>Suivi adapté par le SPST (art. L3122-11 CT)</td></tr>
    </table>

    <h3>Conduite à tenir en cas d'accident sur ce poste</h3>
    <table>
      <tr><th>Étape</th><th>Action</th></tr>
      <tr><td>1 — Protéger</td><td>Sécuriser la zone pour éviter un sur-accident. Ne pas déplacer la victime sauf danger immédiat.</td></tr>
      <tr><td>2 — Alerter</td><td>Appeler le 15 (SAMU) ou le 18 (Pompiers). Indiquer : lieu précis, nature de l'accident, nombre de victimes.</td></tr>
      <tr><td>3 — Secourir</td><td>Prodiguer les premiers secours dans la limite de sa formation (SST, PSC1). Ne pas donner de médicaments.</td></tr>
      <tr><td>4 — Déclarer</td><td>Déclarer l'accident du travail à la CPAM dans les 48h (art. L441-2 CSS). Conserver les témoignages.</td></tr>
    </table>

    ${urgenceNums}

    <h3>Formations obligatoires ou recommandées pour ce poste</h3>
    <table>
      <tr><th>Formation</th><th>Caractère</th><th>Fréquence</th><th>Date de réalisation</th><th>Observations</th></tr>
      <tr><td>Formation au poste / accueil sécurité (art. R4141-3 CT)</td><td>Obligatoire à l'embauche</td><td>À chaque prise de poste</td><td class="saisir">Réalisé le : ______</td><td class="saisir"> </td></tr>
      <tr><td>Formation incendie / évacuation</td><td>Obligatoire</td><td>Min. 1/an</td><td class="saisir"> </td><td class="saisir"> </td></tr>
      <tr><td>Formation spécifique au poste</td><td>Recommandée</td><td>À préciser</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    </table>

    <table style="margin-top:14pt;">
      <tr>
        <td style="padding:14pt;width:50%"><strong>Lu et approuvé — Salarié</strong><br>Nom : ___________________<br>Poste : ___________________<br>Fiche remise le : ___________<br><br>Signature :</td>
        <td style="padding:14pt;width:50%"><strong>Validation employeur</strong><br>Nom : ${acVal(client.valideur||client.contact)}<br>Fonction : ${client.fonctionDirigeant||'Dirigeant'}<br>Date : ${date}<br><br>Signature :</td>
      </tr>
      <tr><td colspan="2" style="padding:8pt;"><strong>Observations :</strong><br><br></td></tr>
    </table>`;
  }).join('');

  return `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Fiches de poste — ${client.nom||''}</title><style>${style}</style></head>
<body>
<div class="header">
  <h1>Fiches de poste sécurité</h1>
  <div style="font-size:9pt;opacity:.85;margin-top:6pt;">
    ${client.nom||'—'} — ${client.activite||'—'} — ${client.salaries||'—'} salarié(s) — SIRET : ${client.siret||'—'}<br>
    Base légale : Art. L4141-1 et R4141-1 CT (information et formation à la sécurité)<br>
    Rédigé par : ${consultant.nom||'PF24'} — ${date}
  </div>
</div>
<p class="note">Ces fiches de poste sécurité ont été établies à partir du Document Unique d'Évaluation des Risques Professionnels (DUERP) v${(visit.historique||[]).length||1}.
Elles doivent être remises à chaque salarié concerné et signées. Elles sont à mettre à jour lors de toute évolution significative du poste. Cette fiche ne remplace pas la formation pratique et appropriée à la sécurité prévue par le Code du travail (art. L4141-2).</p>
<div class="legal">Ce document a été établi sur la base des informations communiquées par l'employeur et des observations disponibles à la date de génération. Toute évolution de l'activité, des locaux, des effectifs, des équipements, des produits utilisés ou de l'organisation du travail peut nécessiter une mise à jour. La mise à jour, la diffusion et la mise en œuvre des mesures de prévention relèvent de la responsabilité de l'employeur.</div>
${fichesHtml}
<p class="note" style="text-align:center;margin-top:14pt;border-top:1pt solid #E3E8F0;padding-top:6pt;">${((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage||'PF24 QSE — Prévention Facile'}</p>
</body></html>`;
}

/* ================================================================
   PLAN DE PRÉVENTION — Word éditable
   Art. R4511-1 à R4515-11 CT — Décret 92-158 du 20/02/1992
   Arrêté du 19 mars 1993 (travaux dangereux)
   ================================================================ */
function generatePlanPreventionWord(visit, client, risques) {
  const consultant = PF24_DB.getConsultant();
  const date = new Date().toLocaleDateString('fr-FR');

  const style = `
    body{font-family:Arial,sans-serif;font-size:10pt;color:#0B1B33;margin:1.8cm;}
    h1{font-size:15pt;color:#0B1B33;border-bottom:3px solid #E8821C;padding-bottom:6pt;}
    h2{font-size:11.5pt;color:white;background:#0B1B33;padding:6pt 10pt;margin-top:18pt;}
    h3{font-size:10pt;color:#16294A;margin-top:12pt;font-weight:bold;}
    table{border-collapse:collapse;width:100%;margin:8pt 0;font-size:9pt;}
    th{background:#F4F6F9;color:#0B1B33;padding:5pt;text-align:left;border:1px solid #ccc;font-size:9pt;}
    td{border:1px solid #ccc;padding:5pt;vertical-align:top;}
    .saisir{background:#FFFDE7;min-width:60pt;}
    .note{font-size:8pt;color:#5B6472;font-style:italic;margin:4pt 0;}
    .header{background:#0B1B33;color:white;padding:14pt;margin-bottom:12pt;}
    .header h1{color:white;border:none;margin:0;}
    .legal{background:#FFF3CD;border-left:4px solid #E8821C;padding:8pt 12pt;margin:8pt 0;font-size:8.5pt;}
    .check{width:18pt;text-align:center;}
    .page-break{page-break-before:always;}
    .danger{background:#FDE8E8;}
  `;

  // Checklist travaux dangereux
  const travauxDangereux = TRAVAUX_DANGEREUX_PDP.map(t =>
    `<tr><td class="check">☐</td><td>${t}</td></tr>`).join('');

  // Étapes de la démarche
  const etapes = PDP_ETAPES.map(e =>
    `<tr><td><strong>${e.etape}</strong></td><td>${e.base}</td><td>${e.desc}</td></tr>`).join('');

  // Sections obligatoires
  const sections = PDP_SECTIONS_OBLIGATOIRES.map((s,i) =>
    `<tr><td class="check">${i+1}</td><td>${s}</td></tr>`).join('');

  // Risques du site (issus du DUERP) pour l'analyse d'interférence
  const risquesSite = (risques||[]).slice(0,10).map(r =>
    `<tr><td>${r.unite||'—'}</td><td>${r.danger||'—'}</td><td>${r.niveau>=12?'Critique':r.niveau>=6?'Élevé':'Modéré'}</td><td class="saisir"> </td></tr>`).join('');

  return `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Plan de prévention — ${client.nom||''}</title><style>${style}</style></head>
<body>

<div class="header">
  <h1>Plan de Prévention</h1>
  <div style="font-size:9pt;opacity:.85;margin-top:6pt;">
    Etabli en application des articles R4511-1 à R4514-10 du Code du travail (Décret n°92-158 du 20 février 1992)<br>
    Entreprise utilisatrice : <strong>${client.nom||'—'}</strong> &nbsp;|&nbsp;
    SIRET : ${client.siret||'—'} &nbsp;|&nbsp; Date d'établissement : ${date}
  </div>
</div>

<div class="legal">
  <strong>⚠ Document à utiliser uniquement en cas d'intervention d'une entreprise extérieure. Il ne remplace pas le protocole de sécurité applicable aux opérations de chargement/déchargement (art. R4515-1 et s. CT).</strong><br>
  <strong>Cadre réglementaire :</strong> Le plan de prévention est obligatoire par écrit lorsque l'opération réalisée par une ou plusieurs entreprises extérieures représente un total ≥ 400 heures de travail sur 12 mois, OU dès la première heure si les travaux figurent sur la liste des travaux dangereux (Arrêté du 19 mars 1993). Une inspection commune préalable est OBLIGATOIRE dans tous les cas (art. R4512-2 CT) et doit être réalisée avant le début de l'intervention.
</div>
<div class="legal">Ce document a été établi sur la base des informations communiquées par l'employeur et des observations disponibles à la date de génération. Toute évolution de l'activité, des locaux, des effectifs, des équipements, des produits utilisés ou de l'organisation du travail peut nécessiter une mise à jour. La mise à jour, la diffusion et la mise en œuvre des mesures de prévention relèvent de la responsabilité de l'employeur.</div>

<!-- ===== 1. IDENTIFICATION ===== -->
<h2>1. Identification des entreprises</h2>
<h3>Entreprise Utilisatrice (EU) — donneur d'ordre</h3>
<table>
  <tr><th style="width:35%">Raison sociale</th><td>${client.nom||'—'}</td></tr>
  <tr><th>Adresse du site d'intervention</th><td class="saisir">${client.adresse||' '}</td></tr>
  <tr><th>Représentant / responsable sécurité</th><td class="saisir">${client.valideur||client.contact||' '}</td></tr>
  <tr><th>Téléphone</th><td class="saisir"> </td></tr>
</table>

<h3>Entreprise(s) Extérieure(s) (EE) — intervenant(s)</h3>
<table>
  <tr><th style="width:35%">Raison sociale</th><td class="saisir"> </td></tr>
  <tr><th>Adresse</th><td class="saisir"> </td></tr>
  <tr><th>SIRET</th><td class="saisir"> </td></tr>
  <tr><th>Représentant sur site</th><td class="saisir"> </td></tr>
  <tr><th>Téléphone</th><td class="saisir"> </td></tr>
  <tr><th>Effectif intervenant</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 2. NATURE DE L'INTERVENTION ===== -->
<h2>2. Nature et durée de l'intervention</h2>
<table>
  <tr><th style="width:35%">Description des travaux</th><td class="saisir"> </td></tr>
  <tr><th>Lieu(x) précis d'intervention</th><td class="saisir"> </td></tr>
  <tr><th>Date de début</th><td class="saisir"> </td></tr>
  <tr><th>Date de fin prévue</th><td class="saisir"> </td></tr>
  <tr><th>Nombre total d'heures prévisibles</th><td class="saisir"> </td></tr>
  <tr><th>Horaires de travail sur site</th><td class="saisir"> </td></tr>
  <tr><th>Type de plan de prévention</th><td class="saisir">☐ Ponctuel (une intervention) &nbsp;&nbsp; ☐ Annuel / renouvelable</td></tr>
  <tr><th>Date de révision prévue</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 3. TRAVAUX DANGEREUX ===== -->
<h2 class="page-break">3. Identification des travaux dangereux</h2>
<p class="note">Cocher les travaux concernés. La présence d'UN SEUL de ces travaux rend le plan de prévention écrit OBLIGATOIRE, quelle que soit la durée (Arrêté du 19 mars 1993).</p>
<table>
  <thead><tr><th class="check">✓</th><th>Type de travaux dangereux</th></tr></thead>
  <tbody>${travauxDangereux}</tbody>
</table>

<!-- ===== 4. INSPECTION COMMUNE ===== -->
<h2>4. Inspection commune préalable (OBLIGATOIRE — art. R4512-2 CT)</h2>
<table>
  <tr><th style="width:35%">Date de l'inspection commune</th><td class="saisir"> </td></tr>
  <tr><th>Participants (EU)</th><td class="saisir"> </td></tr>
  <tr><th>Participants (EE)</th><td class="saisir"> </td></tr>
  <tr><th>Zones et installations examinées</th><td class="saisir"> </td></tr>
  <tr><th>Consignes particulières du site communiquées</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 5. ANALYSE DES RISQUES D'INTERFÉRENCE ===== -->
<h2 class="page-break">5. Analyse des risques d'interférence</h2>
<p class="note">Risques résultant de l'interférence entre les activités, installations et matériels des différentes entreprises (art. R4512-6 CT).</p>

<h3>5.1 Risques présents sur le site (issus du DUERP de l'entreprise utilisatrice)</h3>
<table>
  <thead><tr><th>Zone / Unité</th><th>Danger identifié</th><th>Niveau</th><th>Mesure de prévention retenue</th></tr></thead>
  <tbody>${risquesSite || '<tr><td colspan="4" class="saisir">À compléter à partir du DUERP</td></tr>'}</tbody>
</table>

<h3>5.2 Risques importés par l'entreprise extérieure</h3>
<table>
  <thead><tr><th>Phase de travail</th><th>Danger</th><th>Mesure de prévention</th><th>Responsable</th></tr></thead>
  <tbody>${Array(5).fill('<tr>'+Array(4).fill('<td class="saisir"> </td>').join('')+'</tr>').join('')}</tbody>
</table>

<h3>5.3 Risques de coactivité (interférence EU ↔ EE)</h3>
<table>
  <thead><tr><th>Situation de coactivité</th><th>Risque généré</th><th>Mesure de coordination</th></tr></thead>
  <tbody>${Array(4).fill('<tr>'+Array(3).fill('<td class="saisir"> </td>').join('')+'</tr>').join('')}</tbody>
</table>

<!-- ===== 6. SECTIONS OBLIGATOIRES ===== -->
<h2 class="page-break">6. Contenu réglementaire du plan (art. R4512-8 CT)</h2>
<table>
  <thead><tr><th class="check">N°</th><th>Élément obligatoire</th></tr></thead>
  <tbody>${sections}</tbody>
</table>

<h3>6.1 Phases dangereuses et moyens de prévention spécifiques</h3>
<table>
  <thead><tr><th>Phase d'activité dangereuse</th><th>Moyen de prévention spécifique</th></tr></thead>
  <tbody>${Array(4).fill('<tr>'+Array(2).fill('<td class="saisir"> </td>').join('')+'</tr>').join('')}</tbody>
</table>

<h3>6.2 Instructions données aux travailleurs</h3>
<table><tr><td class="saisir" style="min-height:60pt"> </td></tr></table>

<!-- ===== 7. MOYENS DE SECOURS ===== -->
<h2>7. Organisation des secours</h2>
<table>
  <tr><th style="width:35%">Localisation trousse de secours</th><td class="saisir"> </td></tr>
  <tr><th>Sauveteur(s) Secouriste(s) du Travail sur site</th><td class="saisir"> </td></tr>
  <tr><th>Point de rassemblement en cas d'évacuation</th><td class="saisir"> </td></tr>
  <tr><th>Numéros d'urgence</th><td>SAMU : 15 — Pompiers : 18 — Urgence : 112 — Sourds/malentendants : 114 (SMS/visio)</td></tr>
</table>

<!-- ===== 8. AUTORISATIONS ===== -->
<h2 class="page-break">8. Autorisations, habilitations et permis</h2>
<table>
  <thead><tr><th>Type</th><th>Requis ?</th><th>Titulaire / N°</th><th>Validité</th></tr></thead>
  <tbody>
    <tr><td>Permis de feu (travaux par point chaud)</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td>Habilitation électrique</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td>CACES (conduite d'engins)</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td>Autorisation de travail en hauteur</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td>Autorisation d'intervention espace confiné</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td>Certification amiante (SS3/SS4)</td><td class="check">☐</td><td class="saisir"> </td><td class="saisir"> </td></tr>
  </tbody>
</table>

<h3>Documents remis ou vérifiés</h3>
<table>
  <thead><tr><th class="check">✓</th><th>Document</th><th>Remis / vérifié le</th><th>Observation</th></tr></thead>
  <tbody>
    <tr><td class="check">☐</td><td>Attestation d'assurance (RC pro / décennale le cas échéant)</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>Habilitations (électriques, etc.)</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>Autorisations de conduite / CACES</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>FDS si produits chimiques apportés</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>PPSPS si opération soumise à coordination SPS</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>Consignes du site remises à l'EE</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>Plan de circulation remis</td><td class="saisir"> </td><td class="saisir"> </td></tr>
    <tr><td class="check">☐</td><td>Permis feu (travaux par point chaud)</td><td class="saisir"> </td><td class="saisir"> </td></tr>
  </tbody>
</table>

<!-- ===== 9. DÉMARCHE ===== -->
<h2>9. Rappel de la démarche réglementaire</h2>
<table>
  <thead><tr><th>Étape</th><th>Base légale</th><th>Description</th></tr></thead>
  <tbody>${etapes}</tbody>
</table>

<!-- ===== 10. SIGNATURES ===== -->
<h2 class="page-break">10. Validation et signatures</h2>
<p class="note">Le plan de prévention est arrêté en commun AVANT le début des travaux. Il est tenu à disposition de l'inspection du travail, du médecin du travail et du CSE des deux entreprises.</p>
<table>
  <tr>
    <td style="width:50%;padding:20pt;">
      <strong>Entreprise Utilisatrice</strong><br>
      ${client.nom||'—'}<br>
      Nom du signataire : ________________<br>
      Fonction : ________________<br>
      Date : ${date}<br><br>
      Signature et cachet :<br><br><br>
    </td>
    <td style="width:50%;padding:20pt;">
      <strong>Entreprise Extérieure</strong><br>
      ________________<br>
      Nom du signataire : ________________<br>
      Fonction : ________________<br>
      Date : ________________<br><br>
      Signature et cachet :<br><br><br>
    </td>
  </tr>
</table>

<p class="note" style="margin-top:16pt;">
  Document établi avec l'appui de ${consultant.nom||'PF24 QSE'} — ${consultant.email||'contact@pf24qse.fr'}<br>
  Conservation recommandée : durée de l'opération + archivage. À renouveler à chaque nouvelle intervention ou modification des conditions.
</p>

<p class="note" style="text-align:center;margin-top:14pt;border-top:1pt solid #E3E8F0;padding-top:6pt;">${((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage||'PF24 QSE — Prévention Facile'}</p>
</body></html>`;
}

/* ================================================================
   PROTOCOLE DE SÉCURITÉ — Chargement / Déchargement
   Art. R4515-1 à R4515-11 CT — Arrêté du 26 avril 1996
   Obligatoire pour toute opération de chargement/déchargement
   impliquant une entreprise de transport extérieure
   ================================================================ */
function generateProtocoleSecuriteWord(visit, client, risques) {
  const consultant = PF24_DB.getConsultant();
  const date = new Date().toLocaleDateString('fr-FR');

  const style = `
    body{font-family:Arial,sans-serif;font-size:10pt;color:#0B1B33;margin:1.8cm;}
    h1{font-size:15pt;color:#0B1B33;border-bottom:3px solid #1E9E63;padding-bottom:6pt;}
    h2{font-size:11.5pt;color:white;background:#0B1B33;padding:6pt 10pt;margin-top:18pt;}
    h3{font-size:10pt;color:#16294A;margin-top:12pt;font-weight:bold;}
    table{border-collapse:collapse;width:100%;margin:8pt 0;font-size:9pt;}
    th{background:#F4F6F9;color:#0B1B33;padding:5pt;text-align:left;border:1px solid #ccc;font-size:9pt;}
    td{border:1px solid #ccc;padding:5pt;vertical-align:top;}
    .saisir{background:#FFFDE7;min-width:60pt;}
    .note{font-size:8pt;color:#5B6472;font-style:italic;margin:4pt 0;}
    .header{background:#0B1B33;color:white;padding:14pt;margin-bottom:12pt;}
    .header h1{color:white;border:none;margin:0;}
    .legal{background:#E5F6ED;border-left:4px solid #1E9E63;padding:8pt 12pt;margin:8pt 0;font-size:8.5pt;}
    .check{width:18pt;text-align:center;}
    .page-break{page-break-before:always;}
  `;

  return `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Protocole de sécurité — ${client.nom||''}</title><style>${style}</style></head>
<body>

<div class="header">
  <h1>Protocole de Sécurité</h1>
  <div style="font-size:9pt;opacity:.85;margin-top:6pt;">
    Opérations de chargement / déchargement — Art. R4515-1 à R4515-11 du Code du travail<br>
    Entreprise d'accueil : <strong>${client.nom||'—'}</strong> &nbsp;|&nbsp;
    SIRET : ${client.siret||'—'} &nbsp;|&nbsp; Date : ${date}
  </div>
</div>

<div class="legal">
  <strong>Cadre réglementaire :</strong> Le protocole de sécurité est OBLIGATOIRE pour toute opération de chargement ou de déchargement réalisée par une entreprise de transport extérieure dans l'enceinte d'une entreprise d'accueil (art. R4515-1 CT). Il remplace le plan de prévention pour ces opérations spécifiques. Il est établi préalablement et peut couvrir des opérations à caractère répétitif (protocole permanent) tant que les conditions restent inchangées.
</div>
<div class="legal">Ce document a été établi sur la base des informations communiquées par l'employeur et des observations disponibles à la date de génération. Toute évolution de l'activité, des locaux, des effectifs, des équipements, des produits utilisés ou de l'organisation du travail peut nécessiter une mise à jour. La mise à jour, la diffusion et la mise en œuvre des mesures de prévention relèvent de la responsabilité de l'employeur.</div>

<!-- ===== 1. ENTREPRISES ===== -->
<h2>1. Identification des parties</h2>
<h3>Entreprise d'accueil</h3>
<table>
  <tr><th style="width:35%">Raison sociale</th><td>${client.nom||'—'}</td></tr>
  <tr><th>Adresse du site</th><td class="saisir">${client.adresse||' '}</td></tr>
  <tr><th>Responsable désigné pour l'opération</th><td class="saisir">${client.valideur||client.contact||' '}</td></tr>
  <tr><th>Contact d'urgence entreprise d'accueil (nom + tél.)</th><td class="saisir"> </td></tr>
  <tr><th>Téléphone</th><td class="saisir"> </td></tr>
</table>

<h3>Entreprise de transport</h3>
<table>
  <tr><th style="width:35%">Raison sociale</th><td class="saisir"> </td></tr>
  <tr><th>Adresse</th><td class="saisir"> </td></tr>
  <tr><th>Conducteur / chauffeur</th><td class="saisir"> </td></tr>
  <tr><th>Téléphone</th><td class="saisir"> </td></tr>
  <tr><th>Type de véhicule</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 2. MARCHANDISE ===== -->
<h2>2. Nature de la marchandise</h2>
<table>
  <tr><th style="width:35%">Nature des marchandises</th><td class="saisir"> </td></tr>
  <tr><th>Conditionnement (palettes, vrac, conteneurs…)</th><td class="saisir"> </td></tr>
  <tr><th>Poids / volume estimé</th><td class="saisir"> </td></tr>
  <tr><th>Marchandises dangereuses (ADR) ?</th><td class="saisir">☐ Non &nbsp;&nbsp; ☐ Oui — Classe ADR : ______</td></tr>
  <tr><th>Précautions particulières (nature des substances)</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 3. ACCÈS ET CIRCULATION ===== -->
<h2 class="page-break">3. Accès, circulation et stationnement</h2>
<table>
  <tr><th style="width:35%">Modalités d'accès au site</th><td class="saisir"> </td></tr>
  <tr><th>Plan de circulation communiqué ?</th><td class="saisir">☐ Oui — plan joint &nbsp;&nbsp; ☐ Non applicable</td></tr>
  <tr><th>Lieu précis de chargement / déchargement</th><td class="saisir"> </td></tr>
  <tr><th>Modalités de stationnement du véhicule</th><td class="saisir"> </td></tr>
  <tr><th>Sens de circulation imposé</th><td class="saisir"> </td></tr>
  <tr><th>Limitation de vitesse sur site</th><td class="saisir"> km/h</td></tr>
  <tr><th>Consignes particulières au chauffeur</th><td class="saisir">Ex. : moteur coupé, calage, présence en cabine…</td></tr>
  <tr><th>Plan du site joint</th><td class="saisir">☐ Oui — en annexe &nbsp;&nbsp; ☐ Non disponible</td></tr>
  <tr><th>Zones dangereuses à éviter</th><td class="saisir"> </td></tr>
</table>

<!-- ===== 4. MATÉRIELS ===== -->
<h2>4. Matériels et engins utilisés</h2>
<table>
  <thead><tr><th>Matériel / engin</th><th>Fourni par</th><th>Conducteur habilité (CACES)</th></tr></thead>
  <tbody>
    <tr><td>Chariot élévateur</td><td class="saisir">☐ Accueil ☐ Transport</td><td class="saisir"> </td></tr>
    <tr><td>Transpalette</td><td class="saisir">☐ Accueil ☐ Transport</td><td class="saisir"> </td></tr>
    <tr><td>Hayon élévateur</td><td class="saisir">☐ Accueil ☐ Transport</td><td class="saisir"> </td></tr>
    <tr><td>Autre :</td><td class="saisir"> </td><td class="saisir"> </td></tr>
  </tbody>
</table>

<!-- ===== 5. RISQUES ET PRÉVENTION ===== -->
<h2>5. Risques identifiés et mesures de prévention</h2>
<table>
  <thead><tr><th>Risque</th><th>Présent ?</th><th>Mesure de prévention</th></tr></thead>
  <tbody>
    <tr><td>Renversement de chariot / engin</td><td class="check">☐</td><td>Sol stabilisé, vitesse limitée, formation CACES</td></tr>
    <tr><td>Chute de la marchandise / palette</td><td class="check">☐</td><td>Arrimage vérifié, charge stable, zone dégagée</td></tr>
    <tr><td>Heurt entre piéton et véhicule</td><td class="check">☐</td><td>Séparation flux, gilet HV, calage des roues</td></tr>
    <tr><td>Chute de hauteur (depuis le quai/plateau)</td><td class="check">☐</td><td>Garde-corps, plaque de quai, échelle sécurisée</td></tr>
    <tr><td>Écrasement (recul du véhicule)</td><td class="check">☐</td><td>Calage, cale-roue, avertisseur de recul</td></tr>
    <tr><td>TMS (manutention manuelle)</td><td class="check">☐</td><td>Aide mécanique, limitation des charges</td></tr>
    <tr><td>Marchandises dangereuses (ADR)</td><td class="check">☐</td><td>Procédure ADR, EPI adaptés, plan d'urgence</td></tr>
  </tbody>
</table>

<!-- ===== 6. SECOURS ===== -->
<h2 class="page-break">6. Consignes de sécurité et secours</h2>
<table>
  <tr><th style="width:35%">Localisation des moyens de secours</th><td class="saisir"> </td></tr>
  <tr><th>Point de rassemblement en cas d'évacuation</th><td class="saisir"> </td></tr>
  <tr><th>Consigne en cas d'accident</th><td>Alerter le responsable de l'entreprise d'accueil + Appeler les secours (15 / 18 / 112 — 114 par SMS pour sourds/malentendants)</td></tr>
  <tr><th>EPI obligatoires sur site</th><td class="saisir">☐ Chaussures de sécurité ☐ Gilet HV ☐ Casque ☐ Gants</td></tr>
</table>

<!-- ===== 7. SIGNATURES ===== -->
<h2>7. Validation et signatures</h2>
<p class="note">Le protocole est établi préalablement à l'opération. Pour les opérations répétitives dans des conditions identiques, il reste valable tant que les conditions n'évoluent pas (protocole permanent). À défaut, il est établi à chaque opération.</p>
<table>
  <tr>
    <td style="width:50%;padding:20pt;">
      <strong>Entreprise d'accueil</strong><br>
      ${client.nom||'—'}<br>
      Nom : ________________<br>
      Fonction : ________________<br>
      Date : ${date}<br><br>
      Signature :<br><br><br>
    </td>
    <td style="width:50%;padding:20pt;">
      <strong>Entreprise de transport</strong><br>
      ________________<br>
      Nom : ________________<br>
      Fonction : ________________<br>
      Date : ________________<br><br>
      Signature :<br><br><br>
    </td>
  </tr>
</table>

<p class="note" style="margin-top:16pt;">
  Type de protocole : ☐ Ponctuel (une opération) &nbsp;&nbsp; ☐ Permanent (opérations répétitives)<br>
  Date de révision prévue : ______________ — Conditions de validité : le protocole permanent reste valable tant que les marchandises, matériels, lieux et modalités d'accès demeurent inchangés ; toute modification impose sa révision.<br>
  Tenu à la disposition du CSE et de l'inspection du travail des deux entreprises (art. R4515-11 CT).<br>
  Document établi avec l'appui de ${consultant.nom||'PF24 QSE'} — ${consultant.email||'contact@pf24qse.fr'}
</p>

<p class="note" style="text-align:center;margin-top:14pt;border-top:1pt solid #E3E8F0;padding-top:6pt;">${((typeof PF24_DB!=="undefined"&&PF24_DB.getConsultant&&PF24_DB.getConsultant())||{}).piedPage||'PF24 QSE — Prévention Facile'}</p>
</body></html>`;
}
