/* PF24 V3 — Application principale (BUG-FIXED) */
const APP = {
  screen:"login", history:[], visit:null, client:null,
  clientId:null, devisId:null, factureId:null,
  currentBlocId:null, currentTab:"info", editClient:null,
  _clientPhotoId:null, _devisClientId:"", _upsellSuggestions:[], _devisOffrePrecoche:""
};

const root = document.getElementById("app");

/* ---- TOAST ---- */
function toast(msg, dur=2600){
  const t=document.getElementById("toast");
  t.textContent=msg; t.classList.add("show");
  clearTimeout(t._tid); t._tid=setTimeout(()=>t.classList.remove("show"),dur);
}

/* ---- NAV ---- */
function go(screen, push=true){
  if(push) APP.history.push(APP.screen);
  APP.screen=screen; render();
}
function back(){
  const p=APP.history.pop();
  APP.screen=p||"dashboard"; render();
}

const VISIT_SCREENS=["choix-metier","choix-client","choix-blocs","population",
  "visite-blocs","visite-bloc-detail","photos","risques","validation",
  "registre-screen","historique-screen","upsell"];
const NAV_MAP_MAIN={"dashboard":"dashboard","clients":"clients","devis":"devis",
  "factures":"factures","parametres":"parametres","relances":"relances","catalogue":"catalogue"};

function showNav(){
  const auth=PF24_DB.checkAuth();
  const inVisit=VISIT_SCREENS.includes(APP.screen);
  const nm=document.getElementById("nav-main");
  const nv=document.getElementById("nav-visit");
  if(nm){
    nm.classList.toggle("hidden", !auth||inVisit);
    // active state
    nm.querySelectorAll("button").forEach(b=>{
      const s=b.dataset.go;
      b.classList.toggle("active", s===APP.screen||
        (s==="clients"&&["client-detail","nouveau-client"].includes(APP.screen))||
        (s==="devis"&&["devis-detail","nouveau-devis"].includes(APP.screen))||
        (s==="factures"&&APP.screen==="facture-detail"));
    });
  }
  if(nv){
    nv.classList.toggle("hidden", !auth||!inVisit||APP.screen==="choix-client"||APP.screen==="choix-metier"||APP.screen==="upsell");
  }
}

/* ---- RENDER ---- */
async function render(){
  if(!PF24_DB.checkAuth()){ root.innerHTML=R.login(); showNav(); _bind(); return; }
  if(!APP.visit && VISIT_SCREENS.includes(APP.screen) &&
     !["choix-client","choix-metier","upsell"].includes(APP.screen)){
    APP.screen="dashboard";
  }
  const s=APP.screen;
  try{
    if(s==="dashboard") root.innerHTML=R.dashboard(PF24_DB.getDashboardStats());
    else if(s==="clients") root.innerHTML=R.clientsList(PF24_DB.getClients());
    else if(s==="client-detail"){ const c=PF24_DB.getClient(APP.clientId); if(!c){go("clients");return;} root.innerHTML=R.clientDetail(c,APP.currentTab,PF24_DB.getVisitsForClient(c.id),PF24_DB.getDevisForClient(c.id),PF24_DB.getFacturesForClient(c.id)); }
    else if(s==="nouveau-client") root.innerHTML=R.nouveauClient(APP.editClient||null);
    else if(s==="catalogue") root.innerHTML=R.catalogue();
    else if(s==="devis") root.innerHTML=R.devisList(PF24_DB.getDevis(),PF24_DB.getClients());
    else if(s==="nouveau-devis"){ root.innerHTML=R.nouveauDevis(PF24_DB.getClients(),APP._devisClientId||"",APP._devisOffrePrecoche||""); }
    else if(s==="devis-detail"){ const d=PF24_DB.getDevisById(APP.devisId); if(!d){go("devis");return;} root.innerHTML=R.devisDetail(d,PF24_DB.getClient(d.clientId)); }
    else if(s==="factures") root.innerHTML=R.facturesList(PF24_DB.getFactures(),PF24_DB.getClients());
    else if(s==="facture-detail"){ const f=PF24_DB.getFactureById(APP.factureId); if(!f){go("factures");return;} root.innerHTML=R.factureDetail(f,PF24_DB.getClient(f.clientId)); }
    else if(s==="relances") root.innerHTML=R.relances(PF24_DB.getRelances());
    else if(s==="parametres") root.innerHTML=R.parametres(PF24_DB.getConsultant());
    else if(s==="choix-client") root.innerHTML=R.choixClient(PF24_DB.getClients());
    else if(s==="choix-metier") root.innerHTML=R.choixMetier();
    else if(s==="choix-blocs") root.innerHTML=R.choixBlocs(APP.visit);
    else if(s==="population") root.innerHTML=R.populationBlocs(APP.visit);
    else if(s==="visite-blocs") root.innerHTML=R.visiteBlocs(APP.visit, PF24_DB.getClient(APP.visit?.clientId));
    else if(s==="visite-bloc-detail") root.innerHTML=R.visiteBlocDetail(APP.visit, APP.currentBlocId);
    else if(s==="photos"){ const ph=await _resolvePhotos(); root.innerHTML=R.photosGalerie(APP.visit,ph); }
    else if(s==="risques"){ const {risques}=PF24_ENGINE.genererRisques(APP.visit); root.innerHTML=R.risquesListe(risques); }
    else if(s==="validation") await _renderValidation();
    else if(s==="registre-screen") root.innerHTML=R.registreScreen(APP.visit);
    else if(s==="historique-screen") root.innerHTML=R.historiqueScreen(APP.visit);
    else if(s==="upsell") root.innerHTML=R.upsell(APP._upsellSuggestions||[]);
    else root.innerHTML=R.dashboard(PF24_DB.getDashboardStats());
  }catch(err){ console.error("Render error:",err); root.innerHTML=`<div style="padding:20px;color:red;font-family:monospace;">Erreur d'affichage : ${err.message}</div>`; }
  showNav(); _bind();
}

async function _renderValidation(){
  if(!APP.visit){go("dashboard");return;}
  APP.visit.population=APP.visit.population||{};
  const {risques,actions}=PF24_ENGINE.genererRisques(APP.visit);
  const client=PF24_DB.getClient(APP.visit.clientId);
  const score=PF24_ENGINE.calculerScore(APP.visit);
  const scoreConf=PF24_ENGINE.calculerScoreConformite(APP.visit,client);
  const stats={blocs:(APP.visit.blocsSelectionnes||[]).length,
    objets:Object.values(APP.visit.blocs||{}).reduce((s,b)=>s+Object.values(b.objets||{}).filter(o=>o.statut==="present").length,0),
    photos:(APP.visit.photos||[]).length};
  root.innerHTML=R.validation(APP.visit,risques,actions,score,scoreConf,stats,PF24_DB.getClient(APP.visit?.clientId));
}

async function _resolvePhotos(){
  const out=[];
  for(const p of APP.visit?.photos||[]){ const du=await PF24_DB.getPhoto(p.id); out.push({...p,dataUrl:du,blocNom:BLOCS[p.blocId]?.nom||""}); }
  return out;
}

/* ---- VISIT HELPERS ---- */
function newVisit(clientId){
  const client=PF24_DB.getClient(clientId);
  APP.visit={ id:PF24_DB.uid("visit"), clientId,
    metierId:null, metierNom:null, blocsSelectionnes:[], blocs:{},
    population:{}, registre:{}, historique:[], photos:[],
    redacteur:client?.redacteur||PF24_DB.getConsultant().nom||"",
    entreprisesExterieures:client?.entreprisesExterieures||false,
    teletravail:client?.teletravail||false, deplacements:client?.deplacements||false,
    statut:"en_cours", createdAt:new Date().toISOString() };
}
function _ensureBloc(bid){ APP.visit.blocs[bid]=APP.visit.blocs[bid]||{objets:{}}; return APP.visit.blocs[bid]; }
function _ensureObj(bid,obj){ const b=_ensureBloc(bid); b.objets[obj]=b.objets[obj]||{statut:null,maitrise:null,observation:"",photos:[]}; return b.objets[obj]; }
function _saveVisit(){ PF24_DB.saveVisit(APP.visit); }
function _openCamera(cb){ const i=document.createElement("input"); i.type="file"; i.accept="image/*"; i.capture="environment"; i.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(f);}; i.click(); }

/* ---- BIND events after render ---- */
function _bind(){
  // Back buttons
  document.querySelectorAll("[data-back]").forEach(el=>el.onclick=e=>{e.stopPropagation();back();});
  // Bottom nav buttons
  document.querySelectorAll("#nav-main button, #nav-visit button").forEach(b=>{
    b.onclick=()=>{ const t=b.dataset.go; if(t) go(t,false); };
  });
  // Client tabs
  document.querySelectorAll("[data-client-tab]").forEach(b=>{
    b.onclick=()=>{ APP.currentTab=b.dataset.clientTab; render(); };
  });
  // Toggle yes/no
  document.querySelectorAll("[data-toggle]").forEach(el=>{
    el.onclick=()=>{
      const id=el.dataset.toggle, val=el.dataset.val;
      const inp=document.getElementById(id); if(inp) inp.value=val;
      el.closest("div[style*='display:flex']")?.querySelectorAll("[data-toggle]").forEach(c=>{
        c.classList.remove("sel-yes","sel-no");
        if(c.dataset.val===val) c.classList.add(val==="oui"?"sel-yes":"sel-no");
      });
    };
  });
  // Population toggles
  document.querySelectorAll("[data-pop-toggle]").forEach(el=>{
    el.onclick=()=>{ if(!APP.visit)return; const bid=el.dataset.popToggle,field=el.dataset.field; const p=APP.visit.population[bid]=APP.visit.population[bid]||{}; p[field]=!p[field]; _saveVisit(); render(); };
  });
  document.querySelectorAll("[data-pop]").forEach(inp=>{
    inp.oninput=()=>{ if(!APP.visit)return; const bid=inp.dataset.pop,field=inp.dataset.field; const p=APP.visit.population[bid]=APP.visit.population[bid]||{}; p[field]=inp.type==="number"?Number(inp.value):inp.value; _saveVisit(); };
  });
  // Devis total preview
  if(APP.screen==="nouveau-devis") _bindDevisCalc();
  // Load photos in preview
  document.querySelectorAll("[data-photoid]").forEach(async img=>{ const du=await PF24_DB.getPhoto(img.dataset.photoid); if(du) img.src=du; });
  // Login Enter key
  const pi=document.getElementById("pwd-input");
  if(pi) pi.onkeydown=e=>{ if(e.key==="Enter") document.getElementById("btn-login")?.click(); };
  document.getElementById("btn-login")?.addEventListener("click",_handleLogin);
  // Logo PF24 → dataURL pour les en-têtes PDF
  fetch("assets/logo.png").then(r=>r.blob()).then(bl=>{const fr=new FileReader();fr.onload=()=>{window.PF24_LOGO=fr.result;};fr.readAsDataURL(bl);}).catch(()=>{});
}

function _handleLogin(){
  const pwd=document.getElementById("pwd-input")?.value;
  if(PF24_DB.login(pwd)){ go("dashboard",false); }
  else{ toast("❌ Mot de passe incorrect"); }
}

function _bindDevisCalc(){

  function dvCalcPrix(catId){
    const cb=document.getElementById("dv-cat-"+catId);
    if(!cb) return;
    const base=Number(cb.dataset.baseprix)||0;
    const eff=Number(document.getElementById("dv-effectif")?.value||0);
    const cpx=document.getElementById("dv-complexite")?.value||"simple";
    return calculerPrixAdapte(base,eff,cpx);
  }

  function dvUpdateTotal(){
    let total=0;
    document.querySelectorAll(".dv-cb").forEach(cb=>{
      if(!cb.checked) return;
      const pi=document.getElementById("dv-price-"+cb.dataset.catid);
      total+=Number(pi?.value||0);
    });
    const el=document.getElementById("dv-total-num");
    if(el) el.textContent=total.toFixed(2).replace(".",",")+"\u00a0€";
  }

  function dvToggle(cb){
    const id=cb.dataset.catid;
    const pi=document.getElementById("dv-price-"+id);
    const tarif=document.getElementById("dv-tarif-"+id);
    const line=document.getElementById("dvline-"+id);
    if(cb.checked){
      const calc=dvCalcPrix(id);
      const base=Number(cb.dataset.baseprix)||0;
      pi.value=calc;
      pi.disabled=false;
      pi.style.opacity="1";
      pi.style.background="#fff";
      pi.style.borderColor="var(--green)";
      if(tarif){ tarif.textContent=calc!==base?(base+" €"):""; }
      if(line) line.style.background="#F0FDF4";
    } else {
      pi.disabled=true;
      pi.style.opacity=".45";
      pi.style.background="#f8f9fb";
      pi.style.borderColor="var(--grey-line)";
      if(tarif) tarif.textContent="";
      if(line) line.style.background="";
    }
    dvUpdateTotal();
  }

  function dvRecalcAll(){
    document.querySelectorAll(".dv-cb").forEach(cb=>{
      if(cb.checked) dvToggle(cb);
    });
  }

  // Bind checkboxes
  document.querySelectorAll(".dv-cb").forEach(cb=>{
    cb.onchange=()=>dvToggle(cb);
  });

  // Bind price inputs (manual override)
  document.querySelectorAll(".dv-pi").forEach(pi=>{
    pi.oninput=()=>{
      const id=pi.id.replace("dv-price-","");
      const cb=document.getElementById("dv-cat-"+id);
      const tarif=document.getElementById("dv-tarif-"+id);
      if(tarif&&cb){
        const base=Number(cb.dataset.baseprix)||0;
        const saisie=Number(pi.value)||0;
        if(saisie<base) tarif.textContent=base+" €";
        else tarif.textContent="";
      }
      dvUpdateTotal();
    };
  });

  // Effectif / complexité → recalculer tous les cochés
  document.getElementById("dv-effectif")?.addEventListener("input",dvRecalcAll);
  document.getElementById("dv-complexite")?.addEventListener("change",dvRecalcAll);
}

/* ==============================================================
   GLOBAL CLICK HANDLER — data-open-* BEFORE guard, then data-action
   ============================================================== */
/* ================================================================
   EXPORT WORD (.docx) — helpers multi-plateforme
   Cause du bug corrigé : _sanitizeForDocx/_wordFallback étaient
   appelées sans être définies → ReferenceError à chaque clic.
   ================================================================ */
const APP_VERSION = "5.4";
const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

/* Retire emojis / caractères non-XML avant conversion OOXML */
function _sanitizeForDocx(html){
  // Retirer uniquement les emojis pictographiques (non supportés par certaines
  // versions de Word) — les symboles BMP (✓ ✔ ✗ ☐ ☑ ⚠ →) sont conservés.
  return html
    .replace(/[\u{1F000}-\u{1FAFF}]/gu, '')
    .replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '')
    .replace(/[\u{FE00}-\u{FE0F}]/gu, '')
    .replace(/\u{200D}/gu, '');
}

function _isIOS(){
  return (/iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform==="MacIntel" && navigator.maxTouchPoints>1)) && !window.MSStream;
}

/* Partage natif iOS — retourne un statut précis */
async function _shareDocx(bl, filename){
  const file = new File([bl], filename, { type: DOCX_MIME });
  if(!(navigator.canShare && navigator.canShare({files:[file]}))) return "unsupported";
  try{
    await navigator.share({ files:[file] });
    return "shared";
  }catch(e){
    if(e && e.name === "AbortError") return "aborted";      // annulé par l'utilisateur
    if(e && e.name === "NotAllowedError") return "expired"; // geste utilisateur expiré
    console.error("[Word] navigator.share:", e);
    return "error";
  }
}

/* Téléchargement classique (Android / Desktop / Safari onglet) */
function _anchorDownload(bl, filename){
  const url = URL.createObjectURL(bl);
  const lnk = document.createElement("a");
  lnk.href = url; lnk.download = filename; lnk.rel = "noopener";
  document.body.appendChild(lnk); lnk.click(); document.body.removeChild(lnk);
  setTimeout(()=>URL.revokeObjectURL(url), 60000);
}

/* Barre "Document prêt" : garantit un geste utilisateur FRAIS pour iOS
   (navigator.share exige un geste ; il peut expirer pendant la génération) */
function _showDocxButton(bl, filename){
  const old = document.getElementById("docx-ready-bar");
  if(old) old.remove();
  const bar = document.createElement("div");
  bar.id = "docx-ready-bar";
  bar.style.cssText = "position:fixed;left:12px;right:12px;bottom:calc(84px + env(safe-area-inset-bottom));z-index:9999;background:#0B1B33;color:#fff;border-radius:14px;padding:14px 16px;box-shadow:0 8px 24px rgba(0,0,0,.35);display:flex;align-items:center;gap:12px;";
  const info = document.createElement("div");
  info.style.cssText = "flex:1;font-size:14px;line-height:1.35;";
  info.innerHTML = "<strong>Document prêt</strong><br><span style='opacity:.8;font-size:12px;'>"+filename+"</span>";
  const go = document.createElement("button");
  go.textContent = "Enregistrer";
  go.style.cssText = "background:#1E9E63;color:#fff;border:none;border-radius:10px;padding:10px 16px;font-weight:700;font-size:14px;";
  const x = document.createElement("button");
  x.textContent = "\u2715";
  x.style.cssText = "background:transparent;color:#fff;border:none;font-size:18px;padding:4px;";
  bar.appendChild(info); bar.appendChild(go); bar.appendChild(x);
  document.body.appendChild(bar);
  x.onclick = () => bar.remove();
  go.onclick = async () => {
    const r = await _shareDocx(bl, filename);   // geste frais → autorisé
    if(r === "shared"){ bar.remove(); toast("Enregistré"); }
    else if(r === "aborted"){ /* garder la barre pour réessayer */ }
    else { bar.remove(); _anchorDownload(bl, filename); toast("Téléchargement lancé"); }
  };
}

/* Point d'entrée unique de livraison */

/* ================================================================
   CONTRÔLE QUALITÉ AVANT EXPORT — bloque les incohérences évidentes
   ================================================================ */
function _qcIssues(client, visit){
  const iss=[];
  const c=client||{};
  if(!c.nom||!c.nom.trim()) iss.push("Raison sociale du client manquante");
  if(!c.siret||!c.siret.trim()) iss.push("SIRET manquant");
  if(!c.adresse||!c.adresse.trim()) iss.push("Adresse du client manquante");
  if(!c.valideur&&!c.contact) iss.push("Nom du dirigeant / valideur manquant");
  const nb=Number(c.salaries)||0;
  if(nb>0&&(!c.spst||!c.spst.trim())) iss.push("SPST non renseigné (obligatoire dès 1 salarié)");
  const cons=PF24_DB.getConsultant()||{};
  if(!cons.nom||!cons.nom.trim()) iss.push("Nom du consultant manquant (Paramètres)");
  if(visit){
    if(!(visit.blocsSelectionnes||[]).length) iss.push("Aucune unité de travail sélectionnée");
    const pop=Object.values(visit.population||{}).reduce((s,p)=>s+(Number(p.exposes)||0),0);
    if(nb===0&&pop>0) iss.push("Effectif client = 0 mais des salariés exposés sont déclarés dans les blocs");
    if(pop===0&&nb>0) iss.push("Aucun salarié exposé déclaré dans les blocs (RPS/nuit non évalués)");
    if(c.prochainMaj){ const d=new Date(c.prochainMaj); if(!isNaN(d)&&d<new Date(new Date().toDateString())) iss.push("Date de prochaine mise à jour déjà dépassée"); }
  }
  return iss;
}
function _qcConfirm(client, visit){
  const iss=_qcIssues(client, visit);
  if(!iss.length) return true;
  return confirm("Contrôle qualité — points à corriger :\n\n• "+iss.join("\n• ")+"\n\nLes champs manquants apparaîtront « À compléter par l\u2019employeur ».\nGénérer quand même ?");
}

async function _deliverDocx(bl, filename){
  if(_isIOS() && navigator.share){
    const r = await _shareDocx(bl, filename);
    if(r === "shared"){ toast("Enregistrez dans Fichiers ou ouvrez avec Word"); return; }
    if(r === "aborted"){ return; }
    _showDocxButton(bl, filename);   // "expired" / "unsupported" / "error"
    return;
  }
  _anchorDownload(bl, filename);
  toast("Fichier Word téléchargé — ouvrez-le avec Word ou LibreOffice");
}

document.addEventListener("click", async e=>{

  /* ---- data-open-* (list row clicks — NO data-action on them) ---- */
  const oc=e.target.closest("[data-open-client]");
  if(oc){ APP.clientId=oc.dataset.openClient; APP.currentTab="info"; go("client-detail"); return; }

  const od=e.target.closest("[data-open-devis]");
  if(od){ APP.devisId=od.dataset.openDevis; go("devis-detail"); return; }

  const of2=e.target.closest("[data-open-facture]");
  if(of2){ APP.factureId=of2.dataset.openFacture; go("facture-detail"); return; }

  const ov=e.target.closest("[data-open-visit]");
  if(ov){ const v=PF24_DB.getVisit(ov.dataset.openVisit); if(v){ APP.visit=v; APP.visit.population=APP.visit.population||{}; APP.visit.registre=APP.visit.registre||{}; APP.visit.historique=APP.visit.historique||[]; go("validation"); } return; }

  const sv=e.target.closest("[data-start-visit]");
  if(sv){ const cid=sv.dataset.startVisit; newVisit(cid); go("choix-metier"); return; }

  /* ---- data-action ---- */
  const t=e.target.closest("[data-action]"); if(!t) return;
  const act=t.dataset.action;

  /* AUTH */
  if(act==="logout"){ PF24_DB.logout(); APP.visit=null; go("login",false); return; }

  /* NAVIGATION shortcuts */
  const nmap={"go-clients":"clients","go-devis":"devis","go-factures":"factures","go-relances":"relances","go-catalogue":"catalogue","go-parametres":"parametres","go-dashboard":"dashboard","go-plus":"parametres"};
  if(nmap[act]){ go(nmap[act]); return; }
  if(act==="go-visite-flow"){ go("choix-client"); return; }
  if(act==="go-nouveau-client"){ APP.editClient=null; go("nouveau-client"); return; }
  if(act==="go-nouveau-client-visite"){ APP.editClient=null; APP._afterNewClient="visite"; go("nouveau-client"); return; }
  if(act==="go-nouveau-devis"){ APP._devisClientId=""; go("nouveau-devis"); return; }
  if(act==="upsell-devis"){
    APP._devisClientId=APP.visit?.clientId||"";
    APP._devisOffrePrecoche=t.dataset.offre||"";
    go("nouveau-devis");
    return;
  }

  /* CRM — Valider client */
  if(act==="valider-client"){
    const yn=id=>document.getElementById(id)?.value==="oui";
    const nom=document.getElementById("f-nom")?.value?.trim();
    if(!nom){ toast("La raison sociale est obligatoire"); return; }
    const editId=t.dataset.edit||APP.editClient?.id;
    const prev=editId?PF24_DB.getClient(editId):null;
    const client={
      id:editId||PF24_DB.uid("client"), nom,
      siret:document.getElementById("f-siret")?.value||"",
      ape:document.getElementById("f-ape")?.value||"",
      adresse:document.getElementById("f-adresse")?.value||"",
      telephone:document.getElementById("f-telephone")?.value||"",
      email:document.getElementById("f-email")?.value||"",
      contact:document.getElementById("f-contact")?.value||"",
      activite:document.getElementById("f-activite")?.value||"",
      salaries:document.getElementById("f-salaries")?.value||"0",
      hommes:document.getElementById("f-hommes")?.value||"0",
      femmes:document.getElementById("f-femmes")?.value||"0",
      spst:document.getElementById("f-spst")?.value||"",
      spstTel:document.getElementById("f-spstTel")?.value||"",
      referentSecurite:document.getElementById("f-referentSecurite")?.value||"",
      referentTel:document.getElementById("f-referentTel")?.value||"",
      trousseLocalisation:document.getElementById("f-trousseLocalisation")?.value||"",
      pointRassemblement:document.getElementById("f-pointRassemblement")?.value||"",
      fonctionDirigeant:document.getElementById("f-fonctionDirigeant")?.value||"",
      statut:document.getElementById("f-statut")?.value||"prospect",
      apprentis:yn("f-apprentis"), interimaires:yn("f-interimaires"),
      jeunesTravailleurs:yn("f-jeunes"), travailIsole:yn("f-isoles"),
      vulnerables:yn("f-vulnerables"), entreprisesExterieures:yn("f-exterieures"),
      deplacements:yn("f-deplacements"),
      redacteur:document.getElementById("f-redacteur")?.value||"",
      valideur:document.getElementById("f-valideur")?.value||"",
      prochainMaj:document.getElementById("f-prochainMaj")?.value||null,
      photoId:APP._clientPhotoId||prev?.photoId||null,
      createdAt:prev?.createdAt||new Date().toISOString(),
    };
    PF24_DB.saveClient(client); APP._clientPhotoId=null; APP.editClient=null;
    toast("Client enregistré ✔");
    APP.clientId=client.id;
    if(APP._afterNewClient==="visite"){ APP._afterNewClient=null; newVisit(client.id); go("choix-metier"); }
    else{ APP.currentTab="info"; go("client-detail"); }
    return;
  }

  if(act==="edit-client"){ APP.editClient=PF24_DB.getClient(t.dataset.client||APP.clientId); go("nouveau-client"); return; }
  if(act==="supprimer-client"){ const id=t.dataset.client||APP.clientId; if(!confirm("Supprimer ce client et toutes ses données ?")) return; PF24_DB.deleteClient(id); toast("Client supprimé"); go("clients"); return; }
  if(act==="prendre-photo-client"){ _openCamera(async du=>{ const id=PF24_DB.uid("photo"); await PF24_DB.savePhoto(id,du); APP._clientPhotoId=id; const pv=document.getElementById("preview-client"); if(pv) pv.innerHTML=`<img src="${du}" style="max-width:100%;border-radius:10px;margin-top:8px;">`; toast("Photo façade ajoutée"); }); return; }
  if(act==="demarrer-visite"||act==="demarrer-visite-client"){ const cid=t.dataset.client||APP.clientId; if(!cid){go("choix-client");return;} newVisit(cid); go("choix-metier"); return; }
  if(act==="nouveau-devis-client"){ APP._devisClientId=t.dataset.client||APP.clientId; go("nouveau-devis"); return; }

  /* DEVIS */
  if(act==="valider-devis"){
    const clientId=document.getElementById("dv-clientId")?.value;
    if(!clientId){ toast("Choisissez un client"); return; }
    const lignes=[]; let total=0;
    document.querySelectorAll("[id^='dv-cat-']").forEach(cb=>{
      if(!cb.checked) return;
      const catalogId=cb.id.replace("dv-cat-","");
      // Prix saisi manuellement dans le champ (après ajustement ou remise)
      const prixInput=document.getElementById("dv-price-"+catalogId);
      const prixFinal=Number(prixInput?.value||cb.dataset.baseprix||0);
      const prixBase=Number(cb.dataset.baseprix||cb.dataset.prix||0);
      lignes.push({
        catalogId, nom:cb.dataset.nom, qte:1,
        prixUnit:prixFinal, total:prixFinal,
        prixCatalogue:prixBase,
        remise:prixBase>prixFinal?Math.round((1-prixFinal/prixBase)*100):0
      });
      total+=prixFinal;
    });
    if(!lignes.length){ toast("Sélectionnez au moins une prestation"); return; }
    const d=PF24_DB.createDevis(clientId,lignes,{
      effectif:Number(document.getElementById("dv-effectif")?.value||0),
      complexite:document.getElementById("dv-complexite")?.value||"simple"
    });
    d.commentaire=document.getElementById("dv-commentaire")?.value||"";
    d.total=total;
    PF24_DB.saveDevis(d);
    toast("Devis "+d.numero+" créé ✔"); APP.devisId=d.id; go("devis-detail"); return;
  }
  if(act==="set-devis-statut"){ const d=PF24_DB.getDevisById(t.dataset.devis); if(d){d.statut=t.dataset.statut;PF24_DB.saveDevis(d);render();} return; }
  if(act==="generer-pdf-devis"){ const d=PF24_DB.getDevisById(t.dataset.devis); const c=PF24_DB.getClient(d.clientId); toast("Génération PDF…"); try{ const doc=await PF24_PDF.generateDevis(d,c,PF24_DB.getConsultant()); doc.save(`${d.numero}_${(c.nom||"client").replace(/\s+/g,"_")}.pdf`); toast("PDF devis généré ✔"); }catch(er){console.error(er);toast("Erreur PDF");} return; }
  if(act==="creer-facture-from-devis"){ const d=PF24_DB.getDevisById(t.dataset.devis); const f=PF24_DB.createFactureFromDevis(d); toast("Facture "+f.numero+" créée ✔"); APP.factureId=f.id; go("facture-detail"); return; }
  if(act==="supprimer-devis"){ if(!confirm("Supprimer ce devis ?")) return; PF24_DB.deleteDevisById(t.dataset.devis); toast("Devis supprimé"); go("devis"); return; }
  if(act==="open-offre"){ toast("Pour créer un devis avec cette prestation, allez dans Devis → Nouveau devis."); return; }

  /* FACTURES */
  if(act==="set-facture-statut"){ const f=PF24_DB.getFactureById(t.dataset.facture); if(f){f.statut=t.dataset.statut;PF24_DB.saveFacture(f);render();} return; }
  if(act==="generer-pdf-facture"){ const f=PF24_DB.getFactureById(t.dataset.facture); const c=PF24_DB.getClient(f.clientId); toast("Génération PDF…"); try{ const doc=await PF24_PDF.generateFacture(f,c,PF24_DB.getConsultant()); doc.save(`${f.numero}_${(c.nom||"client").replace(/\s+/g,"_")}.pdf`); toast("PDF facture généré ✔"); }catch(er){console.error(er);toast("Erreur PDF");} return; }
  if(act==="supprimer-facture"){ if(!confirm("Supprimer cette facture ?")) return; PF24_DB.deleteFactureById(t.dataset.facture); toast("Facture supprimée"); go("factures"); return; }

  /* VISITE TERRAIN */
  if(act==="choisir-metier"){ const mid=t.dataset.metier; const m=METIERS[mid]; APP.visit.metierId=mid; APP.visit.metierNom=m.nom; _saveVisit(); go("choix-blocs"); return; }
  if(act==="toggle-bloc"){ const bid=t.dataset.bloc; const list=APP.visit.blocsSelectionnes; const i=list.indexOf(bid); if(i>=0)list.splice(i,1);else list.push(bid); render(); return; }
  if(act==="valider-blocs"){ if(!(APP.visit.blocsSelectionnes||[]).length){toast("Sélectionnez au moins un bloc");return;} _saveVisit(); go("population"); return; }
  if(act==="valider-population"){ _saveVisit(); go("visite-blocs"); return; }
  if(act==="ouvrir-bloc"){ APP.currentBlocId=t.dataset.bloc; go("visite-bloc-detail"); return; }

  if(act==="set-statut"){ const o=_ensureObj(t.dataset.bloc,decodeURIComponent(t.dataset.objet)); o.statut=t.dataset.statut; _saveVisit(); render(); return; }
  if(act==="set-maitrise"){ const o=_ensureObj(t.dataset.bloc,decodeURIComponent(t.dataset.objet)); o.maitrise=t.dataset.maitrise; _saveVisit(); render(); return; }
  if(act==="ajouter-observation"){ const o=_ensureObj(t.dataset.bloc,decodeURIComponent(t.dataset.objet)); const val=prompt("Observation :",o.observation||""); if(val!==null){o.observation=val;_saveVisit();render();} return; }

  if(act==="ajouter-photo-objet"){ const bid=t.dataset.bloc,obj=decodeURIComponent(t.dataset.objet);
    _openCamera(async du=>{ const id=PF24_DB.uid("photo"); await PF24_DB.savePhoto(id,du); const o=_ensureObj(bid,obj); o.photos=o.photos||[]; o.photos.push(id); APP.visit.photos=APP.visit.photos||[]; APP.visit.photos.push({id,blocId:bid,objet:obj,createdAt:new Date().toISOString()});
      try{ o.iaSuggestion=await PF24_AI.analyserPhoto(du,obj+" "+(o.observation||"")); }catch(e){}
      _saveVisit(); toast("Photo ajoutée ✔"); render(); }); return; }

  if(act==="dicter-observation"){ const bid=t.dataset.bloc,obj=decodeURIComponent(t.dataset.objet);
    if(!PF24_VOICE.isSupported()){toast("Dictée non disponible sur ce navigateur");return;}
    toast("🎤 Parlez maintenant…");
    PF24_VOICE.dicter(texte=>{ const o=_ensureObj(bid,obj); o.observation=(o.observation?o.observation+" / ":"")+texte; const sug=PF24_VOICE.suggererAction(texte); if(sug) setTimeout(()=>toast("💡 "+sug),400); _saveVisit(); render(); }, err=>toast("Erreur : "+err)); return; }

  if(act==="generer-word"||act==="generer-registre"||act==="generer-fiches"||act==="generer-pdp"||act==="generer-protocole"){
    toast("Génération en cours…");
    const {risques,actions}=PF24_ENGINE.genererRisques(APP.visit);
    const client=PF24_DB.getClient(APP.visit.clientId);
      if(!_qcConfirm(client, APP.visit)) return;
    const score=PF24_ENGINE.calculerScore(APP.visit);
    const scoreConf=PF24_ENGINE.calculerScoreConformite(APP.visit,client);
    try{
      let html, filename;
      if(act==="generer-word"){
        html=generateDossierWord(APP.visit,client,risques,actions,score,scoreConf);
        filename=`DUERP_${(client?.nom||"client").replace(/\s+/g,"_")}_v${(APP.visit.historique||[]).length||1}.doc`;
      } else if(act==="generer-registre"){
        html=generateRegistreWord(APP.visit,client,risques);
        filename=`Registre_Securite_${(client?.nom||"client").replace(/\s+/g,"_")}.doc`;
      } else if(act==="generer-fiches"){
        html=generateFichesPosteWord(APP.visit,client,risques);
        filename=`Fiches_Poste_${(client?.nom||"client").replace(/\s+/g,"_")}.doc`;
      } else if(act==="generer-pdp"){
        html=generatePlanPreventionWord(APP.visit,client,risques);
        filename=`Plan_Prevention_${(client?.nom||"client").replace(/\s+/g,"_")}.doc`;
      } else {
        html=generateProtocoleSecuriteWord(APP.visit,client,risques);
        filename=`Protocole_Securite_${(client?.nom||"client").replace(/\s+/g,"_")}.doc`;
      }
      if(!html){ console.error("[Word] HTML vide:",act); toast("Erreur : document vide"); return; }
      html = _sanitizeForDocx(html);
      const docxFilename = filename.replace(/\.doc$/, ".docx");
      let bl;
      try{
        bl = await PF24_DOCX.fromHtml(html, { logo: window.PF24_LOGO || null });
      }catch(convErr){
        console.error("[Word] CONVERSION:",convErr);
        toast("Erreur conversion — "+(convErr.message||"inconnue")); return;
      }
      await _deliverDocx(bl, docxFilename);
      try{ const _cl=PF24_DB.getClient(APP.visit?.clientId)||{}; PF24_DB.logGeneration({type:docxFilename.replace(/_.*/,""), clientId:_cl.id, clientNom:_cl.nom, version:(APP.visit?.historique||[]).length||1, consultant:(PF24_DB.getConsultant()||{}).nom||""}); }catch(e){}
    }catch(er){
      console.error("[Word] GÉNÉRATION ("+act+"):",er);
      toast("Erreur génération — "+(er.message||"console"));
    } return; }

  if(act==="generer-dossier"){
    { const _c=PF24_DB.getClient(APP.visit?.clientId); if(!_qcConfirm(_c, APP.visit)) return; } toast("Génération du dossier…");
    const {risques,actions}=PF24_ENGINE.genererRisques(APP.visit);
    const client=PF24_DB.getClient(APP.visit.clientId);
    const score=PF24_ENGINE.calculerScore(APP.visit);
    const scoreConf=PF24_ENGINE.calculerScoreConformite(APP.visit,client);
    PF24_ENGINE.nouvelleVersion(APP.visit);
    PF24_DB.updateClientRelance(APP.visit.clientId,new Date(Date.now()+365*24*3600*1000).toISOString().slice(0,10));
    try{ const doc=await PF24_PDF.generateDossier(APP.visit,client,risques,actions,score,scoreConf);
      APP.visit.statut="terminee"; _saveVisit();
      const pdfFilename=`PF24_DUERP_${(client?.nom||"client").replace(/\s+/g,"_")}_v${APP.visit.historique.length}.pdf`;
      doc.save(pdfFilename);
      toast("Dossier v"+APP.visit.historique.length+" généré ✔");
      // Sauvegarde JSON automatique
      try{
        const jsonBlob=new Blob([PF24_DB.exportAll()],{type:"application/json"});
        const jsonUrl=URL.createObjectURL(jsonBlob);
        const jsonLnk=document.createElement("a");
        jsonLnk.href=jsonUrl;
        jsonLnk.download=`PF24_backup_${new Date().toISOString().slice(0,10)}.json`;
        document.body.appendChild(jsonLnk); jsonLnk.click(); document.body.removeChild(jsonLnk);
        setTimeout(()=>URL.revokeObjectURL(jsonUrl),2000);
      }catch(e){ console.warn("Backup auto JSON:",e); }
      const sugg=detecterUpsell(APP.visit);
      if(sugg.length){ APP._upsellSuggestions=sugg; setTimeout(()=>go("upsell"),2000); }
    }catch(er){ console.error(er); toast("Erreur PDF : "+er.message); } return; }

  if(act==="ouvrir-registre"){ go("registre-screen"); return; }
  if(act==="ouvrir-historique"){ go("historique-screen"); return; }

  if(act==="set-registre"){ if(!APP.visit)return; const item=decodeURIComponent(t.dataset.item); APP.visit.registre=APP.visit.registre||{}; APP.visit.registre[item]=APP.visit.registre[item]||{}; APP.visit.registre[item].statut=t.dataset.statut; _saveVisit(); render(); return; }
  if(act==="sauver-registre"){ if(!APP.visit)return; document.querySelectorAll("[data-reg-obs]").forEach(ta=>{ const item=decodeURIComponent(ta.dataset.regObs); APP.visit.registre[item]=APP.visit.registre[item]||{}; APP.visit.registre[item].observation=ta.value; }); _saveVisit(); toast("Registre enregistré ✔"); back(); return; }

  if(act==="exporter-json-visite"){ if(!APP.visit)return; const bl=new Blob([JSON.stringify(APP.visit,null,2)],{type:"application/json"}); const a=document.createElement("a"); a.href=URL.createObjectURL(bl); a.download=`visite_${APP.visit.id}.json`; a.click(); return; }

  /* RELANCES */
  if(act==="email-relance"){ const c=PF24_DB.getClient(t.dataset.client); const cons=PF24_DB.getConsultant(); const msg=`Objet : Mise à jour DUERP — ${c?.nom||""}\n\nMadame, Monsieur,\n\nNous vous contactons pour vous rappeler que votre DUERP doit être mis à jour.\n\nNous vous proposons un rendez-vous de mise à jour.\n\nCordialement,\n${cons.nom||"Prévention Facile"}\n${cons.email||""}`; prompt("Email type (copiez-le) :",msg); return; }
  if(act==="devis-relance"){ APP._devisClientId=t.dataset.client; go("nouveau-devis"); return; }

  /* PARAMETRES */
  if(act==="sauver-consultant"){ PF24_DB.saveConsultant({nom:document.getElementById("cons-nom")?.value,fonction:document.getElementById("cons-fonction")?.value,piedPage:document.getElementById("cons-piedpage")?.value||"",activite:document.getElementById("cons-activite")?.value,siret:document.getElementById("cons-siret")?.value,adresse:document.getElementById("cons-adresse")?.value,telephone:document.getElementById("cons-tel")?.value,email:document.getElementById("cons-email")?.value}); toast("Profil enregistré ✔"); return; }
  if(act==="changer-pwd"){ const old=document.getElementById("pwd-old")?.value; const nw=document.getElementById("pwd-new")?.value; if(!nw||nw.length<3){toast("Nouveau mot de passe trop court");return;} if(PF24_DB.changePwd(old,nw)){toast("Mot de passe modifié ✔");}else{toast("❌ Ancien mot de passe incorrect");} return; }
  if(act==="export-all-json"){ const bl=new Blob([PF24_DB.exportAll()],{type:"application/json"}); const a=document.createElement("a"); a.href=URL.createObjectURL(bl); a.download="PF24_export_complet.json"; a.click(); return; }
  if(act==="import-all"){ const f=document.getElementById("import-file")?.files[0]; if(!f){toast("Choisissez un fichier JSON");return;} const rd=new FileReader(); rd.onload=()=>{ try{PF24_DB.importAll(rd.result);toast("Import fusionné — aucun doublon ✔");render();}catch(e){toast("Erreur d'import");} }; rd.readAsText(f); return; }
  if(act==="charger-demo"){ _chargerDemo(); toast("Visite démo chargée ✔"); go("validation"); return; }
});

/* ---- DÉMO ---- */
function _chargerDemo(){
  let client=PF24_DB.getClients().find(c=>c.nom==="Client de démonstration");
  if(!client){ client={id:PF24_DB.uid("client"),nom:"Client de démonstration",siret:"",ape:"",adresse:"",contact:"",telephone:"",email:"",activite:"Boulangerie / Pâtisserie",salaries:"5",hommes:"3",femmes:"2",spst:"",statut:"client",apprentis:true,interimaires:false,jeunesTravailleurs:true,travailIsole:false,vulnerables:false,entreprisesExterieures:false,teletravail:false,deplacements:true,redacteur:"",valideur:"",prochainMaj:null,photoId:null,createdAt:new Date().toISOString()}; PF24_DB.saveClient(client); }
  newVisit(client.id);
  Object.assign(APP.visit,{metierId:"boulangerie",metierNom:"Boulangerie",blocsSelectionnes:["accueil","cuisine","stockage","sanitaires","electricite","incendie"],deplacements:true});
  APP.visit.population={
    cuisine:{exposes:3,hommes:2,femmes:1,apprentis:true,jeunesTravailleurs:true,travailIsole:false,expoDiff:false,commentaire:""},
    accueil:{exposes:2,hommes:1,femmes:1,apprentis:false,jeunesTravailleurs:false,travailIsole:false,expoDiff:false,commentaire:""}
  };
  const setObj=(b,o,s,m,obs)=>{const ob=_ensureObj(b,o);ob.statut=s;ob.maitrise=m||null;ob.observation=obs||"";};
  setObj("cuisine","Four professionnel","present","moyen","Four contrôlé il y a 14 mois");
  setObj("cuisine","Hotte d'extraction","present","insuffisant","Pas de nettoyage professionnel récent");
  setObj("cuisine","Sol cuisine (glissant)","present","insuffisant","Farine au sol non balayée régulièrement");
  setObj("cuisine","Couteaux de cuisine","present","bon","");
  setObj("cuisine","Friteuse","present","moyen","Thermostat à vérifier");
  setObj("stockage","Rayonnage","present","moyen","");
  setObj("stockage","Escabeau","present","bon","");
  setObj("electricite","Tableau électrique général","present","moyen","Dernier contrôle > 12 mois");
  setObj("incendie","Extincteur","present","bon","Vérifié il y a 6 mois");
  setObj("incendie","Issue de secours","present","insuffisant","Cartons devant la sortie de secours");
  setObj("sanitaires","Lavabo","present","bon","");
  setObj("accueil","Caisse / comptoir","present","bon","");
  APP.visit.registre={"Extincteurs":{statut:"conforme",observation:"Vérifié il y a 6 mois"},"Installation électrique":{statut:"a_verifier",observation:"Contrôle > 12 mois"},"Trousse de secours":{statut:"conforme",observation:"Complète"},"FDS (fiches de données de sécurité)":{statut:"non_conforme",observation:"FDS produits nettoyage manquantes"}};
  APP.visit.statut="en_cours"; _saveVisit();
}

/* ---- INIT ---- */
if("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
render();
