const CACHE = "pf24-v21";
const ASSETS = [
  "./","./index.html","./style.css","./manifest.json",
  "./data.js","./db.js","./ai-voice.js","./risks-engine.js",
  "./pdf-generator.js","./render.js","./app.js","./jszip.min.js","./docx-builder.js","./assets/logo.png"
];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).catch(()=>{}));
  self.skipWaiting();
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);
  const isLocal = url.origin === self.location.origin;
  if (isLocal) {
    // RÉSEAU D'ABORD pour les fichiers de l'app : toujours la dernière version en ligne,
    // cache utilisé uniquement hors connexion.
    e.respondWith(
      fetch(e.request).then(r => {
        const clone = r.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return r;
      }).catch(() => caches.match(e.request))
    );
  } else {
    // CDN (jsPDF) : cache d'abord
    e.respondWith(caches.match(e.request).then(cached =>
      cached || fetch(e.request).then(r => {
        const clone = r.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return r;
      }).catch(() => cached)
    ));
  }
});
