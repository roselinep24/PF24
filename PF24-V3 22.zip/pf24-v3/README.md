# PF24 – Prévention Facile V3
## Application PWA complète de gestion consultant HSE

CRM • Devis • Factures • Visite terrain • DUERP • PAPRIPACT • Relances annuelles

---

## ⚡ Lancer en 30 secondes

```bash
unzip PF24-V3.zip && cd pf24-v3
python3 -m http.server 8080
# Ouvrir : http://localhost:8080
```
**Mot de passe par défaut : `pf24`**

---

## 📱 Installer sur iPhone (méthode la plus simple)

1. Dézippez `PF24-V3.zip`
2. Allez sur **[app.netlify.com/drop](https://app.netlify.com/drop)**
3. **Glissez-déposez** le dossier `pf24-v3` sur la page
4. Copiez l'URL obtenue (ex. `https://abc123.netlify.app`)
5. Envoyez-vous ce lien (email, SMS, notes)
6. Sur iPhone, ouvrez le lien dans **Safari**
7. Bouton **Partager** (↑) → **"Sur l'écran d'accueil"** → Ajouter

**L'app s'installe comme une vraie application.** Fonctionne hors-ligne.

---

## 💻 Installer sur Chromebook

1. Activez Linux si nécessaire (Paramètres → Développeurs → Linux)
2. Ouvrez le Terminal Linux
3. Copiez le dossier `pf24-v3` dans "Linux files" via le gestionnaire de fichiers
4. Dans le terminal :
```bash
cd ~/pf24-v3
python3 -m http.server 8080
```
5. Chrome → `http://localhost:8080`
6. Menu Chrome (⋮) → **Installer l'application**

---

## 🗺️ Guide de l'application

### 1. Connexion
- Mot de passe : **pf24** (modifiable dans Réglages)
- Session locale, aucun compte cloud requis

### 2. Tableau de bord
- Vue d'ensemble : CA estimé, clients, devis en attente, missions, relances
- Accès rapide à la nouvelle visite et à la création de devis

### 3. CRM Clients
- Fiche complète : SIRET, APE, effectif H/F, populations particulières (art. R4121-1)
- Historique des visites, devis, factures par client
- Système de relances annuelles avec alertes couleur
- Suppression RGPD complète

### 4. Catalogue d'offres
| Offre | Prix |
|---|---|
| Pack Essentiel DUERP | 350 € |
| Pack Conformité | 550 € |
| Pack Sérénité | 850 € |
| Mise à jour annuelle | 250 € |
| Fiches de poste | 150 € |
| Registre sécurité | 100 € |
| Affichages obligatoires | 80 € |
| Audit sécurité | 450 € |
| Analyse risque chimique | 300 € |
| Accompagnement plan d'actions | 480 € (4h) |

### 5. Devis intelligents
- Sélection des prestations du catalogue
- Ajustement automatique au nombre de salariés et à la complexité
- Export PDF professionnel auto-entrepreneur (TVA non applicable, art. 293B CGI)
- Statuts : brouillon → envoyé → accepté → refusé
- Conversion en facture en 1 clic

### 6. Factures
- Numérotation automatique : FA-2026-001
- Suivi : brouillon → envoyée → payée / impayée
- PDF premium avec toutes les mentions légales
- Acompte et solde gérés

### 7. Visite terrain (5 étapes)
1. **Choix du métier** — 60 métiers disponibles
2. **Choix des blocs** — 35 blocs PF24, suggestions automatiques par métier
3. **Population exposée** — R4121-1, par unité de travail
4. **Visite par bloc** — Objets présents/absents, niveau de maîtrise, photos, dictée vocale, IA
5. **Bilan** — Scores sécurité et conformité, génération du dossier PDF

### 8. 60 métiers couverts
Restaurant • Brasserie • Snack • Pizzeria • Boulangerie • Pâtisserie • Boucherie • Traiteur • Fleuriste • Épicerie • Primeur • Caviste • Librairie • Vêtements • Salon de thé • Tabac • Décoration • Animalerie • Garage • Carrossier • Électricien • Plombier • Chauffagiste • Menuisier • Serrurier • Peintre • Maçon • Couvreur • Coiffeur • Barbier • Esthéticienne • Tatoueur • Cabinet médical • Cabinet dentaire • Kinésithérapeute • Ostéopathe • Podologue • Pharmacie • Bureau admin • Cabinet comptable • Agence immobilière • Cabinet d'avocats • Bureau d'études • Centre de formation • Agence de communication • Société informatique • Assurance • Banque • Entrepôt • Atelier de fabrication • Imprimerie • Laboratoire • Atelier de maintenance • Transport • Livreur • Centre de tri • Recyclerie • Blanchisserie • Pressing • Entreprise de nettoyage

### 9. 35 blocs PF24
Accueil • Bureau • Stockage • Sanitaires • Vestiaires • Salle de pause • Nettoyage • Local déchets • Parking • Circulation • Livraison • Produits chimiques • Électricité • Gaz • Incendie • Froid • Ventilation • Éclairage • Bruit • Manutention • Levage • Travail en hauteur • Machines • Outillage • Véhicules • Chargement • Déchargement • Cuisine • Atelier mécanique • Laboratoire • Salle de soins • Tatouage • Salon de coiffure • Salle de vente • Fabrication alimentaire

### 10. Dossier PDF premium
- **Couverture** : logo, client, date, version, photo façade
- **Lettre au dirigeant** : texte professionnel + mentions réglementaires
- **Tableau de bord** : scores sécurité et conformité
- **Populations exposées** : par unité de travail
- **Top 5 priorités**
- **Rapport par bloc** : résumé + photos + risques + actions
- **Tableau DUERP** : unité, population, danger, mesures, G/P/Niveau
- **PAPRIPACT** : action, priorité, responsable, délai, preuve
- **Conformité réglementaire**
- **Fiches de poste** selon le métier
- **Registre de sécurité** avec statuts
- **Historique des versions**
- **Page finale** : signatures consultant + client

### 11. Fonctions IA et Vocal
- **Dictée vocale** 🎤 : transcription automatique + suggestion d'action
- **IA photo** 🤖 : détection mock d'objets dangereux + suggestions (architecture prête pour API externe)
- `PF24_AI.setApiEndpoint("https://votre-api.com/analyze")` pour activer une vraie IA

### 12. Automatisation commerciale
Après chaque visite, PF24 détecte automatiquement :
- Actions nombreuses → suggère l'accompagnement plan d'actions
- Pas de registre → suggère le registre sécurité
- Pas de fiches de poste → suggère le pack conformité
- FDS manquantes → suggère l'analyse risque chimique

### 13. Relances annuelles
- La date de prochaine mise à jour est automatiquement fixée 12 mois après chaque dossier généré
- Dashboard : alertes couleur (rouge = dépassé, orange = < 30 jours, vert = OK)
- Email type générable en 1 clic
- Devis de mise à jour pré-rempli

---

## 🔒 RGPD & Données

- **Stockage 100% local** : localStorage + IndexedDB du navigateur
- **Aucun serveur** : aucune donnée transmise à l'extérieur
- **Aucune donnée nominative de santé** dans le DUERP
- **Suppression client** : efface toutes les visites, devis et factures associés
- **Export JSON** complet de toutes les données
- **Import JSON** pour restaurer sur un autre appareil
- **Photos** : stockées localement dans IndexedDB, ne pas photographier les visages

---

## 📁 Structure des fichiers

```
pf24-v3/
├── index.html          Shell PWA
├── style.css           Design system premium
├── manifest.json       Config PWA (icône, couleurs)
├── service-worker.js   Cache offline
├── app.js              Contrôleur principal + événements
├── data.js             60 métiers, 35 blocs, catalogue, règles de risques
├── db.js               Stockage (clients, visites, devis, factures, photos)
├── ai-voice.js         IA photo (mock) + dictée vocale
├── risks-engine.js     Moteur de génération des risques DUERP
├── pdf-generator.js    PDF premium (DUERP + Devis + Factures)
├── render.js           Templates HTML de tous les écrans
└── assets/
    ├── icon-192.png
    └── icon-512.png
```

---

## 🔧 Personnalisation

**Profil consultant** : Réglages → Profil consultant (nom, activité, SIRET, email, téléphone)

**Changer le mot de passe** : Réglages → Sécurité

**Connecter une vraie IA photo** : Dans la console du navigateur :
```js
PF24_AI.setApiEndpoint("https://votre-api-ia.com/analyze");
```

**Importer les blocs Excel PF24** : Convertir les fichiers BLOC-XXX.xlsx en JSON au format `REGLES_OBJETS` de `data.js`, puis les fusionner.

---

## ⚠️ Mentions importantes

- PF24 est une aide à l'évaluation des risques. **Le consultant HSE valide toujours** le dossier final.
- La tarification (devis) est indicative et doit être adaptée à votre grille tarifaire.
- Les prix affichés n'incluent pas la TVA (auto-entrepreneur, art. 293B CGI).
- Les données sont stockées localement sur l'appareil. Pensez à exporter régulièrement.

---

*PF24 – Prévention Facile • Application privée consultant HSE*
