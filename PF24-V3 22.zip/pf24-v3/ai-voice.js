/* PF24 V3 — IA photo (mock) + Dictée vocale */
const AI_RULES = [
  { k:"extincteur", l:"Extincteur", r:["Absence ou non-conformité du moyen d'extinction"], a:["Vérifier la présence et la conformité de l'extincteur"] },
  { k:"électrique", l:"Armoire électrique", r:["Défaut d'installation électrique"], a:["Faire vérifier l'installation par un organisme agréé"] },
  { k:"friteuse", l:"Friteuse", r:["Brûlure, incendie par surchauffe de l'huile"], a:["Vérifier le thermostat de sécurité de la friteuse"] },
  { k:"four", l:"Four", r:["Brûlure cutanée"], a:["Fournir des gants thermiques"] },
  { k:"pont", l:"Pont élévateur", r:["Écrasement sous véhicule"], a:["Vérifier le rapport de contrôle périodique"] },
  { k:"aiguille", l:"Aiguille / matériel piquant", r:["AES — Accident d'Exposition au Sang"], a:["Vérifier la présence d'un collecteur DASRI"] },
  { k:"autoclave", l:"Autoclave", r:["Stérilisation insuffisante, contamination croisée"], a:["Contrôler le cycle de stérilisation annuellement"] },
  { k:"dasri", l:"Collecteur DASRI", r:["Piqûre accidentelle par aiguille souillée"], a:["Vérifier le remplissage et la filière d'élimination"] },
  { k:"chimi", l:"Produits chimiques", r:["Exposition chimique par inhalation ou contact"], a:["Vérifier la disponibilité des FDS"] },
  { k:"escabeau", l:"Escabeau", r:["Chute de hauteur"], a:["Vérifier la conformité de l'escabeau"] },
  { k:"câble", l:"Câbles au sol", r:["Chute de plain-pied"], a:["Sécuriser les câbles au sol (passe-câbles)"] },
  { k:"issue", l:"Issue de secours", r:["Évacuation entravée en cas d'incendie"], a:["Dégager l'issue de secours en permanence"] },
  { k:"chambre froide", l:"Chambre froide", r:["Enfermement, hypothermie grave"], a:["Vérifier le dispositif d'ouverture intérieure"] },
  { k:"stockage dangereux", l:"Stockage dangereux", r:["Chute d'objet, explosion"], a:["Organiser et sécuriser la zone de stockage"] },
];

const PF24_AI = (() => {
  let apiEndpoint=null;

  async function analyserPhotoMock(contexte){
    const t=(contexte||"").toLowerCase();
    const matches=AI_RULES.filter(r=>t.includes(r.k));
    if(!matches.length) return { objetsDetectes:["Analyse non concluante (mode démo)"],risquesPossibles:[],actionsProposees:[],mock:true };
    return { objetsDetectes:matches.map(m=>m.l), risquesPossibles:[...new Set(matches.flatMap(m=>m.r))], actionsProposees:[...new Set(matches.flatMap(m=>m.a))],mock:true };
  }

  async function analyserPhoto(dataUrl,contexte){
    if(apiEndpoint){ try{ const res=await fetch(apiEndpoint,{method:"POST",body:JSON.stringify({image:dataUrl})}); return await res.json(); }catch(e){ console.warn("IA API indisponible, repli mock"); } }
    return analyserPhotoMock(contexte);
  }

  return { analyserPhoto, analyserPhotoMock, setApiEndpoint:(url)=>{ apiEndpoint=url; } };
})();

const PF24_VOICE = (() => {
  function isSupported(){ return ("SpeechRecognition" in window)||("webkitSpeechRecognition" in window); }

  const SUGGESTIONS = [
    { k:"extincteur", a:"Vérifier la présence et l'accessibilité de l'extincteur" },
    { k:"gant", a:"Mettre à disposition les EPI manquants (gants)" },
    { k:"encombr", a:"Dégager et organiser la zone concernée" },
    { k:"sol", a:"Nettoyer le sol et installer une signalisation glissance" },
    { k:"fds", a:"Réclamer les FDS manquantes auprès des fournisseurs" },
    { k:"issue", a:"Dégager l'issue de secours en permanence" },
    { k:"dasri", a:"Mettre à disposition un collecteur DASRI dédié" },
    { k:"aes", a:"Afficher la procédure AES et former le personnel" },
    { k:"câble", a:"Sécuriser les câbles au sol (passe-câbles ou goulotes)" },
    { k:"éclairage", a:"Renforcer ou réparer l'éclairage de la zone concernée" },
  ];

  function suggererAction(texte){ const t=(texte||"").toLowerCase(); const match=SUGGESTIONS.find(s=>t.includes(s.k)); return match?match.a:null; }

  function dicter(onResult, onError){
    if(!isSupported()){ if(onError) onError("Dictée vocale non disponible sur ce navigateur."); return null; }
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    const rec=new SR(); rec.lang="fr-FR"; rec.interimResults=false; rec.maxAlternatives=1;
    rec.onresult=e=>onResult(e.results[0][0].transcript);
    rec.onerror=e=>{ if(onError) onError("Erreur dictée : "+e.error); };
    rec.start(); return rec;
  }

  return { isSupported, dicter, suggererAction };
})();
